//#region src/functions/combat/toughness.ts
function e(e) {
	return e.constitutionModifier + (e.proficiencyBonus - 2);
}
//#endregion
//#region src/functions/combat/damage-negation.ts
function t(t) {
	let n = t.toughnessApplies === !1 ? 0 : e(t), r = t.armourApplies === !1 ? 0 : Math.max(0, (t.armourBaseAc ?? 10) - 10), i = t.shieldApplies === !1 ? 0 : t.shieldBonus ?? 0, a = t.tanking ? t.strengthModifier ?? 0 : 0;
	return {
		armour: r,
		shield: i,
		tanking: a,
		toughness: n,
		total: n + r + i + a
	};
}
//#endregion
//#region src/functions/combat/defense-responses.ts
var n = [
	{
		criticalEffect: "A natural 20 inflicts a Critical Injury on the attacker.",
		id: "parry",
		label: "Parry",
		opposed: !0,
		summary: "Oppose the attack with a weapon-based defense roll."
	},
	{
		criticalEffect: "A natural 20 negates all damage, even if the attacker wins the exchange.",
		id: "dodge",
		label: "Dodge",
		opposed: !0,
		summary: "Oppose the attack using Dexterity and movement."
	},
	{
		criticalEffect: "No defense roll means no defensive critical.",
		id: "tank",
		label: "Tank the Hit",
		opposed: !1,
		summary: "Accept the hit and add Strength modifier to Negation for this hit."
	},
	{
		criticalEffect: "No defense roll means no defensive critical.",
		id: "unopposed",
		label: "Unopposed",
		opposed: !1,
		summary: "Resolve the attack without a defense roll."
	},
	{
		criticalEffect: "A successful Surprised attack inflicts one unmodified Critical Injury; damage dice are not doubled.",
		id: "surprised",
		label: "Surprised",
		opposed: !1,
		summary: "Resolve the attack without a defense roll and inflict a Critical Injury if it deals damage."
	}
];
function r(e) {
	return typeof e == "string" && n.some((t) => t.id === e);
}
//#endregion
//#region src/functions/combat/momentum-cap.ts
function i(e) {
	return Math.max(1, Math.trunc(e));
}
//#endregion
//#region src/functions/combat/resolve-damage-after-negation.ts
function a(e) {
	return e.damage <= 0 ? 0 : Math.max(1, e.damage - e.negation);
}
//#endregion
//#region node_modules/@vue/shared/dist/shared.esm-bundler.js
// @__NO_SIDE_EFFECTS__
function o(e) {
	let t = /* @__PURE__ */ Object.create(null);
	for (let n of e.split(",")) t[n] = 1;
	return (e) => e in t;
}
var s = {}, c = [], l = () => {}, u = () => !1, d = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && (e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97), f = (e) => e.startsWith("onUpdate:"), p = Object.assign, m = (e, t) => {
	let n = e.indexOf(t);
	n > -1 && e.splice(n, 1);
}, h = Object.prototype.hasOwnProperty, g = (e, t) => h.call(e, t), _ = Array.isArray, v = (e) => T(e) === "[object Map]", y = (e) => T(e) === "[object Set]", b = (e) => T(e) === "[object Date]", x = (e) => typeof e == "function", S = (e) => typeof e == "string", C = (e) => typeof e == "symbol", w = (e) => typeof e == "object" && !!e, ee = (e) => (w(e) || x(e)) && x(e.then) && x(e.catch), te = Object.prototype.toString, T = (e) => te.call(e), ne = (e) => T(e).slice(8, -1), re = (e) => T(e) === "[object Object]", ie = (e) => S(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e, ae = /* @__PURE__ */ o(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"), oe = (e) => {
	let t = /* @__PURE__ */ Object.create(null);
	return ((n) => t[n] || (t[n] = e(n)));
}, se = /-\w/g, E = oe((e) => e.replace(se, (e) => e.slice(1).toUpperCase())), D = /\B([A-Z])/g, ce = oe((e) => e.replace(D, "-$1").toLowerCase()), le = oe((e) => e.charAt(0).toUpperCase() + e.slice(1)), ue = oe((e) => e ? `on${le(e)}` : ""), O = (e, t) => !Object.is(e, t), de = (e, ...t) => {
	for (let n = 0; n < e.length; n++) e[n](...t);
}, fe = (e, t, n, r = !1) => {
	Object.defineProperty(e, t, {
		configurable: !0,
		enumerable: !1,
		writable: r,
		value: n
	});
}, pe = (e) => {
	let t = parseFloat(e);
	return isNaN(t) ? e : t;
}, me, he = () => me ||= typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {};
function ge(e) {
	if (_(e)) {
		let t = {};
		for (let n = 0; n < e.length; n++) {
			let r = e[n], i = S(r) ? be(r) : ge(r);
			if (i) for (let e in i) t[e] = i[e];
		}
		return t;
	} else if (S(e) || w(e)) return e;
}
var _e = /;(?![^(]*\))/g, ve = /:([^]+)/, ye = /\/\*[^]*?\*\//g;
function be(e) {
	let t = {};
	return e.replace(ye, "").split(_e).forEach((e) => {
		if (e) {
			let n = e.split(ve);
			n.length > 1 && (t[n[0].trim()] = n[1].trim());
		}
	}), t;
}
function xe(e) {
	let t = "";
	if (S(e)) t = e;
	else if (_(e)) for (let n = 0; n < e.length; n++) {
		let r = xe(e[n]);
		r && (t += r + " ");
	}
	else if (w(e)) for (let n in e) e[n] && (t += n + " ");
	return t.trim();
}
var Se = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly", Ce = /* @__PURE__ */ o(Se);
Se + "";
function we(e) {
	return !!e || e === "";
}
function Te(e, t) {
	if (e.length !== t.length) return !1;
	let n = !0;
	for (let r = 0; n && r < e.length; r++) n = Ee(e[r], t[r]);
	return n;
}
function Ee(e, t) {
	if (e === t) return !0;
	let n = b(e), r = b(t);
	if (n || r) return n && r ? e.getTime() === t.getTime() : !1;
	if (n = C(e), r = C(t), n || r) return e === t;
	if (n = _(e), r = _(t), n || r) return n && r ? Te(e, t) : !1;
	if (n = w(e), r = w(t), n || r) {
		if (!n || !r || Object.keys(e).length !== Object.keys(t).length) return !1;
		for (let n in e) {
			let r = e.hasOwnProperty(n), i = t.hasOwnProperty(n);
			if (r && !i || !r && i || !Ee(e[n], t[n])) return !1;
		}
	}
	return String(e) === String(t);
}
var De = (e) => !!(e && e.__v_isRef === !0), k = (e) => S(e) ? e : e == null ? "" : _(e) || w(e) && (e.toString === te || !x(e.toString)) ? De(e) ? k(e.value) : JSON.stringify(e, Oe, 2) : String(e), Oe = (e, t) => De(t) ? Oe(e, t.value) : v(t) ? { [`Map(${t.size})`]: [...t.entries()].reduce((e, [t, n], r) => (e[ke(t, r) + " =>"] = n, e), {}) } : y(t) ? { [`Set(${t.size})`]: [...t.values()].map((e) => ke(e)) } : C(t) ? ke(t) : w(t) && !_(t) && !re(t) ? String(t) : t, ke = (e, t = "") => C(e) ? `Symbol(${e.description ?? t})` : e, A, Ae = class {
	constructor(e = !1) {
		this.detached = e, this._active = !0, this._on = 0, this.effects = [], this.cleanups = [], this._isPaused = !1, this._warnOnRun = !0, this.__v_skip = !0, !e && A && (A.active ? (this.parent = A, this.index = (A.scopes ||= []).push(this) - 1) : (this._active = !1, this._warnOnRun = !1));
	}
	get active() {
		return this._active;
	}
	pause() {
		if (this._active) {
			this._isPaused = !0;
			let e, t;
			if (this.scopes) for (e = 0, t = this.scopes.length; e < t; e++) this.scopes[e].pause();
			for (e = 0, t = this.effects.length; e < t; e++) this.effects[e].pause();
		}
	}
	resume() {
		if (this._active && this._isPaused) {
			this._isPaused = !1;
			let e, t;
			if (this.scopes) for (e = 0, t = this.scopes.length; e < t; e++) this.scopes[e].resume();
			for (e = 0, t = this.effects.length; e < t; e++) this.effects[e].resume();
		}
	}
	run(e) {
		if (this._active) {
			let t = A;
			try {
				return A = this, e();
			} finally {
				A = t;
			}
		}
	}
	on() {
		++this._on === 1 && (this.prevScope = A, A = this);
	}
	off() {
		if (this._on > 0 && --this._on === 0) {
			if (A === this) A = this.prevScope;
			else {
				let e = A;
				for (; e;) {
					if (e.prevScope === this) {
						e.prevScope = this.prevScope;
						break;
					}
					e = e.prevScope;
				}
			}
			this.prevScope = void 0;
		}
	}
	stop(e) {
		if (this._active) {
			this._active = !1;
			let t, n;
			for (t = 0, n = this.effects.length; t < n; t++) this.effects[t].stop();
			for (this.effects.length = 0, t = 0, n = this.cleanups.length; t < n; t++) this.cleanups[t]();
			if (this.cleanups.length = 0, this.scopes) {
				for (t = 0, n = this.scopes.length; t < n; t++) this.scopes[t].stop(!0);
				this.scopes.length = 0;
			}
			if (!this.detached && this.parent && !e) {
				let e = this.parent.scopes.pop();
				e && e !== this && (this.parent.scopes[this.index] = e, e.index = this.index);
			}
			this.parent = void 0;
		}
	}
};
function je(e) {
	return new Ae(e);
}
function Me() {
	return A;
}
var j, Ne = /* @__PURE__ */ new WeakSet(), Pe = class {
	constructor(e) {
		this.fn = e, this.deps = void 0, this.depsTail = void 0, this.flags = 5, this.next = void 0, this.cleanup = void 0, this.scheduler = void 0, A && (A.active ? A.effects.push(this) : this.flags &= -2);
	}
	pause() {
		this.flags |= 64;
	}
	resume() {
		this.flags & 64 && (this.flags &= -65, Ne.has(this) && (Ne.delete(this), this.trigger()));
	}
	notify() {
		this.flags & 2 && !(this.flags & 32) || this.flags & 8 || Re(this);
	}
	run() {
		if (!(this.flags & 1)) return this.fn();
		this.flags |= 2, Xe(this), Ve(this);
		let e = j, t = M;
		j = this, M = !0;
		try {
			return this.fn();
		} finally {
			He(this), j = e, M = t, this.flags &= -3;
		}
	}
	stop() {
		if (this.flags & 1) {
			for (let e = this.deps; e; e = e.nextDep) Ge(e);
			this.deps = this.depsTail = void 0, Xe(this), this.onStop && this.onStop(), this.flags &= -2;
		}
	}
	trigger() {
		this.flags & 64 ? Ne.add(this) : this.scheduler ? this.scheduler() : this.runIfDirty();
	}
	runIfDirty() {
		Ue(this) && this.run();
	}
	get dirty() {
		return Ue(this);
	}
}, Fe = 0, Ie, Le;
function Re(e, t = !1) {
	if (e.flags |= 8, t) {
		e.next = Le, Le = e;
		return;
	}
	e.next = Ie, Ie = e;
}
function ze() {
	Fe++;
}
function Be() {
	if (--Fe > 0) return;
	if (Le) {
		let e = Le;
		for (Le = void 0; e;) {
			let t = e.next;
			e.next = void 0, e.flags &= -9, e = t;
		}
	}
	let e;
	for (; Ie;) {
		let t = Ie;
		for (Ie = void 0; t;) {
			let n = t.next;
			if (t.next = void 0, t.flags &= -9, t.flags & 1) try {
				t.trigger();
			} catch (t) {
				e ||= t;
			}
			t = n;
		}
	}
	if (e) throw e;
}
function Ve(e) {
	for (let t = e.deps; t; t = t.nextDep) t.version = -1, t.prevActiveLink = t.dep.activeLink, t.dep.activeLink = t;
}
function He(e) {
	let t, n = e.depsTail, r = n;
	for (; r;) {
		let e = r.prevDep;
		r.version === -1 ? (r === n && (n = e), Ge(r), Ke(r)) : t = r, r.dep.activeLink = r.prevActiveLink, r.prevActiveLink = void 0, r = e;
	}
	e.deps = t, e.depsTail = n;
}
function Ue(e) {
	for (let t = e.deps; t; t = t.nextDep) if (t.dep.version !== t.version || t.dep.computed && (We(t.dep.computed) || t.dep.version !== t.version)) return !0;
	return !!e._dirty;
}
function We(e) {
	if (e.flags & 4 && !(e.flags & 16) || (e.flags &= -17, e.globalVersion === Ze) || (e.globalVersion = Ze, !e.isSSR && e.flags & 128 && (!e.deps && !e._dirty || !Ue(e)))) return;
	e.flags |= 2;
	let t = e.dep, n = j, r = M;
	j = e, M = !0;
	try {
		Ve(e);
		let n = e.fn(e._value);
		(t.version === 0 || O(n, e._value)) && (e.flags |= 128, e._value = n, t.version++);
	} catch (e) {
		throw t.version++, e;
	} finally {
		j = n, M = r, He(e), e.flags &= -3;
	}
}
function Ge(e, t = !1) {
	let { dep: n, prevSub: r, nextSub: i } = e;
	if (r && (r.nextSub = i, e.prevSub = void 0), i && (i.prevSub = r, e.nextSub = void 0), n.subs === e && (n.subs = r, !r && n.computed)) {
		n.computed.flags &= -5;
		for (let e = n.computed.deps; e; e = e.nextDep) Ge(e, !0);
	}
	!t && !--n.sc && n.map && n.map.delete(n.key);
}
function Ke(e) {
	let { prevDep: t, nextDep: n } = e;
	t && (t.nextDep = n, e.prevDep = void 0), n && (n.prevDep = t, e.nextDep = void 0);
}
var M = !0, qe = [];
function Je() {
	qe.push(M), M = !1;
}
function Ye() {
	let e = qe.pop();
	M = e === void 0 ? !0 : e;
}
function Xe(e) {
	let { cleanup: t } = e;
	if (e.cleanup = void 0, t) {
		let e = j;
		j = void 0;
		try {
			t();
		} finally {
			j = e;
		}
	}
}
var Ze = 0, Qe = class {
	constructor(e, t) {
		this.sub = e, this.dep = t, this.version = t.version, this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
	}
}, $e = class {
	constructor(e) {
		this.computed = e, this.version = 0, this.activeLink = void 0, this.subs = void 0, this.map = void 0, this.key = void 0, this.sc = 0, this.__v_skip = !0;
	}
	track(e) {
		if (!j || !M || j === this.computed) return;
		let t = this.activeLink;
		if (t === void 0 || t.sub !== j) t = this.activeLink = new Qe(j, this), j.deps ? (t.prevDep = j.depsTail, j.depsTail.nextDep = t, j.depsTail = t) : j.deps = j.depsTail = t, et(t);
		else if (t.version === -1 && (t.version = this.version, t.nextDep)) {
			let e = t.nextDep;
			e.prevDep = t.prevDep, t.prevDep && (t.prevDep.nextDep = e), t.prevDep = j.depsTail, t.nextDep = void 0, j.depsTail.nextDep = t, j.depsTail = t, j.deps === t && (j.deps = e);
		}
		return t;
	}
	trigger(e) {
		this.version++, Ze++, this.notify(e);
	}
	notify(e) {
		ze();
		try {
			for (let e = this.subs; e; e = e.prevSub) e.sub.notify() && e.sub.dep.notify();
		} finally {
			Be();
		}
	}
};
function et(e) {
	if (e.dep.sc++, e.sub.flags & 4) {
		let t = e.dep.computed;
		if (t && !e.dep.subs) {
			t.flags |= 20;
			for (let e = t.deps; e; e = e.nextDep) et(e);
		}
		let n = e.dep.subs;
		n !== e && (e.prevSub = n, n && (n.nextSub = e)), e.dep.subs = e;
	}
}
var tt = /* @__PURE__ */ new WeakMap(), nt = /* @__PURE__ */ Symbol(""), rt = /* @__PURE__ */ Symbol(""), it = /* @__PURE__ */ Symbol("");
function N(e, t, n) {
	if (M && j) {
		let t = tt.get(e);
		t || tt.set(e, t = /* @__PURE__ */ new Map());
		let r = t.get(n);
		r || (t.set(n, r = new $e()), r.map = t, r.key = n), r.track();
	}
}
function at(e, t, n, r, i, a) {
	let o = tt.get(e);
	if (!o) {
		Ze++;
		return;
	}
	let s = (e) => {
		e && e.trigger();
	};
	if (ze(), t === "clear") o.forEach(s);
	else {
		let i = _(e), a = i && ie(n);
		if (i && n === "length") {
			let e = Number(r);
			o.forEach((t, n) => {
				(n === "length" || n === it || !C(n) && n >= e) && s(t);
			});
		} else switch ((n !== void 0 || o.has(void 0)) && s(o.get(n)), a && s(o.get(it)), t) {
			case "add":
				i ? a && s(o.get("length")) : (s(o.get(nt)), v(e) && s(o.get(rt)));
				break;
			case "delete":
				i || (s(o.get(nt)), v(e) && s(o.get(rt)));
				break;
			case "set":
				v(e) && s(o.get(nt));
				break;
		}
	}
	Be();
}
function ot(e) {
	let t = /* @__PURE__ */ I(e);
	return t === e ? t : (N(t, "iterate", it), /* @__PURE__ */ F(e) ? t : t.map(L));
}
function st(e) {
	return N(e = /* @__PURE__ */ I(e), "iterate", it), e;
}
function P(e, t) {
	return /* @__PURE__ */ Ut(e) ? Kt(/* @__PURE__ */ Ht(e) ? L(t) : t) : L(t);
}
var ct = {
	__proto__: null,
	[Symbol.iterator]() {
		return lt(this, Symbol.iterator, (e) => P(this, e));
	},
	concat(...e) {
		return ot(this).concat(...e.map((e) => _(e) ? ot(e) : e));
	},
	entries() {
		return lt(this, "entries", (e) => (e[1] = P(this, e[1]), e));
	},
	every(e, t) {
		return dt(this, "every", e, t, void 0, arguments);
	},
	filter(e, t) {
		return dt(this, "filter", e, t, (e) => e.map((e) => P(this, e)), arguments);
	},
	find(e, t) {
		return dt(this, "find", e, t, (e) => P(this, e), arguments);
	},
	findIndex(e, t) {
		return dt(this, "findIndex", e, t, void 0, arguments);
	},
	findLast(e, t) {
		return dt(this, "findLast", e, t, (e) => P(this, e), arguments);
	},
	findLastIndex(e, t) {
		return dt(this, "findLastIndex", e, t, void 0, arguments);
	},
	forEach(e, t) {
		return dt(this, "forEach", e, t, void 0, arguments);
	},
	includes(...e) {
		return pt(this, "includes", e);
	},
	indexOf(...e) {
		return pt(this, "indexOf", e);
	},
	join(e) {
		return ot(this).join(e);
	},
	lastIndexOf(...e) {
		return pt(this, "lastIndexOf", e);
	},
	map(e, t) {
		return dt(this, "map", e, t, void 0, arguments);
	},
	pop() {
		return mt(this, "pop");
	},
	push(...e) {
		return mt(this, "push", e);
	},
	reduce(e, ...t) {
		return ft(this, "reduce", e, t);
	},
	reduceRight(e, ...t) {
		return ft(this, "reduceRight", e, t);
	},
	shift() {
		return mt(this, "shift");
	},
	some(e, t) {
		return dt(this, "some", e, t, void 0, arguments);
	},
	splice(...e) {
		return mt(this, "splice", e);
	},
	toReversed() {
		return ot(this).toReversed();
	},
	toSorted(e) {
		return ot(this).toSorted(e);
	},
	toSpliced(...e) {
		return ot(this).toSpliced(...e);
	},
	unshift(...e) {
		return mt(this, "unshift", e);
	},
	values() {
		return lt(this, "values", (e) => P(this, e));
	}
};
function lt(e, t, n) {
	let r = st(e), i = r[t]();
	return r !== e && !/* @__PURE__ */ F(e) && (i._next = i.next, i.next = () => {
		let e = i._next();
		return e.done || (e.value = n(e.value)), e;
	}), i;
}
var ut = Array.prototype;
function dt(e, t, n, r, i, a) {
	let o = st(e), s = o !== e && !/* @__PURE__ */ F(e), c = o[t];
	if (c !== ut[t]) {
		let t = c.apply(e, a);
		return s ? L(t) : t;
	}
	let l = n;
	o !== e && (s ? l = function(t, r) {
		return n.call(this, P(e, t), r, e);
	} : n.length > 2 && (l = function(t, r) {
		return n.call(this, t, r, e);
	}));
	let u = c.call(o, l, r);
	return s && i ? i(u) : u;
}
function ft(e, t, n, r) {
	let i = st(e), a = i !== e && !/* @__PURE__ */ F(e), o = n, s = !1;
	i !== e && (a ? (s = r.length === 0, o = function(t, r, i) {
		return s && (s = !1, t = P(e, t)), n.call(this, t, P(e, r), i, e);
	}) : n.length > 3 && (o = function(t, r, i) {
		return n.call(this, t, r, i, e);
	}));
	let c = i[t](o, ...r);
	return s ? P(e, c) : c;
}
function pt(e, t, n) {
	let r = /* @__PURE__ */ I(e);
	N(r, "iterate", it);
	let i = r[t](...n);
	return (i === -1 || i === !1) && /* @__PURE__ */ Wt(n[0]) ? (n[0] = /* @__PURE__ */ I(n[0]), r[t](...n)) : i;
}
function mt(e, t, n = []) {
	Je(), ze();
	let r = (/* @__PURE__ */ I(e))[t].apply(e, n);
	return Be(), Ye(), r;
}
var ht = /* @__PURE__ */ o("__proto__,__v_isRef,__isVue"), gt = new Set(/* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((e) => e !== "arguments" && e !== "caller").map((e) => Symbol[e]).filter(C));
function _t(e) {
	C(e) || (e = String(e));
	let t = /* @__PURE__ */ I(this);
	return N(t, "has", e), t.hasOwnProperty(e);
}
var vt = class {
	constructor(e = !1, t = !1) {
		this._isReadonly = e, this._isShallow = t;
	}
	get(e, t, n) {
		if (t === "__v_skip") return e.__v_skip;
		let r = this._isReadonly, i = this._isShallow;
		if (t === "__v_isReactive") return !r;
		if (t === "__v_isReadonly") return r;
		if (t === "__v_isShallow") return i;
		if (t === "__v_raw") return n === (r ? i ? It : Ft : i ? Pt : Nt).get(e) || Object.getPrototypeOf(e) === Object.getPrototypeOf(n) ? e : void 0;
		let a = _(e);
		if (!r) {
			let e;
			if (a && (e = ct[t])) return e;
			if (t === "hasOwnProperty") return _t;
		}
		let o = Reflect.get(e, t, /* @__PURE__ */ R(e) ? e : n);
		if ((C(t) ? gt.has(t) : ht(t)) || (r || N(e, "get", t), i)) return o;
		if (/* @__PURE__ */ R(o)) {
			let e = a && ie(t) ? o : o.value;
			return r && w(e) ? /* @__PURE__ */ Bt(e) : e;
		}
		return w(o) ? r ? /* @__PURE__ */ Bt(o) : /* @__PURE__ */ Rt(o) : o;
	}
}, yt = class extends vt {
	constructor(e = !1) {
		super(!1, e);
	}
	set(e, t, n, r) {
		let i = e[t], a = _(e) && ie(t);
		if (!this._isShallow) {
			let e = /* @__PURE__ */ Ut(i);
			if (!/* @__PURE__ */ F(n) && !/* @__PURE__ */ Ut(n) && (i = /* @__PURE__ */ I(i), n = /* @__PURE__ */ I(n)), !a && /* @__PURE__ */ R(i) && !/* @__PURE__ */ R(n)) return e || (i.value = n), !0;
		}
		let o = a ? Number(t) < e.length : g(e, t), s = Reflect.set(e, t, n, /* @__PURE__ */ R(e) ? e : r);
		return e === /* @__PURE__ */ I(r) && (o ? O(n, i) && at(e, "set", t, n, i) : at(e, "add", t, n)), s;
	}
	deleteProperty(e, t) {
		let n = g(e, t), r = e[t], i = Reflect.deleteProperty(e, t);
		return i && n && at(e, "delete", t, void 0, r), i;
	}
	has(e, t) {
		let n = Reflect.has(e, t);
		return (!C(t) || !gt.has(t)) && N(e, "has", t), n;
	}
	ownKeys(e) {
		return N(e, "iterate", _(e) ? "length" : nt), Reflect.ownKeys(e);
	}
}, bt = class extends vt {
	constructor(e = !1) {
		super(!0, e);
	}
	set(e, t) {
		return !0;
	}
	deleteProperty(e, t) {
		return !0;
	}
}, xt = /* @__PURE__ */ new yt(), St = /* @__PURE__ */ new bt(), Ct = /* @__PURE__ */ new yt(!0), wt = (e) => e, Tt = (e) => Reflect.getPrototypeOf(e);
function Et(e, t, n) {
	return function(...r) {
		let i = this.__v_raw, a = /* @__PURE__ */ I(i), o = v(a), s = e === "entries" || e === Symbol.iterator && o, c = e === "keys" && o, l = i[e](...r), u = n ? wt : t ? Kt : L;
		return !t && N(a, "iterate", c ? rt : nt), p(Object.create(l), { next() {
			let { value: e, done: t } = l.next();
			return t ? {
				value: e,
				done: t
			} : {
				value: s ? [u(e[0]), u(e[1])] : u(e),
				done: t
			};
		} });
	};
}
function Dt(e) {
	return function(...t) {
		return e === "delete" ? !1 : e === "clear" ? void 0 : this;
	};
}
function Ot(e, t) {
	let n = {
		get(n) {
			let r = this.__v_raw, i = /* @__PURE__ */ I(r), a = /* @__PURE__ */ I(n);
			e || (O(n, a) && N(i, "get", n), N(i, "get", a));
			let { has: o } = Tt(i), s = t ? wt : e ? Kt : L;
			if (o.call(i, n)) return s(r.get(n));
			if (o.call(i, a)) return s(r.get(a));
			r !== i && r.get(n);
		},
		get size() {
			let t = this.__v_raw;
			return !e && N(/* @__PURE__ */ I(t), "iterate", nt), t.size;
		},
		has(t) {
			let n = this.__v_raw, r = /* @__PURE__ */ I(n), i = /* @__PURE__ */ I(t);
			return e || (O(t, i) && N(r, "has", t), N(r, "has", i)), t === i ? n.has(t) : n.has(t) || n.has(i);
		},
		forEach(n, r) {
			let i = this, a = i.__v_raw, o = /* @__PURE__ */ I(a), s = t ? wt : e ? Kt : L;
			return !e && N(o, "iterate", nt), a.forEach((e, t) => n.call(r, s(e), s(t), i));
		}
	};
	return p(n, e ? {
		add: Dt("add"),
		set: Dt("set"),
		delete: Dt("delete"),
		clear: Dt("clear")
	} : {
		add(e) {
			let n = /* @__PURE__ */ I(this), r = Tt(n), i = /* @__PURE__ */ I(e), a = !t && !/* @__PURE__ */ F(e) && !/* @__PURE__ */ Ut(e) ? i : e;
			return r.has.call(n, a) || O(e, a) && r.has.call(n, e) || O(i, a) && r.has.call(n, i) || (n.add(a), at(n, "add", a, a)), this;
		},
		set(e, n) {
			!t && !/* @__PURE__ */ F(n) && !/* @__PURE__ */ Ut(n) && (n = /* @__PURE__ */ I(n));
			let r = /* @__PURE__ */ I(this), { has: i, get: a } = Tt(r), o = i.call(r, e);
			o ||= (e = /* @__PURE__ */ I(e), i.call(r, e));
			let s = a.call(r, e);
			return r.set(e, n), o ? O(n, s) && at(r, "set", e, n, s) : at(r, "add", e, n), this;
		},
		delete(e) {
			let t = /* @__PURE__ */ I(this), { has: n, get: r } = Tt(t), i = n.call(t, e);
			i ||= (e = /* @__PURE__ */ I(e), n.call(t, e));
			let a = r ? r.call(t, e) : void 0, o = t.delete(e);
			return i && at(t, "delete", e, void 0, a), o;
		},
		clear() {
			let e = /* @__PURE__ */ I(this), t = e.size !== 0, n = e.clear();
			return t && at(e, "clear", void 0, void 0, void 0), n;
		}
	}), [
		"keys",
		"values",
		"entries",
		Symbol.iterator
	].forEach((r) => {
		n[r] = Et(r, e, t);
	}), n;
}
function kt(e, t) {
	let n = Ot(e, t);
	return (t, r, i) => r === "__v_isReactive" ? !e : r === "__v_isReadonly" ? e : r === "__v_raw" ? t : Reflect.get(g(n, r) && r in t ? n : t, r, i);
}
var At = { get: /* @__PURE__ */ kt(!1, !1) }, jt = { get: /* @__PURE__ */ kt(!1, !0) }, Mt = { get: /* @__PURE__ */ kt(!0, !1) }, Nt = /* @__PURE__ */ new WeakMap(), Pt = /* @__PURE__ */ new WeakMap(), Ft = /* @__PURE__ */ new WeakMap(), It = /* @__PURE__ */ new WeakMap();
function Lt(e) {
	switch (e) {
		case "Object":
		case "Array": return 1;
		case "Map":
		case "Set":
		case "WeakMap":
		case "WeakSet": return 2;
		default: return 0;
	}
}
// @__NO_SIDE_EFFECTS__
function Rt(e) {
	return /* @__PURE__ */ Ut(e) ? e : Vt(e, !1, xt, At, Nt);
}
// @__NO_SIDE_EFFECTS__
function zt(e) {
	return Vt(e, !1, Ct, jt, Pt);
}
// @__NO_SIDE_EFFECTS__
function Bt(e) {
	return Vt(e, !0, St, Mt, Ft);
}
function Vt(e, t, n, r, i) {
	if (!w(e) || e.__v_raw && !(t && e.__v_isReactive) || e.__v_skip || !Object.isExtensible(e)) return e;
	let a = i.get(e);
	if (a) return a;
	let o = Lt(ne(e));
	if (o === 0) return e;
	let s = new Proxy(e, o === 2 ? r : n);
	return i.set(e, s), s;
}
// @__NO_SIDE_EFFECTS__
function Ht(e) {
	return /* @__PURE__ */ Ut(e) ? /* @__PURE__ */ Ht(e.__v_raw) : !!(e && e.__v_isReactive);
}
// @__NO_SIDE_EFFECTS__
function Ut(e) {
	return !!(e && e.__v_isReadonly);
}
// @__NO_SIDE_EFFECTS__
function F(e) {
	return !!(e && e.__v_isShallow);
}
// @__NO_SIDE_EFFECTS__
function Wt(e) {
	return e ? !!e.__v_raw : !1;
}
// @__NO_SIDE_EFFECTS__
function I(e) {
	let t = e && e.__v_raw;
	return t ? /* @__PURE__ */ I(t) : e;
}
function Gt(e) {
	return !g(e, "__v_skip") && Object.isExtensible(e) && fe(e, "__v_skip", !0), e;
}
var L = (e) => w(e) ? /* @__PURE__ */ Rt(e) : e, Kt = (e) => w(e) ? /* @__PURE__ */ Bt(e) : e;
// @__NO_SIDE_EFFECTS__
function R(e) {
	return e ? e.__v_isRef === !0 : !1;
}
// @__NO_SIDE_EFFECTS__
function qt(e) {
	return Jt(e, !1);
}
function Jt(e, t) {
	return /* @__PURE__ */ R(e) ? e : new Yt(e, t);
}
var Yt = class {
	constructor(e, t) {
		this.dep = new $e(), this.__v_isRef = !0, this.__v_isShallow = !1, this._rawValue = t ? e : /* @__PURE__ */ I(e), this._value = t ? e : L(e), this.__v_isShallow = t;
	}
	get value() {
		return this.dep.track(), this._value;
	}
	set value(e) {
		let t = this._rawValue, n = this.__v_isShallow || /* @__PURE__ */ F(e) || /* @__PURE__ */ Ut(e);
		e = n ? e : /* @__PURE__ */ I(e), O(e, t) && (this._rawValue = e, this._value = n ? e : L(e), this.dep.trigger());
	}
};
function Xt(e) {
	return /* @__PURE__ */ R(e) ? e.value : e;
}
var Zt = {
	get: (e, t, n) => t === "__v_raw" ? e : Xt(Reflect.get(e, t, n)),
	set: (e, t, n, r) => {
		let i = e[t];
		return /* @__PURE__ */ R(i) && !/* @__PURE__ */ R(n) ? (i.value = n, !0) : Reflect.set(e, t, n, r);
	}
};
function Qt(e) {
	return /* @__PURE__ */ Ht(e) ? e : new Proxy(e, Zt);
}
var $t = class {
	constructor(e, t, n) {
		this.fn = e, this.setter = t, this._value = void 0, this.dep = new $e(this), this.__v_isRef = !0, this.deps = void 0, this.depsTail = void 0, this.flags = 16, this.globalVersion = Ze - 1, this.next = void 0, this.effect = this, this.__v_isReadonly = !t, this.isSSR = n;
	}
	notify() {
		if (this.flags |= 16, !(this.flags & 8) && j !== this) return Re(this, !0), !0;
	}
	get value() {
		let e = this.dep.track();
		return We(this), e && (e.version = this.dep.version), this._value;
	}
	set value(e) {
		this.setter && this.setter(e);
	}
};
// @__NO_SIDE_EFFECTS__
function en(e, t, n = !1) {
	let r, i;
	return x(e) ? r = e : (r = e.get, i = e.set), new $t(r, i, n);
}
var tn = {}, nn = /* @__PURE__ */ new WeakMap(), rn = void 0;
function an(e, t = !1, n = rn) {
	if (n) {
		let t = nn.get(n);
		t || nn.set(n, t = []), t.push(e);
	}
}
function on(e, t, n = s) {
	let { immediate: r, deep: i, once: a, scheduler: o, augmentJob: c, call: u } = n, d = (e) => i ? e : /* @__PURE__ */ F(e) || i === !1 || i === 0 ? sn(e, 1) : sn(e), f, p, h, g, v = !1, y = !1;
	if (/* @__PURE__ */ R(e) ? (p = () => e.value, v = /* @__PURE__ */ F(e)) : /* @__PURE__ */ Ht(e) ? (p = () => d(e), v = !0) : _(e) ? (y = !0, v = e.some((e) => /* @__PURE__ */ Ht(e) || /* @__PURE__ */ F(e)), p = () => e.map((e) => {
		if (/* @__PURE__ */ R(e)) return e.value;
		if (/* @__PURE__ */ Ht(e)) return d(e);
		if (x(e)) return u ? u(e, 2) : e();
	})) : p = x(e) ? t ? u ? () => u(e, 2) : e : () => {
		if (h) {
			Je();
			try {
				h();
			} finally {
				Ye();
			}
		}
		let t = rn;
		rn = f;
		try {
			return u ? u(e, 3, [g]) : e(g);
		} finally {
			rn = t;
		}
	} : l, t && i) {
		let e = p, t = i === !0 ? Infinity : i;
		p = () => sn(e(), t);
	}
	let b = Me(), S = () => {
		f.stop(), b && b.active && m(b.effects, f);
	};
	if (a && t) {
		let e = t;
		t = (...t) => {
			let n = e(...t);
			return S(), n;
		};
	}
	let C = y ? Array(e.length).fill(tn) : tn, w = (e) => {
		if (!(!(f.flags & 1) || !f.dirty && !e)) if (t) {
			let n = f.run();
			if (e || i || v || (y ? n.some((e, t) => O(e, C[t])) : O(n, C))) {
				h && h();
				let e = rn;
				rn = f;
				try {
					let e = [
						n,
						C === tn ? void 0 : y && C[0] === tn ? [] : C,
						g
					];
					C = n, u ? u(t, 3, e) : t(...e);
				} finally {
					rn = e;
				}
			}
		} else f.run();
	};
	return c && c(w), f = new Pe(p), f.scheduler = o ? () => o(w, !1) : w, g = (e) => an(e, !1, f), h = f.onStop = () => {
		let e = nn.get(f);
		if (e) {
			if (u) u(e, 4);
			else for (let t of e) t();
			nn.delete(f);
		}
	}, t ? r ? w(!0) : C = f.run() : o ? o(w.bind(null, !0), !0) : f.run(), S.pause = f.pause.bind(f), S.resume = f.resume.bind(f), S.stop = S, S;
}
function sn(e, t = Infinity, n) {
	if (t <= 0 || !w(e) || e.__v_skip || (n ||= /* @__PURE__ */ new Map(), (n.get(e) || 0) >= t)) return e;
	if (n.set(e, t), t--, /* @__PURE__ */ R(e)) sn(e.value, t, n);
	else if (_(e)) for (let r = 0; r < e.length; r++) sn(e[r], t, n);
	else if (y(e) || v(e)) e.forEach((e) => {
		sn(e, t, n);
	});
	else if (re(e)) {
		for (let r in e) sn(e[r], t, n);
		for (let r of Object.getOwnPropertySymbols(e)) Object.prototype.propertyIsEnumerable.call(e, r) && sn(e[r], t, n);
	}
	return e;
}
//#endregion
//#region node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
function cn(e, t, n, r) {
	try {
		return r ? e(...r) : e();
	} catch (e) {
		ln(e, t, n);
	}
}
function z(e, t, n, r) {
	if (x(e)) {
		let i = cn(e, t, n, r);
		return i && ee(i) && i.catch((e) => {
			ln(e, t, n);
		}), i;
	}
	if (_(e)) {
		let i = [];
		for (let a = 0; a < e.length; a++) i.push(z(e[a], t, n, r));
		return i;
	}
}
function ln(e, t, n, r = !0) {
	let i = t ? t.vnode : null, { errorHandler: a, throwUnhandledErrorInProduction: o } = t && t.appContext.config || s;
	if (t) {
		let r = t.parent, i = t.proxy, o = `https://vuejs.org/error-reference/#runtime-${n}`;
		for (; r;) {
			let t = r.ec;
			if (t) {
				for (let n = 0; n < t.length; n++) if (t[n](e, i, o) === !1) return;
			}
			r = r.parent;
		}
		if (a) {
			Je(), cn(a, null, 10, [
				e,
				i,
				o
			]), Ye();
			return;
		}
	}
	un(e, n, i, r, o);
}
function un(e, t, n, r = !0, i = !1) {
	if (i) throw e;
	console.error(e);
}
var B = [], V = -1, dn = [], fn = null, pn = 0, mn = /* @__PURE__ */ Promise.resolve(), hn = null;
function gn(e) {
	let t = hn || mn;
	return e ? t.then(this ? e.bind(this) : e) : t;
}
function _n(e) {
	let t = V + 1, n = B.length;
	for (; t < n;) {
		let r = t + n >>> 1, i = B[r], a = Cn(i);
		a < e || a === e && i.flags & 2 ? t = r + 1 : n = r;
	}
	return t;
}
function vn(e) {
	if (!(e.flags & 1)) {
		let t = Cn(e), n = B[B.length - 1];
		!n || !(e.flags & 2) && t >= Cn(n) ? B.push(e) : B.splice(_n(t), 0, e), e.flags |= 1, yn();
	}
}
function yn() {
	hn ||= mn.then(wn);
}
function bn(e) {
	_(e) ? dn.push(...e) : fn && e.id === -1 ? fn.splice(pn + 1, 0, e) : e.flags & 1 || (dn.push(e), e.flags |= 1), yn();
}
function xn(e, t, n = V + 1) {
	for (; n < B.length; n++) {
		let t = B[n];
		if (t && t.flags & 2) {
			if (e && t.id !== e.uid) continue;
			B.splice(n, 1), n--, t.flags & 4 && (t.flags &= -2), t(), t.flags & 4 || (t.flags &= -2);
		}
	}
}
function Sn(e) {
	if (dn.length) {
		let e = [...new Set(dn)].sort((e, t) => Cn(e) - Cn(t));
		if (dn.length = 0, fn) {
			fn.push(...e);
			return;
		}
		for (fn = e, pn = 0; pn < fn.length; pn++) {
			let e = fn[pn];
			e.flags & 4 && (e.flags &= -2), e.flags & 8 || e(), e.flags &= -2;
		}
		fn = null, pn = 0;
	}
}
var Cn = (e) => e.id == null ? e.flags & 2 ? -1 : Infinity : e.id;
function wn(e) {
	try {
		for (V = 0; V < B.length; V++) {
			let e = B[V];
			e && !(e.flags & 8) && (e.flags & 4 && (e.flags &= -2), cn(e, e.i, e.i ? 15 : 14), e.flags & 4 || (e.flags &= -2));
		}
	} finally {
		for (; V < B.length; V++) {
			let e = B[V];
			e && (e.flags &= -2);
		}
		V = -1, B.length = 0, Sn(e), hn = null, (B.length || dn.length) && wn(e);
	}
}
var H = null, Tn = null;
function En(e) {
	let t = H;
	return H = e, Tn = e && e.type.__scopeId || null, t;
}
function Dn(e, t = H, n) {
	if (!t || e._n) return e;
	let r = (...n) => {
		r._d && Mi(-1);
		let i = En(t), a;
		try {
			a = e(...n);
		} finally {
			En(i), r._d && Mi(1);
		}
		return a;
	};
	return r._n = !0, r._c = !0, r._d = !0, r;
}
function On(e, t, n, r) {
	let i = e.dirs, a = t && t.dirs;
	for (let o = 0; o < i.length; o++) {
		let s = i[o];
		a && (s.oldValue = a[o].value);
		let c = s.dir[r];
		c && (Je(), z(c, n, 8, [
			e.el,
			s,
			e,
			t
		]), Ye());
	}
}
function kn(e, t) {
	if (X) {
		let n = X.provides, r = X.parent && X.parent.provides;
		r === n && (n = X.provides = Object.create(r)), n[e] = t;
	}
}
function An(e, t, n = !1) {
	let r = Qi();
	if (r || Fr) {
		let i = Fr ? Fr._context.provides : r ? r.parent == null || r.ce ? r.vnode.appContext && r.vnode.appContext.provides : r.parent.provides : void 0;
		if (i && e in i) return i[e];
		if (arguments.length > 1) return n && x(t) ? t.call(r && r.proxy) : t;
	}
}
var jn = /* @__PURE__ */ Symbol.for("v-scx"), Mn = () => An(jn);
function Nn(e, t, n) {
	return Pn(e, t, n);
}
function Pn(e, t, n = s) {
	let { immediate: r, deep: i, flush: a, once: o } = n, c = p({}, n), u = t && r || !t && a !== "post", d;
	if (ia) {
		if (a === "sync") {
			let e = Mn();
			d = e.__watcherHandles ||= [];
		} else if (!u) {
			let e = () => {};
			return e.stop = l, e.resume = l, e.pause = l, e;
		}
	}
	let f = X;
	c.call = (e, t, n) => z(e, f, t, n);
	let m = !1;
	a === "post" ? c.scheduler = (e) => {
		W(e, f && f.suspense);
	} : a !== "sync" && (m = !0, c.scheduler = (e, t) => {
		t ? e() : vn(e);
	}), c.augmentJob = (e) => {
		t && (e.flags |= 4), m && (e.flags |= 2, f && (e.id = f.uid, e.i = f));
	};
	let h = on(e, t, c);
	return ia && (d ? d.push(h) : u && h()), h;
}
function Fn(e, t, n) {
	let r = this.proxy, i = S(e) ? e.includes(".") ? In(r, e) : () => r[e] : e.bind(r, r), a;
	x(t) ? a = t : (a = t.handler, n = t);
	let o = ta(this), s = Pn(i, a.bind(r), n);
	return o(), s;
}
function In(e, t) {
	let n = t.split(".");
	return () => {
		let t = e;
		for (let e = 0; e < n.length && t; e++) t = t[n[e]];
		return t;
	};
}
var Ln = /* @__PURE__ */ Symbol("_vte"), Rn = (e) => e.__isTeleport, zn = /* @__PURE__ */ Symbol("_leaveCb");
function Bn(e, t) {
	e.shapeFlag & 6 && e.component ? (e.transition = t, Bn(e.component.subTree, t)) : e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t;
}
// @__NO_SIDE_EFFECTS__
function Vn(e, t) {
	return x(e) ? /* @__PURE__ */ p({ name: e.name }, t, { setup: e }) : e;
}
function Hn(e) {
	e.ids = [
		e.ids[0] + e.ids[2]++ + "-",
		0,
		0
	];
}
function Un(e, t) {
	let n;
	return !!((n = Object.getOwnPropertyDescriptor(e, t)) && !n.configurable);
}
var Wn = /* @__PURE__ */ new WeakMap();
function Gn(e, t, n, r, i = !1) {
	if (_(e)) {
		e.forEach((e, a) => Gn(e, t && (_(t) ? t[a] : t), n, r, i));
		return;
	}
	if (qn(r) && !i) {
		r.shapeFlag & 512 && r.type.__asyncResolved && r.component.subTree.component && Gn(e, t, n, r.component.subTree);
		return;
	}
	let a = r.shapeFlag & 4 ? pa(r.component) : r.el, o = i ? null : a, { i: c, r: l } = e, d = t && t.r, f = c.refs === s ? c.refs = {} : c.refs, p = c.setupState, h = /* @__PURE__ */ I(p), v = p === s ? u : (e) => Un(f, e) ? !1 : g(h, e), y = (e, t) => !(t && Un(f, t));
	if (d != null && d !== l) {
		if (Kn(t), S(d)) f[d] = null, v(d) && (p[d] = null);
		else if (/* @__PURE__ */ R(d)) {
			let e = t;
			y(d, e.k) && (d.value = null), e.k && (f[e.k] = null);
		}
	}
	if (x(l)) cn(l, c, 12, [o, f]);
	else {
		let t = S(l), r = /* @__PURE__ */ R(l);
		if (t || r) {
			let s = () => {
				if (e.f) {
					let n = t ? v(l) ? p[l] : f[l] : y(l) || !e.k ? l.value : f[e.k];
					if (i) _(n) && m(n, a);
					else if (_(n)) n.includes(a) || n.push(a);
					else if (t) f[l] = [a], v(l) && (p[l] = f[l]);
					else {
						let t = [a];
						y(l, e.k) && (l.value = t), e.k && (f[e.k] = t);
					}
				} else t ? (f[l] = o, v(l) && (p[l] = o)) : r && (y(l, e.k) && (l.value = o), e.k && (f[e.k] = o));
			};
			if (o) {
				let t = () => {
					s(), Wn.delete(e);
				};
				t.id = -1, Wn.set(e, t), W(t, n);
			} else Kn(e), s();
		}
	}
}
function Kn(e) {
	let t = Wn.get(e);
	t && (t.flags |= 8, Wn.delete(e));
}
he().requestIdleCallback, he().cancelIdleCallback;
var qn = (e) => !!e.type.__asyncLoader, Jn = (e) => e.type.__isKeepAlive;
function Yn(e, t) {
	Zn(e, "a", t);
}
function Xn(e, t) {
	Zn(e, "da", t);
}
function Zn(e, t, n = X) {
	let r = e.__wdc ||= () => {
		let t = n;
		for (; t;) {
			if (t.isDeactivated) return;
			t = t.parent;
		}
		return e();
	};
	if ($n(t, r, n), n) {
		let e = n.parent;
		for (; e && e.parent;) Jn(e.parent.vnode) && Qn(r, t, n, e), e = e.parent;
	}
}
function Qn(e, t, n, r) {
	let i = $n(t, e, r, !0);
	or(() => {
		m(r[t], i);
	}, n);
}
function $n(e, t, n = X, r = !1) {
	if (n) {
		let i = n[e] || (n[e] = []), a = t.__weh ||= (...r) => {
			Je();
			let i = ta(n), a = z(t, n, e, r);
			return i(), Ye(), a;
		};
		return r ? i.unshift(a) : i.push(a), a;
	}
}
var er = (e) => (t, n = X) => {
	(!ia || e === "sp") && $n(e, (...e) => t(...e), n);
}, tr = er("bm"), nr = er("m"), rr = er("bu"), ir = er("u"), ar = er("bum"), or = er("um"), sr = er("sp"), cr = er("rtg"), lr = er("rtc");
function ur(e, t = X) {
	$n("ec", e, t);
}
var dr = /* @__PURE__ */ Symbol.for("v-ndc");
function fr(e, t, n, r) {
	let i, a = n && n[r], o = _(e);
	if (o || S(e)) {
		let n = o && /* @__PURE__ */ Ht(e), r = !1, s = !1;
		n && (r = !/* @__PURE__ */ F(e), s = /* @__PURE__ */ Ut(e), e = st(e)), i = Array(e.length);
		for (let n = 0, o = e.length; n < o; n++) i[n] = t(r ? s ? Kt(L(e[n])) : L(e[n]) : e[n], n, void 0, a && a[n]);
	} else if (typeof e == "number") {
		i = Array(e);
		for (let n = 0; n < e; n++) i[n] = t(n + 1, n, void 0, a && a[n]);
	} else if (w(e)) if (e[Symbol.iterator]) i = Array.from(e, (e, n) => t(e, n, void 0, a && a[n]));
	else {
		let n = Object.keys(e);
		i = Array(n.length);
		for (let r = 0, o = n.length; r < o; r++) {
			let o = n[r];
			i[r] = t(e[o], o, r, a && a[r]);
		}
	}
	else i = [];
	return n && (n[r] = i), i;
}
var pr = (e) => e ? ra(e) ? pa(e) : pr(e.parent) : null, mr = /* @__PURE__ */ p(/* @__PURE__ */ Object.create(null), {
	$: (e) => e,
	$el: (e) => e.vnode.el,
	$data: (e) => e.data,
	$props: (e) => e.props,
	$attrs: (e) => e.attrs,
	$slots: (e) => e.slots,
	$refs: (e) => e.refs,
	$parent: (e) => pr(e.parent),
	$root: (e) => pr(e.root),
	$host: (e) => e.ce,
	$emit: (e) => e.emit,
	$options: (e) => Cr(e),
	$forceUpdate: (e) => e.f ||= () => {
		vn(e.update);
	},
	$nextTick: (e) => e.n ||= gn.bind(e.proxy),
	$watch: (e) => Fn.bind(e)
}), hr = (e, t) => e !== s && !e.__isScriptSetup && g(e, t), gr = {
	get({ _: e }, t) {
		if (t === "__v_skip") return !0;
		let { ctx: n, setupState: r, data: i, props: a, accessCache: o, type: c, appContext: l } = e;
		if (t[0] !== "$") {
			let e = o[t];
			if (e !== void 0) switch (e) {
				case 1: return r[t];
				case 2: return i[t];
				case 4: return n[t];
				case 3: return a[t];
			}
			else if (hr(r, t)) return o[t] = 1, r[t];
			else if (i !== s && g(i, t)) return o[t] = 2, i[t];
			else if (g(a, t)) return o[t] = 3, a[t];
			else if (n !== s && g(n, t)) return o[t] = 4, n[t];
			else vr && (o[t] = 0);
		}
		let u = mr[t], d, f;
		if (u) return t === "$attrs" && N(e.attrs, "get", ""), u(e);
		if ((d = c.__cssModules) && (d = d[t])) return d;
		if (n !== s && g(n, t)) return o[t] = 4, n[t];
		if (f = l.config.globalProperties, g(f, t)) return f[t];
	},
	set({ _: e }, t, n) {
		let { data: r, setupState: i, ctx: a } = e;
		return hr(i, t) ? (i[t] = n, !0) : r !== s && g(r, t) ? (r[t] = n, !0) : g(e.props, t) || t[0] === "$" && t.slice(1) in e ? !1 : (a[t] = n, !0);
	},
	has({ _: { data: e, setupState: t, accessCache: n, ctx: r, appContext: i, props: a, type: o } }, c) {
		let l;
		return !!(n[c] || e !== s && c[0] !== "$" && g(e, c) || hr(t, c) || g(a, c) || g(r, c) || g(mr, c) || g(i.config.globalProperties, c) || (l = o.__cssModules) && l[c]);
	},
	defineProperty(e, t, n) {
		return n.get == null ? g(n, "value") && this.set(e, t, n.value, null) : e._.accessCache[t] = 0, Reflect.defineProperty(e, t, n);
	}
};
function _r(e) {
	return _(e) ? e.reduce((e, t) => (e[t] = null, e), {}) : e;
}
var vr = !0;
function yr(e) {
	let t = Cr(e), n = e.proxy, r = e.ctx;
	vr = !1, t.beforeCreate && xr(t.beforeCreate, e, "bc");
	let { data: i, computed: a, methods: o, watch: s, provide: c, inject: u, created: d, beforeMount: f, mounted: p, beforeUpdate: m, updated: h, activated: g, deactivated: v, beforeDestroy: y, beforeUnmount: b, destroyed: S, unmounted: C, render: ee, renderTracked: te, renderTriggered: T, errorCaptured: ne, serverPrefetch: re, expose: ie, inheritAttrs: ae, components: oe, directives: se, filters: E } = t;
	if (u && br(u, r, null), o) for (let e in o) {
		let t = o[e];
		x(t) && (r[e] = t.bind(n));
	}
	if (i) {
		let t = i.call(n, n);
		w(t) && (e.data = /* @__PURE__ */ Rt(t));
	}
	if (vr = !0, a) for (let e in a) {
		let t = a[e], i = ha({
			get: x(t) ? t.bind(n, n) : x(t.get) ? t.get.bind(n, n) : l,
			set: !x(t) && x(t.set) ? t.set.bind(n) : l
		});
		Object.defineProperty(r, e, {
			enumerable: !0,
			configurable: !0,
			get: () => i.value,
			set: (e) => i.value = e
		});
	}
	if (s) for (let e in s) Sr(s[e], r, n, e);
	if (c) {
		let e = x(c) ? c.call(n) : c;
		Reflect.ownKeys(e).forEach((t) => {
			kn(t, e[t]);
		});
	}
	d && xr(d, e, "c");
	function D(e, t) {
		_(t) ? t.forEach((t) => e(t.bind(n))) : t && e(t.bind(n));
	}
	if (D(tr, f), D(nr, p), D(rr, m), D(ir, h), D(Yn, g), D(Xn, v), D(ur, ne), D(lr, te), D(cr, T), D(ar, b), D(or, C), D(sr, re), _(ie)) if (ie.length) {
		let t = e.exposed ||= {};
		ie.forEach((e) => {
			Object.defineProperty(t, e, {
				get: () => n[e],
				set: (t) => n[e] = t,
				enumerable: !0
			});
		});
	} else e.exposed ||= {};
	ee && e.render === l && (e.render = ee), ae != null && (e.inheritAttrs = ae), oe && (e.components = oe), se && (e.directives = se), re && Hn(e);
}
function br(e, t, n = l) {
	_(e) && (e = Or(e));
	for (let n in e) {
		let r = e[n], i;
		i = w(r) ? "default" in r ? An(r.from || n, r.default, !0) : An(r.from || n) : An(r), /* @__PURE__ */ R(i) ? Object.defineProperty(t, n, {
			enumerable: !0,
			configurable: !0,
			get: () => i.value,
			set: (e) => i.value = e
		}) : t[n] = i;
	}
}
function xr(e, t, n) {
	z(_(e) ? e.map((e) => e.bind(t.proxy)) : e.bind(t.proxy), t, n);
}
function Sr(e, t, n, r) {
	let i = r.includes(".") ? In(n, r) : () => n[r];
	if (S(e)) {
		let n = t[e];
		x(n) && Nn(i, n);
	} else if (x(e)) Nn(i, e.bind(n));
	else if (w(e)) if (_(e)) e.forEach((e) => Sr(e, t, n, r));
	else {
		let r = x(e.handler) ? e.handler.bind(n) : t[e.handler];
		x(r) && Nn(i, r, e);
	}
}
function Cr(e) {
	let t = e.type, { mixins: n, extends: r } = t, { mixins: i, optionsCache: a, config: { optionMergeStrategies: o } } = e.appContext, s = a.get(t), c;
	return s ? c = s : !i.length && !n && !r ? c = t : (c = {}, i.length && i.forEach((e) => wr(c, e, o, !0)), wr(c, t, o)), w(t) && a.set(t, c), c;
}
function wr(e, t, n, r = !1) {
	let { mixins: i, extends: a } = t;
	a && wr(e, a, n, !0), i && i.forEach((t) => wr(e, t, n, !0));
	for (let i in t) if (!(r && i === "expose")) {
		let r = Tr[i] || n && n[i];
		e[i] = r ? r(e[i], t[i]) : t[i];
	}
	return e;
}
var Tr = {
	data: Er,
	props: Ar,
	emits: Ar,
	methods: kr,
	computed: kr,
	beforeCreate: U,
	created: U,
	beforeMount: U,
	mounted: U,
	beforeUpdate: U,
	updated: U,
	beforeDestroy: U,
	beforeUnmount: U,
	destroyed: U,
	unmounted: U,
	activated: U,
	deactivated: U,
	errorCaptured: U,
	serverPrefetch: U,
	components: kr,
	directives: kr,
	watch: jr,
	provide: Er,
	inject: Dr
};
function Er(e, t) {
	return t ? e ? function() {
		return p(x(e) ? e.call(this, this) : e, x(t) ? t.call(this, this) : t);
	} : t : e;
}
function Dr(e, t) {
	return kr(Or(e), Or(t));
}
function Or(e) {
	if (_(e)) {
		let t = {};
		for (let n = 0; n < e.length; n++) t[e[n]] = e[n];
		return t;
	}
	return e;
}
function U(e, t) {
	return e ? [...new Set([].concat(e, t))] : t;
}
function kr(e, t) {
	return e ? p(/* @__PURE__ */ Object.create(null), e, t) : t;
}
function Ar(e, t) {
	return e ? _(e) && _(t) ? [.../* @__PURE__ */ new Set([...e, ...t])] : p(/* @__PURE__ */ Object.create(null), _r(e), _r(t ?? {})) : t;
}
function jr(e, t) {
	if (!e) return t;
	if (!t) return e;
	let n = p(/* @__PURE__ */ Object.create(null), e);
	for (let r in t) n[r] = U(e[r], t[r]);
	return n;
}
function Mr() {
	return {
		app: null,
		config: {
			isNativeTag: u,
			performance: !1,
			globalProperties: {},
			optionMergeStrategies: {},
			errorHandler: void 0,
			warnHandler: void 0,
			compilerOptions: {}
		},
		mixins: [],
		components: {},
		directives: {},
		provides: /* @__PURE__ */ Object.create(null),
		optionsCache: /* @__PURE__ */ new WeakMap(),
		propsCache: /* @__PURE__ */ new WeakMap(),
		emitsCache: /* @__PURE__ */ new WeakMap()
	};
}
var Nr = 0;
function Pr(e, t) {
	return function(n, r = null) {
		x(n) || (n = p({}, n)), r != null && !w(r) && (r = null);
		let i = Mr(), a = /* @__PURE__ */ new WeakSet(), o = [], s = !1, c = i.app = {
			_uid: Nr++,
			_component: n,
			_props: r,
			_container: null,
			_context: i,
			_instance: null,
			version: ga,
			get config() {
				return i.config;
			},
			set config(e) {},
			use(e, ...t) {
				return a.has(e) || (e && x(e.install) ? (a.add(e), e.install(c, ...t)) : x(e) && (a.add(e), e(c, ...t))), c;
			},
			mixin(e) {
				return i.mixins.includes(e) || i.mixins.push(e), c;
			},
			component(e, t) {
				return t ? (i.components[e] = t, c) : i.components[e];
			},
			directive(e, t) {
				return t ? (i.directives[e] = t, c) : i.directives[e];
			},
			mount(a, o, l) {
				if (!s) {
					let u = c._ceVNode || Bi(n, r);
					return u.appContext = i, l === !0 ? l = "svg" : l === !1 && (l = void 0), o && t ? t(u, a) : e(u, a, l), s = !0, c._container = a, a.__vue_app__ = c, pa(u.component);
				}
			},
			onUnmount(e) {
				o.push(e);
			},
			unmount() {
				s && (z(o, c._instance, 16), e(null, c._container), delete c._container.__vue_app__);
			},
			provide(e, t) {
				return i.provides[e] = t, c;
			},
			runWithContext(e) {
				let t = Fr;
				Fr = c;
				try {
					return e();
				} finally {
					Fr = t;
				}
			}
		};
		return c;
	};
}
var Fr = null, Ir = (e, t) => t === "modelValue" || t === "model-value" ? e.modelModifiers : e[`${t}Modifiers`] || e[`${E(t)}Modifiers`] || e[`${ce(t)}Modifiers`];
function Lr(e, t, ...n) {
	if (e.isUnmounted) return;
	let r = e.vnode.props || s, i = n, a = t.startsWith("update:"), o = a && Ir(r, t.slice(7));
	o && (o.trim && (i = n.map((e) => S(e) ? e.trim() : e)), o.number && (i = n.map(pe)));
	let c, l = r[c = ue(t)] || r[c = ue(E(t))];
	!l && a && (l = r[c = ue(ce(t))]), l && z(l, e, 6, i);
	let u = r[c + "Once"];
	if (u) {
		if (!e.emitted) e.emitted = {};
		else if (e.emitted[c]) return;
		e.emitted[c] = !0, z(u, e, 6, i);
	}
}
var Rr = /* @__PURE__ */ new WeakMap();
function zr(e, t, n = !1) {
	let r = n ? Rr : t.emitsCache, i = r.get(e);
	if (i !== void 0) return i;
	let a = e.emits, o = {}, s = !1;
	if (!x(e)) {
		let r = (e) => {
			let n = zr(e, t, !0);
			n && (s = !0, p(o, n));
		};
		!n && t.mixins.length && t.mixins.forEach(r), e.extends && r(e.extends), e.mixins && e.mixins.forEach(r);
	}
	return !a && !s ? (w(e) && r.set(e, null), null) : (_(a) ? a.forEach((e) => o[e] = null) : p(o, a), w(e) && r.set(e, o), o);
}
function Br(e, t) {
	return !e || !d(t) ? !1 : (t = t.slice(2).replace(/Once$/, ""), g(e, t[0].toLowerCase() + t.slice(1)) || g(e, ce(t)) || g(e, t));
}
function Vr(e) {
	let { type: t, vnode: n, proxy: r, withProxy: i, propsOptions: [a], slots: o, attrs: s, emit: c, render: l, renderCache: u, props: d, data: p, setupState: m, ctx: h, inheritAttrs: g } = e, _ = En(e), v, y;
	try {
		if (n.shapeFlag & 4) {
			let e = i || r, t = e;
			v = J(l.call(t, e, u, d, m, p, h)), y = s;
		} else {
			let e = t;
			v = J(e.length > 1 ? e(d, {
				attrs: s,
				slots: o,
				emit: c
			}) : e(d, null)), y = t.props ? s : Hr(s);
		}
	} catch (t) {
		Oi.length = 0, ln(t, e, 1), v = Bi(Ei);
	}
	let b = v;
	if (y && g !== !1) {
		let e = Object.keys(y), { shapeFlag: t } = b;
		e.length && t & 7 && (a && e.some(f) && (y = Ur(y, a)), b = Ui(b, y, !1, !0));
	}
	return n.dirs && (b = Ui(b, null, !1, !0), b.dirs = b.dirs ? b.dirs.concat(n.dirs) : n.dirs), n.transition && Bn(b, n.transition), v = b, En(_), v;
}
var Hr = (e) => {
	let t;
	for (let n in e) (n === "class" || n === "style" || d(n)) && ((t ||= {})[n] = e[n]);
	return t;
}, Ur = (e, t) => {
	let n = {};
	for (let r in e) (!f(r) || !(r.slice(9) in t)) && (n[r] = e[r]);
	return n;
};
function Wr(e, t, n) {
	let { props: r, children: i, component: a } = e, { props: o, children: s, patchFlag: c } = t, l = a.emitsOptions;
	if (t.dirs || t.transition) return !0;
	if (n && c >= 0) {
		if (c & 1024) return !0;
		if (c & 16) return r ? Gr(r, o, l) : !!o;
		if (c & 8) {
			let e = t.dynamicProps;
			for (let t = 0; t < e.length; t++) {
				let n = e[t];
				if (Kr(o, r, n) && !Br(l, n)) return !0;
			}
		}
	} else return (i || s) && (!s || !s.$stable) ? !0 : r === o ? !1 : r ? o ? Gr(r, o, l) : !0 : !!o;
	return !1;
}
function Gr(e, t, n) {
	let r = Object.keys(t);
	if (r.length !== Object.keys(e).length) return !0;
	for (let i = 0; i < r.length; i++) {
		let a = r[i];
		if (Kr(t, e, a) && !Br(n, a)) return !0;
	}
	return !1;
}
function Kr(e, t, n) {
	let r = e[n], i = t[n];
	return n === "style" && w(r) && w(i) ? !Ee(r, i) : r !== i;
}
function qr({ vnode: e, parent: t, suspense: n }, r) {
	for (; t;) {
		let n = t.subTree;
		if (n.suspense && n.suspense.activeBranch === e && (n.suspense.vnode.el = n.el = r, e = n), n === e) (e = t.vnode).el = r, t = t.parent;
		else break;
	}
	n && n.activeBranch === e && (n.vnode.el = r);
}
var Jr = {}, Yr = () => Object.create(Jr), Xr = (e) => Object.getPrototypeOf(e) === Jr;
function Zr(e, t, n, r = !1) {
	let i = {}, a = Yr();
	e.propsDefaults = /* @__PURE__ */ Object.create(null), $r(e, t, i, a);
	for (let t in e.propsOptions[0]) t in i || (i[t] = void 0);
	n ? e.props = r ? i : /* @__PURE__ */ zt(i) : e.type.props ? e.props = i : e.props = a, e.attrs = a;
}
function Qr(e, t, n, r) {
	let { props: i, attrs: a, vnode: { patchFlag: o } } = e, s = /* @__PURE__ */ I(i), [c] = e.propsOptions, l = !1;
	if ((r || o > 0) && !(o & 16)) {
		if (o & 8) {
			let n = e.vnode.dynamicProps;
			for (let r = 0; r < n.length; r++) {
				let o = n[r];
				if (Br(e.emitsOptions, o)) continue;
				let u = t[o];
				if (c) if (g(a, o)) u !== a[o] && (a[o] = u, l = !0);
				else {
					let t = E(o);
					i[t] = ei(c, s, t, u, e, !1);
				}
				else u !== a[o] && (a[o] = u, l = !0);
			}
		}
	} else {
		$r(e, t, i, a) && (l = !0);
		let r;
		for (let a in s) (!t || !g(t, a) && ((r = ce(a)) === a || !g(t, r))) && (c ? n && (n[a] !== void 0 || n[r] !== void 0) && (i[a] = ei(c, s, a, void 0, e, !0)) : delete i[a]);
		if (a !== s) for (let e in a) (!t || !g(t, e)) && (delete a[e], l = !0);
	}
	l && at(e.attrs, "set", "");
}
function $r(e, t, n, r) {
	let [i, a] = e.propsOptions, o = !1, c;
	if (t) for (let s in t) {
		if (ae(s)) continue;
		let l = t[s], u;
		i && g(i, u = E(s)) ? !a || !a.includes(u) ? n[u] = l : (c ||= {})[u] = l : Br(e.emitsOptions, s) || (!(s in r) || l !== r[s]) && (r[s] = l, o = !0);
	}
	if (a) {
		let t = /* @__PURE__ */ I(n), r = c || s;
		for (let o = 0; o < a.length; o++) {
			let s = a[o];
			n[s] = ei(i, t, s, r[s], e, !g(r, s));
		}
	}
	return o;
}
function ei(e, t, n, r, i, a) {
	let o = e[n];
	if (o != null) {
		let e = g(o, "default");
		if (e && r === void 0) {
			let e = o.default;
			if (o.type !== Function && !o.skipFactory && x(e)) {
				let { propsDefaults: a } = i;
				if (n in a) r = a[n];
				else {
					let o = ta(i);
					r = a[n] = e.call(null, t), o();
				}
			} else r = e;
			i.ce && i.ce._setProp(n, r);
		}
		o[0] && (a && !e ? r = !1 : o[1] && (r === "" || r === ce(n)) && (r = !0));
	}
	return r;
}
var ti = /* @__PURE__ */ new WeakMap();
function ni(e, t, n = !1) {
	let r = n ? ti : t.propsCache, i = r.get(e);
	if (i) return i;
	let a = e.props, o = {}, l = [], u = !1;
	if (!x(e)) {
		let r = (e) => {
			u = !0;
			let [n, r] = ni(e, t, !0);
			p(o, n), r && l.push(...r);
		};
		!n && t.mixins.length && t.mixins.forEach(r), e.extends && r(e.extends), e.mixins && e.mixins.forEach(r);
	}
	if (!a && !u) return w(e) && r.set(e, c), c;
	if (_(a)) for (let e = 0; e < a.length; e++) {
		let t = E(a[e]);
		ri(t) && (o[t] = s);
	}
	else if (a) for (let e in a) {
		let t = E(e);
		if (ri(t)) {
			let n = a[e], r = o[t] = _(n) || x(n) ? { type: n } : p({}, n), i = r.type, s = !1, c = !0;
			if (_(i)) for (let e = 0; e < i.length; ++e) {
				let t = i[e], n = x(t) && t.name;
				if (n === "Boolean") {
					s = !0;
					break;
				} else n === "String" && (c = !1);
			}
			else s = x(i) && i.name === "Boolean";
			r[0] = s, r[1] = c, (s || g(r, "default")) && l.push(t);
		}
	}
	let d = [o, l];
	return w(e) && r.set(e, d), d;
}
function ri(e) {
	return e[0] !== "$" && !ae(e);
}
var ii = (e) => e === "_" || e === "_ctx" || e === "$stable", ai = (e) => _(e) ? e.map(J) : [J(e)], oi = (e, t, n) => {
	if (t._n) return t;
	let r = Dn((...e) => ai(t(...e)), n);
	return r._c = !1, r;
}, si = (e, t, n) => {
	let r = e._ctx;
	for (let n in e) {
		if (ii(n)) continue;
		let i = e[n];
		if (x(i)) t[n] = oi(n, i, r);
		else if (i != null) {
			let e = ai(i);
			t[n] = () => e;
		}
	}
}, ci = (e, t) => {
	let n = ai(t);
	e.slots.default = () => n;
}, li = (e, t, n) => {
	for (let r in t) (n || !ii(r)) && (e[r] = t[r]);
}, di = (e, t, n) => {
	let r = e.slots = Yr();
	if (e.vnode.shapeFlag & 32) {
		let e = t._;
		e ? (li(r, t, n), n && fe(r, "_", e, !0)) : si(t, r);
	} else t && ci(e, t);
}, fi = (e, t, n) => {
	let { vnode: r, slots: i } = e, a = !0, o = s;
	if (r.shapeFlag & 32) {
		let e = t._;
		e ? n && e === 1 ? a = !1 : li(i, t, n) : (a = !t.$stable, si(t, i)), o = t;
	} else t && (ci(e, t), o = { default: 1 });
	if (a) for (let e in i) !ii(e) && o[e] == null && delete i[e];
}, W = wi;
function pi(e) {
	return mi(e);
}
function mi(e, t) {
	let n = he();
	n.__VUE__ = !0;
	let { insert: r, remove: i, patchProp: a, createElement: o, createText: u, createComment: d, setText: f, setElementText: p, parentNode: m, nextSibling: h, setScopeId: g = l, insertStaticContent: _ } = e, v = (e, t, n, r = null, i = null, a = null, o = void 0, s = null, c = !!t.dynamicChildren) => {
		if (e === t) return;
		e && !Li(e, t) && (r = be(e), me(e, i, a, !0), e = null), t.patchFlag === -2 && (c = !1, t.dynamicChildren = null);
		let { type: l, ref: u, shapeFlag: d } = t;
		switch (l) {
			case Ti:
				y(e, t, n, r);
				break;
			case Ei:
				b(e, t, n, r);
				break;
			case Di:
				e ?? x(t, n, r, o);
				break;
			case G:
				oe(e, t, n, r, i, a, o, s, c);
				break;
			default: d & 1 ? w(e, t, n, r, i, a, o, s, c) : d & 6 ? se(e, t, n, r, i, a, o, s, c) : (d & 64 || d & 128) && l.process(e, t, n, r, i, a, o, s, c, Ce);
		}
		u != null && i ? Gn(u, e && e.ref, a, t || e, !t) : u == null && e && e.ref != null && Gn(e.ref, null, a, e, !0);
	}, y = (e, t, n, i) => {
		if (e == null) r(t.el = u(t.children), n, i);
		else {
			let n = t.el = e.el;
			t.children !== e.children && f(n, t.children);
		}
	}, b = (e, t, n, i) => {
		e == null ? r(t.el = d(t.children || ""), n, i) : t.el = e.el;
	}, x = (e, t, n, r) => {
		[e.el, e.anchor] = _(e.children, t, n, r, e.el, e.anchor);
	}, S = ({ el: e, anchor: t }, n, i) => {
		let a;
		for (; e && e !== t;) a = h(e), r(e, n, i), e = a;
		r(t, n, i);
	}, C = ({ el: e, anchor: t }) => {
		let n;
		for (; e && e !== t;) n = h(e), i(e), e = n;
		i(t);
	}, w = (e, t, n, r, i, a, o, s, c) => {
		if (t.type === "svg" ? o = "svg" : t.type === "math" && (o = "mathml"), e == null) ee(t, n, r, i, a, o, s, c);
		else {
			let n = e.el && e.el._isVueCE ? e.el : null;
			try {
				n && n._beginPatch(), ne(e, t, i, a, o, s, c);
			} finally {
				n && n._endPatch();
			}
		}
	}, ee = (e, t, n, i, s, c, l, u) => {
		let d, f, { props: m, shapeFlag: h, transition: g, dirs: _ } = e;
		if (d = e.el = o(e.type, c, m && m.is, m), h & 8 ? p(d, e.children) : h & 16 && T(e.children, d, null, i, s, hi(e, c), l, u), _ && On(e, null, i, "created"), te(d, e, e.scopeId, l, i), m) {
			for (let e in m) e !== "value" && !ae(e) && a(d, e, null, m[e], c, i);
			"value" in m && a(d, "value", null, m.value, c), (f = m.onVnodeBeforeMount) && Y(f, i, e);
		}
		_ && On(e, null, i, "beforeMount");
		let v = _i(s, g);
		v && g.beforeEnter(d), r(d, t, n), ((f = m && m.onVnodeMounted) || v || _) && W(() => {
			try {
				f && Y(f, i, e), v && g.enter(d), _ && On(e, null, i, "mounted");
			} finally {}
		}, s);
	}, te = (e, t, n, r, i) => {
		if (n && g(e, n), r) for (let t = 0; t < r.length; t++) g(e, r[t]);
		if (i) {
			let n = i.subTree;
			if (t === n || Ci(n.type) && (n.ssContent === t || n.ssFallback === t)) {
				let t = i.vnode;
				te(e, t, t.scopeId, t.slotScopeIds, i.parent);
			}
		}
	}, T = (e, t, n, r, i, a, o, s, c = 0) => {
		for (let l = c; l < e.length; l++) v(null, e[l] = s ? Ki(e[l]) : J(e[l]), t, n, r, i, a, o, s);
	}, ne = (e, t, n, r, i, o, c) => {
		let l = t.el = e.el, { patchFlag: u, dynamicChildren: d, dirs: f } = t;
		u |= e.patchFlag & 16;
		let m = e.props || s, h = t.props || s, g;
		if (n && gi(n, !1), (g = h.onVnodeBeforeUpdate) && Y(g, n, t, e), f && On(t, e, n, "beforeUpdate"), n && gi(n, !0), (m.innerHTML && h.innerHTML == null || m.textContent && h.textContent == null) && p(l, ""), d ? re(e.dynamicChildren, d, l, n, r, hi(t, i), o) : c || ue(e, t, l, null, n, r, hi(t, i), o, !1), u > 0) {
			if (u & 16) ie(l, m, h, n, i);
			else if (u & 2 && m.class !== h.class && a(l, "class", null, h.class, i), u & 4 && a(l, "style", m.style, h.style, i), u & 8) {
				let e = t.dynamicProps;
				for (let t = 0; t < e.length; t++) {
					let r = e[t], o = m[r], s = h[r];
					(s !== o || r === "value") && a(l, r, o, s, i, n);
				}
			}
			u & 1 && e.children !== t.children && p(l, t.children);
		} else !c && d == null && ie(l, m, h, n, i);
		((g = h.onVnodeUpdated) || f) && W(() => {
			g && Y(g, n, t, e), f && On(t, e, n, "updated");
		}, r);
	}, re = (e, t, n, r, i, a, o) => {
		for (let s = 0; s < t.length; s++) {
			let c = e[s], l = t[s];
			v(c, l, c.el && (c.type === G || !Li(c, l) || c.shapeFlag & 198) ? m(c.el) : n, null, r, i, a, o, !0);
		}
	}, ie = (e, t, n, r, i) => {
		if (t !== n) {
			if (t !== s) for (let o in t) !ae(o) && !(o in n) && a(e, o, t[o], null, i, r);
			for (let o in n) {
				if (ae(o)) continue;
				let s = n[o], c = t[o];
				s !== c && o !== "value" && a(e, o, c, s, i, r);
			}
			"value" in n && a(e, "value", t.value, n.value, i);
		}
	}, oe = (e, t, n, i, a, o, s, c, l) => {
		let d = t.el = e ? e.el : u(""), f = t.anchor = e ? e.anchor : u(""), { patchFlag: p, dynamicChildren: m, slotScopeIds: h } = t;
		h && (c = c ? c.concat(h) : h), e == null ? (r(d, n, i), r(f, n, i), T(t.children || [], n, f, a, o, s, c, l)) : p > 0 && p & 64 && m && e.dynamicChildren && e.dynamicChildren.length === m.length ? (re(e.dynamicChildren, m, n, a, o, s, c), (t.key != null || a && t === a.subTree) && vi(e, t, !0)) : ue(e, t, n, f, a, o, s, c, l);
	}, se = (e, t, n, r, i, a, o, s, c) => {
		t.slotScopeIds = s, e == null ? t.shapeFlag & 512 ? i.ctx.activate(t, n, r, o, c) : E(t, n, r, i, a, o, c) : D(e, t, c);
	}, E = (e, t, n, r, i, a, o) => {
		let s = e.component = Zi(e, r, i);
		if (Jn(e) && (s.ctx.renderer = Ce), aa(s, !1, o), s.asyncDep) {
			if (i && i.registerDep(s, ce, o), !e.el) {
				let r = s.subTree = Bi(Ei);
				b(null, r, t, n), e.placeholder = r.el;
			}
		} else ce(s, e, t, n, i, a, o);
	}, D = (e, t, n) => {
		let r = t.component = e.component;
		if (Wr(e, t, n)) if (r.asyncDep && !r.asyncResolved) {
			le(r, t, n);
			return;
		} else r.next = t, r.update();
		else t.el = e.el, r.vnode = t;
	}, ce = (e, t, n, r, i, a, o) => {
		let s = () => {
			if (e.isMounted) {
				let { next: t, bu: n, u: r, parent: s, vnode: c } = e;
				{
					let n = bi(e);
					if (n) {
						t && (t.el = c.el, le(e, t, o)), n.asyncDep.then(() => {
							W(() => {
								e.isUnmounted || l();
							}, i);
						});
						return;
					}
				}
				let u = t, d;
				gi(e, !1), t ? (t.el = c.el, le(e, t, o)) : t = c, n && de(n), (d = t.props && t.props.onVnodeBeforeUpdate) && Y(d, s, t, c), gi(e, !0);
				let f = Vr(e), p = e.subTree;
				e.subTree = f, v(p, f, m(p.el), be(p), e, i, a), t.el = f.el, u === null && qr(e, f.el), r && W(r, i), (d = t.props && t.props.onVnodeUpdated) && W(() => Y(d, s, t, c), i);
			} else {
				let o, { el: s, props: c } = t, { bm: l, m: u, parent: d, root: f, type: p } = e, m = qn(t);
				if (gi(e, !1), l && de(l), !m && (o = c && c.onVnodeBeforeMount) && Y(o, d, t), gi(e, !0), s && Te) {
					let t = () => {
						e.subTree = Vr(e), Te(s, e.subTree, e, i, null);
					};
					m && p.__asyncHydrate ? p.__asyncHydrate(s, e, t) : t();
				} else {
					f.ce && f.ce._hasShadowRoot() && f.ce._injectChildStyle(p, e.parent ? e.parent.type : void 0);
					let o = e.subTree = Vr(e);
					v(null, o, n, r, e, i, a), t.el = o.el;
				}
				if (u && W(u, i), !m && (o = c && c.onVnodeMounted)) {
					let e = t;
					W(() => Y(o, d, e), i);
				}
				(t.shapeFlag & 256 || d && qn(d.vnode) && d.vnode.shapeFlag & 256) && e.a && W(e.a, i), e.isMounted = !0, t = n = r = null;
			}
		};
		e.scope.on();
		let c = e.effect = new Pe(s);
		e.scope.off();
		let l = e.update = c.run.bind(c), u = e.job = c.runIfDirty.bind(c);
		u.i = e, u.id = e.uid, c.scheduler = () => vn(u), gi(e, !0), l();
	}, le = (e, t, n) => {
		t.component = e;
		let r = e.vnode.props;
		e.vnode = t, e.next = null, Qr(e, t.props, r, n), fi(e, t.children, n), Je(), xn(e), Ye();
	}, ue = (e, t, n, r, i, a, o, s, c = !1) => {
		let l = e && e.children, u = e ? e.shapeFlag : 0, d = t.children, { patchFlag: f, shapeFlag: m } = t;
		if (f > 0) {
			if (f & 128) {
				fe(l, d, n, r, i, a, o, s, c);
				return;
			} else if (f & 256) {
				O(l, d, n, r, i, a, o, s, c);
				return;
			}
		}
		m & 8 ? (u & 16 && ye(l, i, a), d !== l && p(n, d)) : u & 16 ? m & 16 ? fe(l, d, n, r, i, a, o, s, c) : ye(l, i, a, !0) : (u & 8 && p(n, ""), m & 16 && T(d, n, r, i, a, o, s, c));
	}, O = (e, t, n, r, i, a, o, s, l) => {
		e ||= c, t ||= c;
		let u = e.length, d = t.length, f = Math.min(u, d), p;
		for (p = 0; p < f; p++) {
			let r = t[p] = l ? Ki(t[p]) : J(t[p]);
			v(e[p], r, n, null, i, a, o, s, l);
		}
		u > d ? ye(e, i, a, !0, !1, f) : T(t, n, r, i, a, o, s, l, f);
	}, fe = (e, t, n, r, i, a, o, s, l) => {
		let u = 0, d = t.length, f = e.length - 1, p = d - 1;
		for (; u <= f && u <= p;) {
			let r = e[u], c = t[u] = l ? Ki(t[u]) : J(t[u]);
			if (Li(r, c)) v(r, c, n, null, i, a, o, s, l);
			else break;
			u++;
		}
		for (; u <= f && u <= p;) {
			let r = e[f], c = t[p] = l ? Ki(t[p]) : J(t[p]);
			if (Li(r, c)) v(r, c, n, null, i, a, o, s, l);
			else break;
			f--, p--;
		}
		if (u > f) {
			if (u <= p) {
				let e = p + 1, c = e < d ? t[e].el : r;
				for (; u <= p;) v(null, t[u] = l ? Ki(t[u]) : J(t[u]), n, c, i, a, o, s, l), u++;
			}
		} else if (u > p) for (; u <= f;) me(e[u], i, a, !0), u++;
		else {
			let m = u, h = u, g = /* @__PURE__ */ new Map();
			for (u = h; u <= p; u++) {
				let e = t[u] = l ? Ki(t[u]) : J(t[u]);
				e.key != null && g.set(e.key, u);
			}
			let _, y = 0, b = p - h + 1, x = !1, S = 0, C = Array(b);
			for (u = 0; u < b; u++) C[u] = 0;
			for (u = m; u <= f; u++) {
				let r = e[u];
				if (y >= b) {
					me(r, i, a, !0);
					continue;
				}
				let c;
				if (r.key != null) c = g.get(r.key);
				else for (_ = h; _ <= p; _++) if (C[_ - h] === 0 && Li(r, t[_])) {
					c = _;
					break;
				}
				c === void 0 ? me(r, i, a, !0) : (C[c - h] = u + 1, c >= S ? S = c : x = !0, v(r, t[c], n, null, i, a, o, s, l), y++);
			}
			let w = x ? yi(C) : c;
			for (_ = w.length - 1, u = b - 1; u >= 0; u--) {
				let e = h + u, c = t[e], f = t[e + 1], p = e + 1 < d ? f.el || Si(f) : r;
				C[u] === 0 ? v(null, c, n, p, i, a, o, s, l) : x && (_ < 0 || u !== w[_] ? pe(c, n, p, 2) : _--);
			}
		}
	}, pe = (e, t, n, a, o = null) => {
		let { el: s, type: c, transition: l, children: u, shapeFlag: d } = e;
		if (d & 6) {
			pe(e.component.subTree, t, n, a);
			return;
		}
		if (d & 128) {
			e.suspense.move(t, n, a);
			return;
		}
		if (d & 64) {
			c.move(e, t, n, Ce);
			return;
		}
		if (c === G) {
			r(s, t, n);
			for (let e = 0; e < u.length; e++) pe(u[e], t, n, a);
			r(e.anchor, t, n);
			return;
		}
		if (c === Di) {
			S(e, t, n);
			return;
		}
		if (a !== 2 && d & 1 && l) if (a === 0) l.persisted && !s[zn] ? r(s, t, n) : (l.beforeEnter(s), r(s, t, n), W(() => l.enter(s), o));
		else {
			let { leave: a, delayLeave: o, afterLeave: c } = l, u = () => {
				e.ctx.isUnmounted ? i(s) : r(s, t, n);
			}, d = () => {
				let e = s._isLeaving || !!s[zn];
				s._isLeaving && s[zn](!0), l.persisted && !e ? u() : a(s, () => {
					u(), c && c();
				});
			};
			o ? o(s, u, d) : d();
		}
		else r(s, t, n);
	}, me = (e, t, n, r = !1, i = !1) => {
		let { type: a, props: o, ref: s, children: c, dynamicChildren: l, shapeFlag: u, patchFlag: d, dirs: f, cacheIndex: p, memo: m } = e;
		if (d === -2 && (i = !1), s != null && (Je(), Gn(s, null, n, e, !0), Ye()), p != null && (t.renderCache[p] = void 0), u & 256) {
			t.ctx.deactivate(e);
			return;
		}
		let h = u & 1 && f, g = !qn(e), _;
		if (g && (_ = o && o.onVnodeBeforeUnmount) && Y(_, t, e), u & 6) ve(e.component, n, r);
		else {
			if (u & 128) {
				e.suspense.unmount(n, r);
				return;
			}
			h && On(e, null, t, "beforeUnmount"), u & 64 ? e.type.remove(e, t, n, Ce, r) : l && !l.hasOnce && (a !== G || d > 0 && d & 64) ? ye(l, t, n, !1, !0) : (a === G && d & 384 || !i && u & 16) && ye(c, t, n), r && ge(e);
		}
		let v = m != null && p == null;
		(g && (_ = o && o.onVnodeUnmounted) || h || v) && W(() => {
			_ && Y(_, t, e), h && On(e, null, t, "unmounted"), v && (e.el = null);
		}, n);
	}, ge = (e) => {
		let { type: t, el: n, anchor: r, transition: a } = e;
		if (t === G) {
			_e(n, r);
			return;
		}
		if (t === Di) {
			C(e);
			return;
		}
		let o = () => {
			i(n), a && !a.persisted && a.afterLeave && a.afterLeave();
		};
		if (e.shapeFlag & 1 && a && !a.persisted) {
			let { leave: t, delayLeave: r } = a, i = () => t(n, o);
			r ? r(e.el, o, i) : i();
		} else o();
	}, _e = (e, t) => {
		let n;
		for (; e !== t;) n = h(e), i(e), e = n;
		i(t);
	}, ve = (e, t, n) => {
		let { bum: r, scope: i, job: a, subTree: o, um: s, m: c, a: l } = e;
		xi(c), xi(l), r && de(r), i.stop(), a && (a.flags |= 8, me(o, e, t, n)), s && W(s, t), W(() => {
			e.isUnmounted = !0;
		}, t);
	}, ye = (e, t, n, r = !1, i = !1, a = 0) => {
		for (let o = a; o < e.length; o++) me(e[o], t, n, r, i);
	}, be = (e) => {
		if (e.shapeFlag & 6) return be(e.component.subTree);
		if (e.shapeFlag & 128) return e.suspense.next();
		let t = h(e.anchor || e.el), n = t && t[Ln];
		return n ? h(n) : t;
	}, xe = !1, Se = (e, t, n) => {
		let r;
		e == null ? t._vnode && (me(t._vnode, null, null, !0), r = t._vnode.component) : v(t._vnode || null, e, t, null, null, null, n), t._vnode = e, xe ||= (xe = !0, xn(r), Sn(), !1);
	}, Ce = {
		p: v,
		um: me,
		m: pe,
		r: ge,
		mt: E,
		mc: T,
		pc: ue,
		pbc: re,
		n: be,
		o: e
	}, we, Te;
	return t && ([we, Te] = t(Ce)), {
		render: Se,
		hydrate: we,
		createApp: Pr(Se, we)
	};
}
function hi({ type: e, props: t }, n) {
	return n === "svg" && e === "foreignObject" || n === "mathml" && e === "annotation-xml" && t && t.encoding && t.encoding.includes("html") ? void 0 : n;
}
function gi({ effect: e, job: t }, n) {
	n ? (e.flags |= 32, t.flags |= 4) : (e.flags &= -33, t.flags &= -5);
}
function _i(e, t) {
	return (!e || e && !e.pendingBranch) && t && !t.persisted;
}
function vi(e, t, n = !1) {
	let r = e.children, i = t.children;
	if (_(r) && _(i)) for (let e = 0; e < r.length; e++) {
		let t = r[e], a = i[e];
		a.shapeFlag & 1 && !a.dynamicChildren && ((a.patchFlag <= 0 || a.patchFlag === 32) && (a = i[e] = Ki(i[e]), a.el = t.el), !n && a.patchFlag !== -2 && vi(t, a)), a.type === Ti && (a.patchFlag === -1 && (a = i[e] = Ki(a)), a.el = t.el), a.type === Ei && !a.el && (a.el = t.el);
	}
}
function yi(e) {
	let t = e.slice(), n = [0], r, i, a, o, s, c = e.length;
	for (r = 0; r < c; r++) {
		let c = e[r];
		if (c !== 0) {
			if (i = n[n.length - 1], e[i] < c) {
				t[r] = i, n.push(r);
				continue;
			}
			for (a = 0, o = n.length - 1; a < o;) s = a + o >> 1, e[n[s]] < c ? a = s + 1 : o = s;
			c < e[n[a]] && (a > 0 && (t[r] = n[a - 1]), n[a] = r);
		}
	}
	for (a = n.length, o = n[a - 1]; a-- > 0;) n[a] = o, o = t[o];
	return n;
}
function bi(e) {
	let t = e.subTree.component;
	if (t) return t.asyncDep && !t.asyncResolved ? t : bi(t);
}
function xi(e) {
	if (e) for (let t = 0; t < e.length; t++) e[t].flags |= 8;
}
function Si(e) {
	if (e.placeholder) return e.placeholder;
	let t = e.component;
	return t ? Si(t.subTree) : null;
}
var Ci = (e) => e.__isSuspense;
function wi(e, t) {
	t && t.pendingBranch ? _(e) ? t.effects.push(...e) : t.effects.push(e) : bn(e);
}
var G = /* @__PURE__ */ Symbol.for("v-fgt"), Ti = /* @__PURE__ */ Symbol.for("v-txt"), Ei = /* @__PURE__ */ Symbol.for("v-cmt"), Di = /* @__PURE__ */ Symbol.for("v-stc"), Oi = [], K = null;
function ki(e = !1) {
	Oi.push(K = e ? null : []);
}
function Ai() {
	Oi.pop(), K = Oi[Oi.length - 1] || null;
}
var ji = 1;
function Mi(e, t = !1) {
	ji += e, e < 0 && K && t && (K.hasOnce = !0);
}
function Ni(e) {
	return e.dynamicChildren = ji > 0 ? K || c : null, Ai(), ji > 0 && K && K.push(e), e;
}
function Pi(e, t, n, r, i, a) {
	return Ni(q(e, t, n, r, i, a, !0));
}
function Fi(e, t, n, r, i) {
	return Ni(Bi(e, t, n, r, i, !0));
}
function Ii(e) {
	return e ? e.__v_isVNode === !0 : !1;
}
function Li(e, t) {
	return e.type === t.type && e.key === t.key;
}
var Ri = ({ key: e }) => e ?? null, zi = ({ ref: e, ref_key: t, ref_for: n }) => (typeof e == "number" && (e = "" + e), e == null ? null : S(e) || /* @__PURE__ */ R(e) || x(e) ? {
	i: H,
	r: e,
	k: t,
	f: !!n
} : e);
function q(e, t = null, n = null, r = 0, i = null, a = e === G ? 0 : 1, o = !1, s = !1) {
	let c = {
		__v_isVNode: !0,
		__v_skip: !0,
		type: e,
		props: t,
		key: t && Ri(t),
		ref: t && zi(t),
		scopeId: Tn,
		slotScopeIds: null,
		children: n,
		component: null,
		suspense: null,
		ssContent: null,
		ssFallback: null,
		dirs: null,
		transition: null,
		el: null,
		anchor: null,
		target: null,
		targetStart: null,
		targetAnchor: null,
		staticCount: 0,
		shapeFlag: a,
		patchFlag: r,
		dynamicProps: i,
		dynamicChildren: null,
		appContext: null,
		ctx: H
	};
	return s ? (qi(c, n), a & 128 && e.normalize(c)) : n && (c.shapeFlag |= S(n) ? 8 : 16), ji > 0 && !o && K && (c.patchFlag > 0 || a & 6) && c.patchFlag !== 32 && K.push(c), c;
}
var Bi = Vi;
function Vi(e, t = null, n = null, r = 0, i = null, a = !1) {
	if ((!e || e === dr) && (e = Ei), Ii(e)) {
		let r = Ui(e, t, !0);
		return n && qi(r, n), ji > 0 && !a && K && (r.shapeFlag & 6 ? K[K.indexOf(e)] = r : K.push(r)), r.patchFlag = -2, r;
	}
	if (ma(e) && (e = e.__vccOpts), t) {
		t = Hi(t);
		let { class: e, style: n } = t;
		e && !S(e) && (t.class = xe(e)), w(n) && (/* @__PURE__ */ Wt(n) && !_(n) && (n = p({}, n)), t.style = ge(n));
	}
	let o = S(e) ? 1 : Ci(e) ? 128 : Rn(e) ? 64 : w(e) ? 4 : x(e) ? 2 : 0;
	return q(e, t, n, r, i, o, a, !0);
}
function Hi(e) {
	return e ? /* @__PURE__ */ Wt(e) || Xr(e) ? p({}, e) : e : null;
}
function Ui(e, t, n = !1, r = !1) {
	let { props: i, ref: a, patchFlag: o, children: s, transition: c } = e, l = t ? Ji(i || {}, t) : i, u = {
		__v_isVNode: !0,
		__v_skip: !0,
		type: e.type,
		props: l,
		key: l && Ri(l),
		ref: t && t.ref ? n && a ? _(a) ? a.concat(zi(t)) : [a, zi(t)] : zi(t) : a,
		scopeId: e.scopeId,
		slotScopeIds: e.slotScopeIds,
		children: s,
		target: e.target,
		targetStart: e.targetStart,
		targetAnchor: e.targetAnchor,
		staticCount: e.staticCount,
		shapeFlag: e.shapeFlag,
		patchFlag: t && e.type !== G ? o === -1 ? 16 : o | 16 : o,
		dynamicProps: e.dynamicProps,
		dynamicChildren: e.dynamicChildren,
		appContext: e.appContext,
		dirs: e.dirs,
		transition: c,
		component: e.component,
		suspense: e.suspense,
		ssContent: e.ssContent && Ui(e.ssContent),
		ssFallback: e.ssFallback && Ui(e.ssFallback),
		placeholder: e.placeholder,
		el: e.el,
		anchor: e.anchor,
		ctx: e.ctx,
		ce: e.ce
	};
	return c && r && Bn(u, c.clone(u)), u;
}
function Wi(e = " ", t = 0) {
	return Bi(Ti, null, e, t);
}
function Gi(e = "", t = !1) {
	return t ? (ki(), Fi(Ei, null, e)) : Bi(Ei, null, e);
}
function J(e) {
	return e == null || typeof e == "boolean" ? Bi(Ei) : _(e) ? Bi(G, null, e.slice()) : Ii(e) ? Ki(e) : Bi(Ti, null, String(e));
}
function Ki(e) {
	return e.el === null && e.patchFlag !== -1 || e.memo ? e : Ui(e);
}
function qi(e, t) {
	let n = 0, { shapeFlag: r } = e;
	if (t == null) t = null;
	else if (_(t)) n = 16;
	else if (typeof t == "object") if (r & 65) {
		let n = t.default;
		n && (n._c && (n._d = !1), qi(e, n()), n._c && (n._d = !0));
		return;
	} else {
		n = 32;
		let r = t._;
		!r && !Xr(t) ? t._ctx = H : r === 3 && H && (H.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024));
	}
	else x(t) ? (t = {
		default: t,
		_ctx: H
	}, n = 32) : (t = String(t), r & 64 ? (n = 16, t = [Wi(t)]) : n = 8);
	e.children = t, e.shapeFlag |= n;
}
function Ji(...e) {
	let t = {};
	for (let n = 0; n < e.length; n++) {
		let r = e[n];
		for (let e in r) if (e === "class") t.class !== r.class && (t.class = xe([t.class, r.class]));
		else if (e === "style") t.style = ge([t.style, r.style]);
		else if (d(e)) {
			let n = t[e], i = r[e];
			i && n !== i && !(_(n) && n.includes(i)) ? t[e] = n ? [].concat(n, i) : i : i == null && n == null && !f(e) && (t[e] = i);
		} else e !== "" && (t[e] = r[e]);
	}
	return t;
}
function Y(e, t, n, r = null) {
	z(e, t, 7, [n, r]);
}
var Yi = Mr(), Xi = 0;
function Zi(e, t, n) {
	let r = e.type, i = (t ? t.appContext : e.appContext) || Yi, a = {
		uid: Xi++,
		vnode: e,
		type: r,
		parent: t,
		appContext: i,
		root: null,
		next: null,
		subTree: null,
		effect: null,
		update: null,
		job: null,
		scope: new Ae(!0),
		render: null,
		proxy: null,
		exposed: null,
		exposeProxy: null,
		withProxy: null,
		provides: t ? t.provides : Object.create(i.provides),
		ids: t ? t.ids : [
			"",
			0,
			0
		],
		accessCache: null,
		renderCache: [],
		components: null,
		directives: null,
		propsOptions: ni(r, i),
		emitsOptions: zr(r, i),
		emit: null,
		emitted: null,
		propsDefaults: s,
		inheritAttrs: r.inheritAttrs,
		ctx: s,
		data: s,
		props: s,
		attrs: s,
		slots: s,
		refs: s,
		setupState: s,
		setupContext: null,
		suspense: n,
		suspenseId: n ? n.pendingId : 0,
		asyncDep: null,
		asyncResolved: !1,
		isMounted: !1,
		isUnmounted: !1,
		isDeactivated: !1,
		bc: null,
		c: null,
		bm: null,
		m: null,
		bu: null,
		u: null,
		um: null,
		bum: null,
		da: null,
		a: null,
		rtg: null,
		rtc: null,
		ec: null,
		sp: null
	};
	return a.ctx = { _: a }, a.root = t ? t.root : a, a.emit = Lr.bind(null, a), e.ce && e.ce(a), a;
}
var X = null, Qi = () => X || H, $i, ea;
{
	let e = he(), t = (t, n) => {
		let r;
		return (r = e[t]) || (r = e[t] = []), r.push(n), (e) => {
			r.length > 1 ? r.forEach((t) => t(e)) : r[0](e);
		};
	};
	$i = t("__VUE_INSTANCE_SETTERS__", (e) => X = e), ea = t("__VUE_SSR_SETTERS__", (e) => ia = e);
}
var ta = (e) => {
	let t = X;
	return $i(e), e.scope.on(), () => {
		e.scope.off(), $i(t);
	};
}, na = () => {
	X && X.scope.off(), $i(null);
};
function ra(e) {
	return e.vnode.shapeFlag & 4;
}
var ia = !1;
function aa(e, t = !1, n = !1) {
	t && ea(t);
	let { props: r, children: i } = e.vnode, a = ra(e);
	Zr(e, r, a, t), di(e, i, n || t);
	let o = a ? oa(e, t) : void 0;
	return t && ea(!1), o;
}
function oa(e, t) {
	let n = e.type;
	e.accessCache = /* @__PURE__ */ Object.create(null), e.proxy = new Proxy(e.ctx, gr);
	let { setup: r } = n;
	if (r) {
		Je();
		let n = e.setupContext = r.length > 1 ? fa(e) : null, i = ta(e), a = cn(r, e, 0, [e.props, n]), o = ee(a);
		if (Ye(), i(), (o || e.sp) && !qn(e) && Hn(e), o) {
			if (a.then(na, na), t) return a.then((n) => {
				sa(e, n, t);
			}).catch((t) => {
				ln(t, e, 0);
			});
			e.asyncDep = a;
		} else sa(e, a, t);
	} else ua(e, t);
}
function sa(e, t, n) {
	x(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : w(t) && (e.setupState = Qt(t)), ua(e, n);
}
var ca, la;
function ua(e, t, n) {
	let r = e.type;
	if (!e.render) {
		if (!t && ca && !r.render) {
			let t = r.template || Cr(e).template;
			if (t) {
				let { isCustomElement: n, compilerOptions: i } = e.appContext.config, { delimiters: a, compilerOptions: o } = r;
				r.render = ca(t, p(p({
					isCustomElement: n,
					delimiters: a
				}, i), o));
			}
		}
		e.render = r.render || l, la && la(e);
	}
	{
		let t = ta(e);
		Je();
		try {
			yr(e);
		} finally {
			Ye(), t();
		}
	}
}
var da = { get(e, t) {
	return N(e, "get", ""), e[t];
} };
function fa(e) {
	return {
		attrs: new Proxy(e.attrs, da),
		slots: e.slots,
		emit: e.emit,
		expose: (t) => {
			e.exposed = t || {};
		}
	};
}
function pa(e) {
	return e.exposed ? e.exposeProxy ||= new Proxy(Qt(Gt(e.exposed)), {
		get(t, n) {
			if (n in t) return t[n];
			if (n in mr) return mr[n](e);
		},
		has(e, t) {
			return t in e || t in mr;
		}
	}) : e.proxy;
}
function ma(e) {
	return x(e) && "__vccOpts" in e;
}
var ha = (e, t) => /* @__PURE__ */ en(e, t, ia), ga = "3.5.38", _a = void 0, va = typeof window < "u" && window.trustedTypes;
if (va) try {
	_a = /* @__PURE__ */ va.createPolicy("vue", { createHTML: (e) => e });
} catch {}
var ya = _a ? (e) => _a.createHTML(e) : (e) => e, ba = "http://www.w3.org/2000/svg", xa = "http://www.w3.org/1998/Math/MathML", Sa = typeof document < "u" ? document : null, Ca = Sa && /* @__PURE__ */ Sa.createElement("template"), wa = {
	insert: (e, t, n) => {
		t.insertBefore(e, n || null);
	},
	remove: (e) => {
		let t = e.parentNode;
		t && t.removeChild(e);
	},
	createElement: (e, t, n, r) => {
		let i = t === "svg" ? Sa.createElementNS(ba, e) : t === "mathml" ? Sa.createElementNS(xa, e) : n ? Sa.createElement(e, { is: n }) : Sa.createElement(e);
		return e === "select" && r && r.multiple != null && i.setAttribute("multiple", r.multiple), i;
	},
	createText: (e) => Sa.createTextNode(e),
	createComment: (e) => Sa.createComment(e),
	setText: (e, t) => {
		e.nodeValue = t;
	},
	setElementText: (e, t) => {
		e.textContent = t;
	},
	parentNode: (e) => e.parentNode,
	nextSibling: (e) => e.nextSibling,
	querySelector: (e) => Sa.querySelector(e),
	setScopeId(e, t) {
		e.setAttribute(t, "");
	},
	insertStaticContent(e, t, n, r, i, a) {
		let o = n ? n.previousSibling : t.lastChild;
		if (i && (i === a || i.nextSibling)) for (; t.insertBefore(i.cloneNode(!0), n), !(i === a || !(i = i.nextSibling)););
		else {
			Ca.innerHTML = ya(r === "svg" ? `<svg>${e}</svg>` : r === "mathml" ? `<math>${e}</math>` : e);
			let i = Ca.content;
			if (r === "svg" || r === "mathml") {
				let e = i.firstChild;
				for (; e.firstChild;) i.appendChild(e.firstChild);
				i.removeChild(e);
			}
			t.insertBefore(i, n);
		}
		return [o ? o.nextSibling : t.firstChild, n ? n.previousSibling : t.lastChild];
	}
}, Ta = /* @__PURE__ */ Symbol("_vtc");
function Ea(e, t, n) {
	let r = e[Ta];
	r && (t = (t ? [t, ...r] : [...r]).join(" ")), t == null ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t;
}
var Da = /* @__PURE__ */ Symbol("_vod"), Oa = /* @__PURE__ */ Symbol("_vsh"), ka = /* @__PURE__ */ Symbol(""), Aa = /(?:^|;)\s*display\s*:/;
function ja(e, t, n) {
	let r = e.style, i = S(n), a = !1;
	if (n && !i) {
		if (t) if (S(t)) for (let e of t.split(";")) {
			let t = e.slice(0, e.indexOf(":")).trim();
			n[t] ?? Na(r, t, "");
		}
		else for (let e in t) n[e] ?? Na(r, e, "");
		for (let i in n) {
			i === "display" && (a = !0);
			let o = n[i];
			o == null ? Na(r, i, "") : La(e, i, !S(t) && t ? t[i] : void 0, o) || Na(r, i, o);
		}
	} else if (i) {
		if (t !== n) {
			let e = r[ka];
			e && (n += ";" + e), r.cssText = n, a = Aa.test(n);
		}
	} else t && e.removeAttribute("style");
	Da in e && (e[Da] = a ? r.display : "", e[Oa] && (r.display = "none"));
}
var Ma = /\s*!important$/;
function Na(e, t, n) {
	if (_(n)) n.forEach((n) => Na(e, t, n));
	else if (n ??= "", t.startsWith("--")) e.setProperty(t, n);
	else {
		let r = Ia(e, t);
		Ma.test(n) ? e.setProperty(ce(r), n.replace(Ma, ""), "important") : e[r] = n;
	}
}
var Pa = [
	"Webkit",
	"Moz",
	"ms"
], Fa = {};
function Ia(e, t) {
	let n = Fa[t];
	if (n) return n;
	let r = E(t);
	if (r !== "filter" && r in e) return Fa[t] = r;
	r = le(r);
	for (let n = 0; n < Pa.length; n++) {
		let i = Pa[n] + r;
		if (i in e) return Fa[t] = i;
	}
	return t;
}
function La(e, t, n, r) {
	return e.tagName === "TEXTAREA" && (t === "width" || t === "height") && S(r) && n === r;
}
var Ra = "http://www.w3.org/1999/xlink";
function za(e, t, n, r, i, a = Ce(t)) {
	r && t.startsWith("xlink:") ? n == null ? e.removeAttributeNS(Ra, t.slice(6, t.length)) : e.setAttributeNS(Ra, t, n) : n == null || a && !we(n) ? e.removeAttribute(t) : e.setAttribute(t, a ? "" : C(n) ? String(n) : n);
}
function Ba(e, t, n, r, i) {
	if (t === "innerHTML" || t === "textContent") {
		n != null && (e[t] = t === "innerHTML" ? ya(n) : n);
		return;
	}
	let a = e.tagName;
	if (t === "value" && a !== "PROGRESS" && !a.includes("-")) {
		let r = a === "OPTION" ? e.getAttribute("value") || "" : e.value, i = n == null ? e.type === "checkbox" ? "on" : "" : String(n);
		(r !== i || !("_value" in e)) && (e.value = i), n ?? e.removeAttribute(t), e._value = n;
		return;
	}
	let o = !1;
	if (n === "" || n == null) {
		let r = typeof e[t];
		r === "boolean" ? n = we(n) : n == null && r === "string" ? (n = "", o = !0) : r === "number" && (n = 0, o = !0);
	}
	try {
		e[t] = n;
	} catch {}
	o && e.removeAttribute(i || t);
}
function Va(e, t, n, r) {
	e.addEventListener(t, n, r);
}
function Ha(e, t, n, r) {
	e.removeEventListener(t, n, r);
}
var Ua = /* @__PURE__ */ Symbol("_vei");
function Wa(e, t, n, r, i = null) {
	let a = e[Ua] || (e[Ua] = {}), o = a[t];
	if (r && o) o.value = r;
	else {
		let [n, s] = Ka(t);
		r ? Va(e, n, a[t] = Xa(r, i), s) : o && (Ha(e, n, o, s), a[t] = void 0);
	}
}
var Ga = /(?:Once|Passive|Capture)$/;
function Ka(e) {
	let t;
	if (Ga.test(e)) {
		t = {};
		let n;
		for (; n = e.match(Ga);) e = e.slice(0, e.length - n[0].length), t[n[0].toLowerCase()] = !0;
	}
	return [e[2] === ":" ? e.slice(3) : ce(e.slice(2)), t];
}
var qa = 0, Ja = /* @__PURE__ */ Promise.resolve(), Ya = () => qa ||= (Ja.then(() => qa = 0), Date.now());
function Xa(e, t) {
	let n = (e) => {
		if (!e._vts) e._vts = Date.now();
		else if (e._vts <= n.attached) return;
		let r = n.value;
		if (_(r)) {
			let n = e.stopImmediatePropagation;
			e.stopImmediatePropagation = () => {
				n.call(e), e._stopped = !0;
			};
			let i = r.slice(), a = [e];
			for (let n = 0; n < i.length && !e._stopped; n++) {
				let e = i[n];
				e && z(e, t, 5, a);
			}
		} else z(r, t, 5, [e]);
	};
	return n.value = e, n.attached = Ya(), n;
}
var Za = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123, Qa = (e, t, n, r, i, a) => {
	let o = i === "svg";
	t === "class" ? Ea(e, r, o) : t === "style" ? ja(e, n, r) : d(t) ? f(t) || Wa(e, t, n, r, a) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : $a(e, t, r, o)) ? (Ba(e, t, r), !e.tagName.includes("-") && (t === "value" || t === "checked" || t === "selected") && za(e, t, r, o, a, t !== "value")) : e._isVueCE && (eo(e, t) || e._def.__asyncLoader && (/[A-Z]/.test(t) || !S(r))) ? Ba(e, E(t), r, a, t) : (t === "true-value" ? e._trueValue = r : t === "false-value" && (e._falseValue = r), za(e, t, r, o));
};
function $a(e, t, n, r) {
	if (r) return !!(t === "innerHTML" || t === "textContent" || t in e && Za(t) && x(n));
	if (t === "spellcheck" || t === "draggable" || t === "translate" || t === "autocorrect" || t === "sandbox" && e.tagName === "IFRAME" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA") return !1;
	if (t === "width" || t === "height") {
		let t = e.tagName;
		if (t === "IMG" || t === "VIDEO" || t === "CANVAS" || t === "SOURCE") return !1;
	}
	return Za(t) && S(n) ? !1 : t in e;
}
function eo(e, t) {
	let n = e._def.props;
	if (!n) return !1;
	let r = E(t);
	return Array.isArray(n) ? n.some((e) => E(e) === r) : Object.keys(n).some((e) => E(e) === r);
}
var to = /* @__PURE__ */ p({ patchProp: Qa }, wa), no;
function ro() {
	return no ||= pi(to);
}
var io = ((...e) => {
	let t = ro().createApp(...e), { mount: n } = t;
	return t.mount = (e) => {
		let r = oo(e);
		if (!r) return;
		let i = t._component;
		!x(i) && !i.render && !i.template && (i.template = r.innerHTML), r.nodeType === 1 && (r.textContent = "");
		let a = n(r, !1, ao(r));
		return r instanceof Element && (r.removeAttribute("v-cloak"), r.setAttribute("data-v-app", "")), a;
	}, t;
});
function ao(e) {
	if (e instanceof SVGElement) return "svg";
	if (typeof MathMLElement == "function" && e instanceof MathMLElement) return "mathml";
}
function oo(e) {
	return S(e) ? document.querySelector(e) : e;
}
//#endregion
//#region src/view/apps/dashboard/GrimdarkDashboard.vue?vue&type=script&setup=true&lang.ts
var so = { class: "dashboard" }, co = {
	class: "dashboard__status",
	"aria-label": "Runtime status"
}, lo = {
	key: 0,
	class: "dashboard__actor",
	"aria-label": "Selected actor"
}, uo = { class: "dashboard__actor-heading" }, fo = {
	key: 0,
	class: "dashboard__peril"
}, po = { class: "dashboard__actor-grid" }, mo = {
	key: 1,
	class: "dashboard__warning"
}, ho = {
	key: 2,
	class: "dashboard__warning",
	role: "status"
}, go = { class: "dashboard__columns" }, _o = { class: "dashboard__footer" }, vo = /* @__PURE__ */ Vn({
	__name: "GrimdarkDashboard",
	props: {
		actor: {},
		experimentalCombat: { type: Boolean },
		runtime: {}
	},
	setup(e) {
		let t = [
			"Melee exchange response prompt and opposed rolls",
			"Momentum gain, loss, use, and Initiative cap",
			"Recursive exploding damage and no doubled critical dice",
			"Toughness, armour, shield, Tank, and minimum-1 Negation",
			"Mortal Peril, Excess Damage, and thirteen Critical Injury tables"
		], n = [
			"Fate and Resolve actor resources (starting allocation settled)",
			"Armour Piercing weapons and values (reserved for later)",
			"Define the general First Aid and magical-healing interactions for Bleeding",
			"Perilous magic, Fear/Terror, corruption, and careers (rules still open)"
		];
		return (r, i) => (ki(), Pi("main", so, [
			i[14] ||= q("header", { class: "dashboard__hero" }, [
				q("p", { class: "dashboard__eyebrow" }, "Foundry VTT 14 · D&D5e 2024-first"),
				q("h1", null, "Grimdark 5e"),
				q("p", null, "5e chassis, Warhammer consequences.")
			], -1),
			q("section", co, [
				q("div", null, [i[0] ||= q("span", null, "Foundry", -1), q("strong", null, k(e.runtime.foundryVersion), 1)]),
				q("div", null, [i[1] ||= q("span", null, "D&D5e", -1), q("strong", null, k(e.runtime.systemVersion), 1)]),
				q("div", null, [i[2] ||= q("span", null, "Rules", -1), q("strong", null, k(e.runtime.rulesVersion), 1)])
			]),
			e.actor ? (ki(), Pi("section", lo, [q("div", uo, [q("div", null, [i[3] ||= q("p", { class: "dashboard__eyebrow" }, "Selected actor", -1), q("h2", null, k(e.actor.name), 1)]), e.actor.mortalPeril ? (ki(), Pi("strong", fo, "Mortal Peril")) : Gi("", !0)]), q("div", po, [
				q("div", null, [i[4] ||= q("span", null, "Negation", -1), q("strong", null, k(e.actor.negation.total), 1)]),
				q("div", null, [i[5] ||= q("span", null, "Toughness", -1), q("strong", null, k(e.actor.negation.toughness), 1)]),
				q("div", null, [i[6] ||= q("span", null, "Armour", -1), q("strong", null, k(e.actor.negation.armour), 1)]),
				q("div", null, [i[7] ||= q("span", null, "Shield", -1), q("strong", null, k(e.actor.negation.shield), 1)]),
				q("div", null, [i[8] ||= q("span", null, "Momentum", -1), q("strong", null, k(e.actor.momentum) + "/" + k(e.actor.momentumCap), 1)]),
				q("div", null, [i[9] ||= q("span", null, "Injuries", -1), q("strong", null, k(e.actor.criticalInjuries), 1)]),
				q("div", null, [i[10] ||= q("span", null, "Bleeding", -1), q("strong", null, k(e.actor.bleeding), 1)])
			])])) : (ki(), Pi("p", mo, "Select a token to inspect its Grimdark combat values.")),
			e.runtime.rulesVersion === "2024" ? Gi("", !0) : (ki(), Pi("div", ho, " This module is designed against the 2024 rules. Set the D&D5e system Rules Version to Modern before enabling automation. ")),
			q("div", go, [q("section", null, [i[11] ||= q("h2", null, "Scaffolded rule domains", -1), q("ul", null, [(ki(), Pi(G, null, fr(t, (e) => q("li", { key: e }, k(e), 1)), 64))])]), q("section", null, [i[12] ||= q("h2", null, "Next integration slices", -1), q("ul", null, [(ki(), Pi(G, null, fr(n, (e) => q("li", { key: e }, k(e), 1)), 64))])])]),
			q("footer", _o, [i[13] ||= Wi(" Experimental combat automation: ", -1), q("strong", null, k(e.experimentalCombat ? "enabled" : "disabled"), 1)])
		]));
	}
}), Z = "grimdark-5e", yo = "Grimdark 5e", bo = "dnd5e";
//#endregion
//#region src/module/dnd5e/get-dnd5e-runtime-info.ts
function xo() {
	let e = game?.settings.get(bo, "rulesVersion");
	return e === "modern" ? "2024" : e === "legacy" ? "2014" : "unknown";
}
function So() {
	let e = game?.system;
	return {
		foundryVersion: game?.version ?? "unknown",
		isExpectedSystem: e?.id === bo,
		rulesVersion: xo(),
		systemId: e?.id ?? "unknown",
		systemVersion: e?.version ?? "unknown"
	};
}
//#endregion
//#region src/module/settings/register-module-settings.ts
var Co = {
	experimentalCombat: "experimentalCombat",
	dodgeCriticalPriority: "dodgeCriticalPriority",
	automaticCriticalInjuries: "automaticCriticalInjuries"
};
function wo() {
	if (!game) throw Error("Foundry game global is unavailable while reading module settings.");
	return game.settings;
}
function To() {
	if (!game) throw Error("Foundry game global is unavailable during module settings registration.");
	game.settings.register(Z, Co.experimentalCombat, {
		config: !0,
		default: !0,
		hint: "GRIMDARK_5E.Settings.ExperimentalCombat.Hint",
		name: "GRIMDARK_5E.Settings.ExperimentalCombat.Name",
		scope: "world",
		type: Boolean
	}), game.settings.register(Z, Co.dodgeCriticalPriority, {
		choices: {
			both: "GRIMDARK_5E.Settings.DodgeCriticalPriority.Both",
			dodge: "GRIMDARK_5E.Settings.DodgeCriticalPriority.Dodge",
			normal: "GRIMDARK_5E.Settings.DodgeCriticalPriority.Normal"
		},
		config: !0,
		default: "dodge",
		hint: "GRIMDARK_5E.Settings.DodgeCriticalPriority.Hint",
		name: "GRIMDARK_5E.Settings.DodgeCriticalPriority.Name",
		scope: "world",
		type: String
	}), game.settings.register(Z, Co.automaticCriticalInjuries, {
		config: !0,
		default: !0,
		hint: "GRIMDARK_5E.Settings.AutomaticCriticalInjuries.Hint",
		name: "GRIMDARK_5E.Settings.AutomaticCriticalInjuries.Name",
		scope: "world",
		type: Boolean
	});
}
function Eo() {
	let e = wo().get(Z, Co.experimentalCombat);
	if (typeof e != "boolean") throw Error("Experimental Combat setting is invalid.");
	return e;
}
function Do() {
	let e = wo().get(Z, Co.dodgeCriticalPriority);
	if (e === "both" || e === "dodge" || e === "normal") return e;
	throw Error("Dodge Critical Resolution setting is invalid.");
}
function Oo() {
	let e = wo().get(Z, Co.automaticCriticalInjuries);
	if (typeof e != "boolean") throw Error("Automatic Critical Injuries setting is invalid.");
	return e;
}
//#endregion
//#region src/functions/combat/bleeding.ts
function ko(e) {
	return Math.max(0, Math.trunc(e) - 1);
}
function Ao(e, t) {
	let n = Math.max(1, Math.trunc(e)), r = ko(t);
	return r ? `1d${n}x + ${r}` : `1d${n}x`;
}
function jo(e) {
	let t = ko(e);
	return t ? `1d20 - ${t}` : "1d20";
}
function Mo(e) {
	return e <= 1;
}
function No(e, t) {
	return Math.min(6, Math.max(0, Math.trunc(e)) + Math.max(0, Math.trunc(t)));
}
function Po(e) {
	return [
		e.largestFace,
		typeof e.largest == "string" ? Number.parseInt(e.largest.replace(/^d/i, ""), 10) : 0,
		typeof e.denomination == "number" ? e.denomination : Number.parseInt(e.denomination ?? "", 10),
		Number.parseInt(e.hpFormula?.match(/\d*d(\d+)/i)?.[1] ?? "", 10)
	].find((e) => Number.isFinite(e) && (e ?? 0) > 0) ?? 8;
}
//#endregion
//#region src/module/dnd5e/actor-values.ts
function Fo(e) {
	return typeof e == "object" && e ? e : {};
}
function Io(e, t = 0) {
	return typeof e == "number" && Number.isFinite(e) ? e : t;
}
function Lo(e, t) {
	return Fo(e[t]);
}
function Ro(e, t) {
	return Io(e.system.abilities?.[t]?.mod);
}
function zo(e) {
	return Io(e.system.attributes?.prof, 2);
}
function Bo(e) {
	let t = e.system.attributes?.init;
	return Io(t?.total, Io(t?.value, Ro(e, "dex")));
}
function Vo(e) {
	return e.system.equipped === !0;
}
function Ho(e) {
	if (e.type !== "equipment" || !Vo(e)) return;
	let t = Lo(e.system, "type"), n = Lo(e.system, "armor"), r = (t.value ?? n.type) === "shield";
	return {
		shield: r,
		value: Io(n.base, Io(n.value, r ? 2 : 10))
	};
}
function Uo(e) {
	let t = 10, n = 0;
	for (let r of e.items) {
		let e = Ho(r);
		e && (e.shield ? n = Math.max(n, e.value) : t = Math.max(t, e.value));
	}
	return {
		armourBaseAc: t,
		shieldBonus: n
	};
}
function Wo(e, n = {}) {
	return t({
		...Uo(e),
		constitutionModifier: Ro(e, "con"),
		proficiencyBonus: zo(e),
		strengthModifier: Ro(e, "str"),
		...n
	});
}
function Go(e) {
	return i(Bo(e));
}
function Ko(e) {
	let t = e.system.attributes?.hd;
	return Po({
		denomination: t?.denomination,
		hpFormula: e.system.attributes?.hp?.formula,
		largest: t?.largest,
		largestFace: t?.largestFace
	});
}
function qo(e) {
	return Array.from(e.items).filter((e) => e.type === "weapon" && Vo(e));
}
function Jo(e) {
	if (typeof e == "string") return e;
	if (e && Symbol.iterator in Object(e)) {
		let t = Array.from(e)[0];
		return typeof t == "string" ? t : void 0;
	}
}
function Yo(e) {
	let t = Jo(Lo(Lo(e.system, "damage"), "base").types);
	if (!t) throw Error(`Item "${e.name}" has no damage type.`);
	return t;
}
//#endregion
//#region src/functions/combat/critical-injury-severity.ts
function Xo(e) {
	return e.unmodified ? 0 : Math.max(0, Math.trunc(e.excessDamage ?? 0)) + Math.max(0, Math.trunc(e.existingInjuries)) * 10;
}
function Zo(e) {
	let t = Xo(e);
	return t > 0 ? `1d100 + ${t}` : "1d100";
}
//#endregion
//#region src/module/hooks/run-hook-task.ts
function Qo(e, t) {
	t.catch((t) => {
		console.error(`[Grimdark 5e] ${e} failed.`, t), ui.notifications.error(`${e} failed. See the browser console for details.`);
	});
}
//#endregion
//#region src/module/critical-injuries/critical-injury-service.ts
var $o = "criticalInjury", es = "bludgeoning";
function ts(e) {
	return typeof e == "object" && e ? e : {};
}
function ns(e) {
	return typeof e == "number" && Number.isFinite(e) ? e : 0;
}
function rs(e) {
	return e.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;");
}
function is(e) {
	let t = ts(ts(e.flags?.[Z])[$o]);
	if (typeof t.name == "string") return t;
}
function as() {
	return game?.user.isGM === !0 && game.users.activeGM?.id === game.user.id;
}
async function os(e, t) {
	if (t <= 0) return;
	let n = e.system.attributes?.exhaustion ?? 0;
	await e.update({ "system.attributes.exhaustion": No(n, t) });
}
function ss(e) {
	let t = ts(e.flags?.[Z]);
	return typeof t.severity == "string" ? t.severity : "unknown";
}
function cs(e) {
	let t = ts(e.flags?.[Z]).bleeding;
	if (typeof t != "number" || !Number.isInteger(t) || t < 0) throw Error(`Critical Injury result "${e.name}" has invalid Bleeding metadata.`);
	return t;
}
function ls(e) {
	return Array.from(e.effects).flatMap((e) => {
		let t = is(e);
		return t ? [{
			data: t,
			effect: e
		}] : [];
	});
}
function us(e) {
	return ls(e).reduce((e, t) => e + t.data.bleeding, 0);
}
async function ds(e, t = 1) {
	let n = us(e), r = Math.max(0, Math.trunc(t)), i = 0;
	for (let t of ls(e)) {
		if (!r || !t.data.bleeding || !t.effect.update) continue;
		let e = Math.min(r, t.data.bleeding);
		r -= e, i += e, await t.effect.update({ [`flags.${Z}.${$o}.bleeding`]: t.data.bleeding - e });
	}
	return await os(e, i), Math.max(0, n - i);
}
function fs() {
	Hooks.on("deleteActiveEffect", ((e) => {
		let t = is(e)?.bleeding ?? 0;
		!as() || !e.actor || t <= 0 || Qo("Bleeding-to-Exhaustion conversion", os(e.actor, t));
	}));
}
async function ps(e) {
	let { actor: t } = e, n = e.damageType?.toLowerCase() || es, r = game?.packs.get(`${Z}.critical-injury-tables`);
	if (!r) throw Error("Grimdark Critical Injury compendium is unavailable.");
	let i = await r.getDocuments(), a = `${n} critical injuries`, o = i.find((e) => e.name.toLowerCase() === a);
	if (!o) throw Error(`No Critical Injury table was found for ${n} damage.`);
	let s = ls(t).length, c = Math.max(0, Math.trunc(e.excessDamage ?? 0)), l = Zo({
		excessDamage: c,
		existingInjuries: s,
		...e.unmodified === void 0 ? {} : { unmodified: e.unmodified }
	}), u = await o.roll({ roll: new Roll(l) }), d = u.results[0];
	if (!d) throw Error(`Critical Injury table "${o.name}" produced no result for ${l}.`);
	let f = d.description ?? "", p = {
		bleeding: cs(d),
		damageType: n,
		description: f,
		excessDamage: c,
		name: d.name,
		rollTotal: ns(u.roll.total),
		severity: ss(d)
	};
	await t.createEmbeddedDocuments("ActiveEffect", [{
		name: `Critical Injury: ${d.name}`,
		img: d.img ?? "icons/svg/blood.svg",
		description: f,
		disabled: !1,
		transfer: !1,
		flags: { [Z]: {
			[$o]: p,
			source: e.source
		} }
	}]);
	let m = u.roll.render ? await u.roll.render() : `<strong>${p.rollTotal}</strong>`;
	return await ChatMessage.create({
		content: `<section class="grimdark-critical-card">
      <h3><i class="fa-solid fa-droplet"></i> Critical Injury — ${rs(t.name)}</h3>
      <p><strong>${rs(d.name)}</strong> · ${rs(n)} · ${rs(p.severity)}</p>
      ${f}
      <details><summary>Severity roll</summary>${m}</details>
    </section>`,
		flags: { [Z]: { criticalInjury: p } },
		speaker: ChatMessage.getSpeaker({ actor: t })
	}), p;
}
//#endregion
//#region src/module/combat/momentum-service.ts
var ms = "momentum";
function hs(e) {
	let t = e.getFlag(Z, ms);
	return typeof t == "number" && Number.isFinite(t) ? Math.min(Go(e), Math.max(0, Math.trunc(t))) : 0;
}
async function gs(e, t) {
	let n = Math.min(Go(e), Math.max(0, Math.trunc(t)));
	return await e.setFlag(Z, ms, n), n;
}
async function _s(e, t) {
	t === "gain" ? await gs(e, hs(e) + 1) : t === "clear" && await gs(e, 0);
}
async function vs(e, t, n) {
	await Promise.all([_s(e, n.attackerMomentumChange), _s(t, n.defenderMomentumChange)]);
}
//#endregion
//#region node_modules/pinia/dist/pinia.mjs
var ys = typeof window < "u", bs = Symbol(), xs;
(function(e) {
	e.direct = "direct", e.patchObject = "patch object", e.patchFunction = "patch function";
})(xs ||= {});
var Ss = typeof window == "object" && window.window === window ? window : typeof self == "object" && self.self === self ? self : typeof global == "object" && global.global === global ? global : typeof globalThis == "object" ? globalThis : { HTMLElement: null };
function Cs(e, { autoBom: t = !1 } = {}) {
	return t && /^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(e.type) ? new Blob(["﻿", e], { type: e.type }) : e;
}
function ws(e, t, n) {
	let r = new XMLHttpRequest();
	r.open("GET", e), r.responseType = "blob", r.onload = function() {
		ks(r.response, t, n);
	}, r.onerror = function() {
		console.error("could not download file");
	}, r.send();
}
function Ts(e) {
	let t = new XMLHttpRequest();
	t.open("HEAD", e, !1);
	try {
		t.send();
	} catch {}
	return t.status >= 200 && t.status <= 299;
}
function Es(e) {
	try {
		e.dispatchEvent(new MouseEvent("click"));
	} catch {
		let t = new MouseEvent("click", {
			bubbles: !0,
			cancelable: !0,
			view: window,
			detail: 0,
			screenX: 80,
			screenY: 20,
			clientX: 80,
			clientY: 20,
			ctrlKey: !1,
			altKey: !1,
			shiftKey: !1,
			metaKey: !1,
			button: 0,
			relatedTarget: null
		});
		e.dispatchEvent(t);
	}
}
var Ds = typeof navigator == "object" ? navigator : { userAgent: "" }, Os = /Macintosh/.test(Ds.userAgent) && /AppleWebKit/.test(Ds.userAgent) && !/Safari/.test(Ds.userAgent), ks = ys ? typeof HTMLAnchorElement < "u" && "download" in HTMLAnchorElement.prototype && !Os ? As : "msSaveOrOpenBlob" in Ds ? js : Ms : () => {};
function As(e, t = "download", n) {
	let r = document.createElement("a");
	r.download = t, r.rel = "noopener", typeof e == "string" ? (r.href = e, r.origin === location.origin ? Es(r) : Ts(r.href) ? ws(e, t, n) : (r.target = "_blank", Es(r))) : (r.href = URL.createObjectURL(e), setTimeout(function() {
		URL.revokeObjectURL(r.href);
	}, 4e4), setTimeout(function() {
		Es(r);
	}, 0));
}
function js(e, t = "download", n) {
	if (typeof e == "string") if (Ts(e)) ws(e, t, n);
	else {
		let t = document.createElement("a");
		t.href = e, t.target = "_blank", setTimeout(function() {
			Es(t);
		});
	}
	else navigator.msSaveOrOpenBlob(Cs(e, n), t);
}
function Ms(e, t, n, r) {
	if (r ||= open("", "_blank"), r && (r.document.title = r.document.body.innerText = "downloading..."), typeof e == "string") return ws(e, t, n);
	let i = e.type === "application/octet-stream", a = /constructor/i.test(String(Ss.HTMLElement)) || "safari" in Ss, o = /CriOS\/[\d]+/.test(navigator.userAgent);
	if ((o || i && a || Os) && typeof FileReader < "u") {
		let t = new FileReader();
		t.onloadend = function() {
			let e = t.result;
			if (typeof e != "string") throw r = null, Error("Wrong reader.result type");
			e = o ? e : e.replace(/^data:[^;]*;/, "data:attachment/file;"), r ? r.location.href = e : location.assign(e), r = null;
		}, t.readAsDataURL(e);
	} else {
		let t = URL.createObjectURL(e);
		r ? r.location.assign(t) : location.href = t, r = null, setTimeout(function() {
			URL.revokeObjectURL(t);
		}, 4e4);
	}
}
var { assign: Ns } = Object;
function Ps() {
	let e = je(!0), t = e.run(() => /* @__PURE__ */ qt({})), n = [], r = [], i = Gt({
		install(e) {
			i._a = e, e.provide(bs, i), e.config.globalProperties.$pinia = i, r.forEach((e) => n.push(e)), r = [];
		},
		use(e) {
			return this._a ? n.push(e) : r.push(e), this;
		},
		_p: n,
		_a: null,
		_e: e,
		_s: /* @__PURE__ */ new Map(),
		state: t
	});
	return i;
}
var { assign: Fs } = Object, Is = class extends foundry.applications.api.ApplicationV2 {
	#e;
	getVueProps() {}
	async _renderHTML(e, t) {
		let n = document.createElement("div");
		return n.classList.add("grimdark-5e-root"), n.dataset.theme = "grimdark-5e", n;
	}
	_replaceHTML(e, t, n) {
		this.unmountVue(), t.classList.add("grimdark-5e-app"), t.replaceChildren(e), this.#e = io(this.getVueComponent(), this.getVueProps() ?? {}), this.#e.use(Ps()), this.#e.mount(e);
	}
	async _preClose(e) {
		this.unmountVue(), await super._preClose(e);
	}
	unmountVue() {
		this.#e?.unmount(), this.#e = void 0;
	}
}, Ls = class extends Is {
	static DEFAULT_OPTIONS = {
		id: `${Z}-dashboard`,
		tag: "section",
		window: {
			icon: "fa-solid fa-shield-halved",
			resizable: !0,
			title: yo
		},
		position: {
			height: "auto",
			width: 620
		}
	};
	getVueComponent() {
		return vo;
	}
	getVueProps() {
		let e = canvas.tokens?.controlled[0]?.actor ?? game?.user.character, t = e ? Wo(e) : void 0;
		return {
			actor: e ? {
				bleeding: us(e),
				criticalInjuries: ls(e).length,
				mortalPeril: e.getFlag(Z, "mortalPeril") === !0,
				momentum: hs(e),
				momentumCap: Go(e),
				name: e.name,
				negation: t
			} : void 0,
			experimentalCombat: Eo(),
			runtime: So()
		};
	}
};
//#endregion
//#region src/module/api/create-module-api.ts
async function Rs(e) {
	let t = await fromUuid(e);
	if (typeof t == "object" && t && "applyDamage" in t) return t;
}
function zs() {
	return {
		calculateDamageNegation: t,
		calculateMomentumCap: i,
		calculateToughness: e,
		async getActorCombatSummary(e) {
			let t = await Rs(e);
			if (t) return {
				bleeding: us(t),
				criticalInjuries: ls(t).length,
				mortalPeril: t.getFlag(Z, "mortalPeril") === !0,
				momentum: hs(t),
				momentumCap: Go(t),
				negation: Wo(t)
			};
		},
		getDefenseResponses() {
			return n;
		},
		getRuntimeInfo: So,
		async openDashboard() {
			await new Ls().render(!0);
		},
		async reduceBleeding(e, t) {
			let n = await Rs(e);
			return n ? ds(n, t) : void 0;
		},
		async rollCriticalInjury(e, t = {}) {
			let n = await Rs(e);
			return n ? ps({
				actor: n,
				...t
			}) : void 0;
		},
		resolveDamageAfterNegation: a,
		async setMomentum(e, t) {
			let n = await Rs(e);
			return n ? gs(n, t) : void 0;
		}
	};
}
//#endregion
//#region src/module/api/register-module-api.ts
function Bs() {
	if (!game) throw Error("Foundry game global is unavailable during module API registration.");
	let e = game.modules.get(Z);
	if (!e) throw Error(`Foundry module registry entry was not found for ${Z}.`);
	e.api = zs();
}
//#endregion
//#region src/module/dnd5e/report-runtime-status.ts
function Vs() {
	if (!game) throw Error(`${yo} requires the Foundry game runtime.`);
	if (game.system?.id !== "dnd5e") throw Error(`${yo} requires the dnd5e system; found ${game.system?.id ?? "none"}.`);
}
function Hs() {
	Vs();
	let e = So();
	e.rulesVersion !== "2024" && console.warn(`${yo} is 2024-first, but this world currently reports the ${e.rulesVersion} rules baseline.`), console.info(`${yo} ready on Foundry ${e.foundryVersion}, dnd5e ${e.systemVersion}, rules ${e.rulesVersion}.`);
}
//#endregion
//#region src/functions/combat/damage-negation-applicability.ts
function Us(e) {
	return e.trim().toLowerCase() === "force";
}
function Ws(e) {
	let t = Math.max(0, e.damage);
	if (t === 0 || e.bypassNegation) return t;
	let n = Math.min(t, Math.max(0, e.forceDamage)), r = t - n;
	return r === 0 ? n : n + a({
		damage: r,
		negation: e.negation
	});
}
//#endregion
//#region src/functions/combat/grimdark-damage.ts
var Gs = {
	armour: 0,
	shield: 0,
	tanking: 0,
	toughness: 0,
	total: 0
};
function Ks(e) {
	let t = e.context.defenderActorUuid;
	return t && t !== e.defenderUuid ? {} : e.context;
}
function qs(e, t, n) {
	if (t.damageType) return t.damageType;
	if (n) return "bleeding";
	let r = e.reduce((e, t) => !t.type || (t.value ?? 0) <= 0 ? e : !e || (t.value ?? 0) > (e.value ?? 0) ? t : e, void 0);
	if (!r?.type) throw Error("Positive damage requires a damage type.");
	return r.type;
}
function Js(e, t, n) {
	let r = e.filter((e) => e.type && (e.value ?? 0) > 0);
	if (!r.length) return Us(t) ? n : 0;
	let i = r.reduce((e, t) => Us(t.type ?? "") ? e + (t.value ?? 0) : e, 0);
	return Math.min(n, i);
}
function Ys(e) {
	let t = Ks(e), n = qs(e.damageEntries, t, e.bleedingDamage), r = Js(e.damageEntries, n, e.rawAmount), i = t.response === "tank" ? e.tankingNegation : e.standardNegation, a = e.bypassNegation || r >= e.rawAmount ? Gs : i, o = Ws({
		bypassNegation: e.bypassNegation,
		damage: e.rawAmount,
		forceDamage: r,
		negation: a.total
	});
	return {
		bleedingDamage: e.bleedingDamage,
		context: t,
		damageType: n,
		excessDamage: e.bleedingDamage ? 0 : Math.max(0, o - e.existingHp),
		finalAmount: o,
		forceDamage: r,
		negation: a,
		rawAmount: e.rawAmount
	};
}
function Xs(e, t) {
	if (typeof e != "object" || !e) throw Error(`Grimdark damage resolution ${t} must be an object.`);
	return e;
}
function Zs(e, t, n) {
	let r = e[t];
	if (typeof r != "number" || !Number.isFinite(r) || n !== void 0 && r < n) throw Error(`Grimdark damage resolution ${t} is invalid.`);
	return r;
}
function Qs(e) {
	let t = Xs(e, "value");
	if (typeof t.bleedingDamage != "boolean") throw Error("Grimdark damage resolution bleedingDamage is invalid.");
	if (typeof t.damageType != "string" || !t.damageType) throw Error("Grimdark damage resolution damageType is invalid.");
	let n = Xs(t.context, "context");
	for (let e of [
		"damageType",
		"defenderActorUuid",
		"exchangeMessageId"
	]) if (n[e] !== void 0 && typeof n[e] != "string") throw Error(`Grimdark damage resolution context.${e} is invalid.`);
	for (let e of ["attackerCritical", "surprisedCritical"]) if (n[e] !== void 0 && typeof n[e] != "boolean") throw Error(`Grimdark damage resolution context.${e} is invalid.`);
	if (n.response !== void 0 && !r(n.response)) throw Error("Grimdark damage resolution context.response is invalid.");
	let i = Xs(t.negation, "negation");
	for (let e of [
		"armour",
		"shield",
		"tanking",
		"toughness",
		"total"
	]) Zs(i, e);
	for (let e of [
		"excessDamage",
		"finalAmount",
		"forceDamage",
		"rawAmount"
	]) Zs(t, e, 0);
	return e;
}
//#endregion
//#region src/module/dnd5e/register-damage-hooks.ts
function Q(e) {
	return typeof e == "object" && e ? e : {};
}
function $s(e) {
	let t = Q(Q(e[Z]).damageContext);
	return {
		...Q(Q(Q(Q(e.originatingMessage).flags)[Z]).damageContext),
		...t
	};
}
function ec(e) {
	let t = e.system.attributes?.hp;
	return Math.max(0, (t?.value ?? 0) + (t?.temp ?? 0));
}
function tc(e, t, n) {
	if (!Eo() || t.amount <= 0) return;
	let r = Q(n[Z]), i = $s(n), a = Ys({
		bleedingDamage: r.bleedingDamage === !0,
		bypassNegation: r.bypassNegation === !0,
		context: i,
		damageEntries: t,
		defenderUuid: e.uuid,
		existingHp: ec(e),
		rawAmount: t.amount,
		standardNegation: Wo(e),
		tankingNegation: Wo(e, { tanking: !0 })
	});
	t.amount = a.finalAmount, n[Z] = {
		...r,
		resolution: a
	};
}
function nc() {
	return game?.user.isGM === !0 && game.users.activeGM?.id === game.user.id;
}
async function rc(e, t, n) {
	if (!Eo() || t <= 0) return;
	let r = Qs(Q(n[Z]).resolution);
	if (!nc()) {
		game?.users.activeGM ? game.socket.emit(`module.${Z}`, {
			actorUuid: e.uuid,
			amount: t,
			resolution: r,
			type: "damageConsequences"
		}) : ui.notifications.error("Grimdark damage was applied, but Mortal Peril and Critical Injury consequences require an active GM.");
		return;
	}
	let i = e.system.attributes?.hp?.value ?? 0;
	if (i <= 0 ? await e.setFlag(Z, "mortalPeril", !0) : e.getFlag("grimdark-5e", "mortalPeril") && await e.unsetFlag(Z, "mortalPeril"), r.bleedingDamage) return;
	let { context: a, damageType: o, excessDamage: s, finalAmount: c, forceDamage: l, negation: u, rawAmount: d } = r, f = a.attackerCritical === !0 || a.surprisedCritical === !0 || s > 0;
	if (await ChatMessage.create({
		content: `<section class="grimdark-damage-card">
      <h3><i class="fa-solid fa-shield-halved"></i> Grimdark Damage — ${e.name}</h3>
      <p><strong>${d}</strong> incoming − <strong>${u.total}</strong> Negation
      = <strong>${c}</strong> damage.</p>
      <p class="grimdark-breakdown">Toughness ${u.toughness} · Armour ${u.armour} · Shield ${u.shield} · Tank ${u.tanking}</p>
      ${l > 0 ? `<p><strong>${l} Force damage</strong> bypassed Damage Negation.</p>` : ""}
      ${s > 0 ? `<p><strong>${s} Excess Damage</strong> — Critical Injury triggered.</p>` : ""}
      ${i <= 0 ? "<p><strong>Mortal Peril:</strong> the creature remains conscious, but death saves are replaced by concrete injuries.</p>" : ""}
    </section>`,
		flags: { [Z]: { damageResolution: r } },
		speaker: ChatMessage.getSpeaker({ actor: e })
	}), f && Oo()) {
		let t = typeof a.exchangeMessageId == "string" ? a.exchangeMessageId : void 0;
		await ps({
			actor: e,
			damageType: o,
			excessDamage: s,
			...t ? { source: t } : {}
		});
	}
}
function ic() {
	Hooks.on("dnd5e.calculateDamage", ((e, t, n) => {
		tc(e, t, n);
	})), Hooks.on("dnd5e.applyDamage", ((e, t, n) => {
		Qo("Damage consequences", rc(e, t, n));
	})), Hooks.on("dnd5e.preRollDeathSaveV2", ((e) => {
		let t = e.subject, n = typeof Q(t).getFlag == "function" ? t : Q(t).actor;
		if (!(!Eo() || !n?.getFlag("grimdark-5e", "mortalPeril"))) return ui.notifications.warn("Death saves are replaced by Mortal Peril and Critical Injuries in Grimdark 5e."), !1;
	})), Hooks.once("ready", (() => {
		if (!game) throw Error("Foundry game global is unavailable during socket registration.");
		game.socket.on(`module.${Z}`, (e) => {
			let t = Q(e);
			!nc() || t.type !== "damageConsequences" || typeof t.actorUuid != "string" || typeof t.amount != "number" || Qo("Remote damage consequences", fromUuid(t.actorUuid).then((e) => {
				let n = e;
				if (!n) throw Error(`Actor ${t.actorUuid} could not be resolved.`);
				return rc(n, t.amount, { [Z]: { resolution: t.resolution } });
			}));
		});
	}));
}
//#endregion
//#region src/module/dnd5e/register-roll-hooks.ts
var ac = {
	bonusDamage: "",
	bonusDice: 0,
	multiplier: 1,
	multiplyNumeric: !1,
	powerfulCritical: !1
};
function oc(e) {
	e.options ??= {}, e.options.isCritical = !1, e.options.critical = ac, e.configureDamage?.({ critical: ac });
}
function sc(e) {
	for (let t of e.dice ?? []) t.modifiers ??= [], t.modifiers.some((e) => e.toLowerCase().startsWith("x")) || t.modifiers.push("x");
	e.resetFormula?.();
}
function cc() {
	Hooks.on("dnd5e.postBuildDamageRollConfig", ((e, t) => {
		if (!Eo()) return;
		e.isCritical = !1, e.critical = ac;
		let n = typeof t.options == "object" && t.options ? t.options : t.options = {};
		n.isCritical = !1, n.critical = ac;
	})), Hooks.on("dnd5e.postDamageRollConfiguration", ((e) => {
		if (Eo()) for (let t of e) oc(t), sc(t);
	}));
}
//#endregion
//#region src/functions/combat/resolve-melee-exchange.ts
function lc(e) {
	return e.total + e.momentum;
}
function uc(e) {
	return e.modifier + e.momentum;
}
function dc(e, t) {
	let n = lc(e), r = lc(t);
	if (n !== r) return n > r ? "attacker" : "defender";
	let i = uc(e), a = uc(t);
	return i === a ? "stalemate" : i > a ? "attacker" : "defender";
}
function fc(e) {
	let t = e.response === "parry" || e.response === "dodge", n = "defender" in e ? e.defender : void 0, r = "unopposed";
	if (t) {
		if (!n) throw Error("An opposed defense requires a defender roll.");
		r = dc(e.attacker, n);
	}
	let i = e.response === "tank" || e.attacker.natural !== 1, a = n?.natural === 20, o = e.response === "dodge" && a && e.attacker.natural === 20, s = e.dodgeCriticalResolution ?? "dodge", c = o && s === "normal", l = e.response === "dodge" && a && !c;
	return {
		attackerCritical: e.attacker.natural === 20 && (!o || s === "both"),
		attackerMomentumChange: r === "attacker" ? "gain" : r === "defender" ? "clear" : "none",
		defenderCritical: e.response === "parry" && a,
		defenderMomentumChange: r === "defender" ? "gain" : r === "attacker" ? "clear" : "none",
		hit: t ? r === "attacker" && !l : i,
		normalDamageNegated: l,
		response: e.response,
		surprisedCritical: e.response === "surprised" && i,
		winner: r
	};
}
//#endregion
//#region src/module/combat/exchange-service.ts
function $(e) {
	return typeof e == "object" && e ? e : {};
}
function pc(e) {
	return $(e.flags?.dnd5e);
}
function mc(e) {
	return $(e.flags?.[Z]);
}
function hc(e) {
	let t = $(pc(e).activity).uuid;
	return typeof t == "string" ? t : void 0;
}
function gc(e) {
	let t = pc(e).targets;
	return Array.isArray(t) ? t.filter((e) => typeof $(e).uuid == "string") : [];
}
function _c(e) {
	for (let t of e.dice ?? []) {
		let e = t.results.find((e) => e.active !== !1);
		if (e) return e.result;
	}
	throw Error("A Grimdark melee exchange requires an active d20 result.");
}
function vc(e) {
	if (e.type !== "attack") return !1;
	let t = e.attack?.type?.value, n = e.item.system.actionType;
	return t === "melee" || n === "mwak";
}
function yc(e) {
	return $(pc(e).roll).type === "attack";
}
function bc(e) {
	let t = $(e);
	if (typeof t.applyDamage == "function") return e;
	let n = t.actor;
	return typeof $(n).applyDamage == "function" ? n : void 0;
}
function xc(e, t) {
	let n = zo(e);
	return t === "dodge" ? n + Ro(e, "dex") : n + Math.max(Ro(e, "str"), Ro(e, "dex"));
}
async function Sc(e, t) {
	let n = xc(e, t), r = await new Roll("1d20 + @modifier", { modifier: n }).evaluate();
	return {
		exchangeRoll: {
			modifier: n,
			momentum: hs(e),
			natural: _c(r),
			total: r.total
		},
		roll: r
	};
}
function Cc(e) {
	return game?.user.isGM === !0 || e.isOwner === !0;
}
function wc() {
	return game?.user.isGM === !0 && game.users.activeGM?.id === game.user.id;
}
async function Tc(e, t) {
	let n = game?.messages.get(e);
	if (!n || mc(n).exchange) return;
	let r = hc(n), i = gc(n)[0], a = n.rolls?.[0];
	if (!r || !i || !a) {
		ui.notifications.error("The attack must have one stored target and an attack roll before it can be resolved.");
		return;
	}
	let o = await fromUuid(r), s = bc(await fromUuid(i.uuid)), c = o?.actor;
	if (!o || !c || !s || !vc(o)) {
		ui.notifications.error("Grimdark 5e could not resolve the attacker, defender, or melee activity.");
		return;
	}
	let l = t === "parry" ? qo(s)[0] : void 0;
	if (t === "parry" && !l) {
		ui.notifications.error("Parry requires an equipped weapon.");
		return;
	}
	let u = _c(a), d = {
		modifier: a.total - u,
		momentum: hs(c),
		natural: u,
		total: a.total
	}, f = t === "parry" || t === "dodge" ? await Sc(s, t) : void 0, p = Do(), m;
	if (t === "parry" || t === "dodge") {
		if (!f) throw Error("An opposed defense roll was not created.");
		m = fc({
			attacker: d,
			defender: f.exchangeRoll,
			dodgeCriticalResolution: p,
			response: t
		});
	} else m = fc({
		attacker: d,
		dodgeCriticalResolution: p,
		response: t
	});
	await vs(c, s, m);
	let h = Yo(o.item), g = {
		attackerActorUuid: c.uuid,
		attackerName: c.name,
		attackTotal: a.total + d.momentum,
		damageContext: {
			attackerCritical: m.attackerCritical,
			damageType: h,
			defenderActorUuid: s.uuid,
			exchangeMessageId: n.id,
			response: t,
			surprisedCritical: m.surprisedCritical
		},
		defenderActorUuid: s.uuid,
		defenderName: s.name,
		resolution: m,
		...f ? { defenseTotal: f.roll.total + f.exchangeRoll.momentum } : {}
	};
	if (await n.setFlag(Z, "exchange", g), m.defenderCritical) {
		if (!l) throw Error("A Parry critical requires an equipped weapon.");
		await ps({
			actor: c,
			damageType: Yo(l),
			source: n.id
		});
	}
	m.attackerCritical && !m.hit && await ps({
		actor: s,
		damageType: h,
		source: n.id
	}), await ChatMessage.create({
		content: `<section class="grimdark-exchange-card">
      <h3><i class="fa-solid fa-swords"></i> Melee Exchange</h3>
      <p><strong>${c.name}</strong> ${g.attackTotal} vs. <strong>${s.name}</strong> ${g.defenseTotal ?? t}.</p>
      <p><strong>${m.hit ? "Hit" : "No normal damage"}</strong> · ${t} · ${m.winner}</p>
      <p>Momentum: ${c.name} ${hs(c)} · ${s.name} ${hs(s)}</p>
    </section>`,
		flags: { [Z]: { exchange: g } },
		speaker: n.speaker
	});
}
async function Ec(e, t) {
	if (wc()) {
		await Tc(e, t);
		return;
	}
	if (!game?.users.activeGM) {
		ui.notifications.error("An active GM is required to resolve a Grimdark exchange.");
		return;
	}
	game.socket.emit(`module.${Z}`, {
		messageId: e,
		response: t,
		type: "resolveExchange"
	}), ui.notifications.info("Exchange response sent to the GM.");
}
function Dc() {
	Hooks.once("ready", (() => {
		if (!game) throw Error("Foundry game global is unavailable during socket registration.");
		game.socket.on(`module.${Z}`, (e) => {
			let t = $(e);
			if (!(!wc() || t.type !== "resolveExchange")) {
				if (typeof t.messageId != "string") throw Error("Remote exchange request has no message id.");
				if (!r(t.response)) throw Error("Remote exchange request has an invalid defense response.");
				Qo("Remote exchange resolution", Tc(t.messageId, t.response));
			}
		});
	}));
}
//#endregion
//#region src/module/combat/exchange-workflow.ts
async function Oc(e, t) {
	let n = qo(t).length > 0, i = await foundry.applications.api.DialogV2.wait({
		window: { title: "Resolve Grimdark Exchange" },
		content: "<p>Choose how the defender responds. Parry and Dodge are opposed rolls; Tank, Unopposed, and Surprised do not roll.</p>",
		buttons: [
			...n ? [{
				action: "parry",
				label: "Parry",
				icon: "<i class=\"fa-solid fa-swords\"></i>",
				callback: () => "parry"
			}] : [],
			{
				action: "dodge",
				label: "Dodge",
				icon: "<i class=\"fa-solid fa-person-running\"></i>",
				callback: () => "dodge"
			},
			{
				action: "tank",
				label: "Tank the Hit",
				icon: "<i class=\"fa-solid fa-shield\"></i>",
				callback: () => "tank"
			},
			{
				action: "unopposed",
				label: "Unopposed",
				callback: () => "unopposed"
			},
			{
				action: "surprised",
				label: "Surprised",
				callback: () => "surprised"
			}
		],
		rejectClose: !1
	});
	r(i) && await Ec(e.id, i);
}
async function kc(e) {
	let t = $(mc(e).exchange);
	if ($(t.resolution).hit !== !0) return;
	let n = hc(e), r = n ? await fromUuid(n) : void 0;
	if (!r?.actor?.isOwner) {
		ui.notifications.warn("The attack's owner or GM must roll its damage.");
		return;
	}
	let i = $(t.damageContext);
	await r.rollDamage({ isCritical: !1 }, { configure: !0 }, { data: { flags: {
		dnd5e: { originatingMessage: e.id },
		[Z]: { damageContext: i }
	} } });
}
function Ac(e) {
	let t = document.createElement("section");
	return t.className = "grimdark-exchange-panel", e ? (t.innerHTML = `<p><strong>${e.resolution.hit ? "Exchange won: roll damage" : "Exchange resolved: no normal damage"}</strong></p>
    <p>${e.attackerName} ${e.attackTotal} vs. ${e.defenderName} ${e.defenseTotal ?? e.resolution.response} · ${e.resolution.response}</p>
    ${e.resolution.hit ? "<button type=\"button\" data-grimdark-action=\"roll-damage\"><i class=\"fa-solid fa-burst\"></i> Roll Grimdark damage</button>" : ""}`, t) : (t.innerHTML = "<p><strong>Grimdark melee exchange</strong></p>\n      <button type=\"button\" data-grimdark-action=\"resolve-exchange\"><i class=\"fa-solid fa-swords\"></i> Resolve exchange</button>", t);
}
async function jc(e, t) {
	if (!Eo() || !yc(e) || t.querySelector(".grimdark-exchange-panel")) return;
	let n = hc(e), r = n ? await fromUuid(n) : void 0, i = gc(e)[0], a = i ? bc(await fromUuid(i.uuid)) : void 0;
	if (!r || !vc(r) || !a) return;
	let o = mc(e).exchange;
	if (!o && !Cc(a)) return;
	let s = Ac(o);
	if (t.querySelector(".message-content")?.append(s), o) for (let e of t.querySelectorAll("[data-action=\"rollDamage\"]")) e.disabled = !0, e.title = "Use Roll Grimdark damage after resolving the exchange.";
	s.addEventListener("click", (t) => {
		let n = t.target.closest("[data-grimdark-action]");
		n?.dataset.grimdarkAction === "resolve-exchange" && Qo("Exchange response", Oc(e, a)), n?.dataset.grimdarkAction === "roll-damage" && Qo("Grimdark damage roll", kc(e));
	});
}
function Mc() {
	Hooks.on("renderChatMessageHTML", ((e, t) => {
		Qo("Melee exchange chat rendering", jc(e, t));
	})), Dc();
}
//#endregion
//#region src/module/combat/bleeding-service.ts
var Nc = /* @__PURE__ */ new Map();
function Pc() {
	return game?.user.isGM === !0 && game.users.activeGM?.id === game.user.id;
}
function Fc(e) {
	return Math.max(0, e.system.attributes?.hp?.value ?? 0);
}
function Ic(e) {
	return e.statuses?.has("unconscious") === !0 || e.getFlag("grimdark-5e", "bleedingUnconscious") === !0;
}
async function Lc(e) {
	Ic(e) || (e.toggleStatusEffect ? await e.toggleStatusEffect("unconscious", { active: !0 }) : await e.createEmbeddedDocuments("ActiveEffect", [{
		name: "Bleeding: Unconscious",
		statuses: ["unconscious"],
		flags: { [Z]: { bleedingUnconscious: !0 } }
	}])), await e.setFlag(Z, "bleedingUnconscious", !0);
}
async function Rc(e) {
	let t = us(e);
	if (!t || e.getFlag("grimdark-5e", "bleedOutPending") === !0) return;
	let n = Ko(e), r = await new Roll(Ao(n, t)).evaluate();
	await e.applyDamage(r.total, { [Z]: {
		bleedingDamage: !0,
		bypassNegation: !0
	} });
	let i = Fc(e) === 0;
	i && await Lc(e);
	let a = i && Ic(e) ? await new Roll(jo(t)).evaluate() : void 0, o = a ? Mo(a.total) : !1;
	o && await e.setFlag(Z, "bleedOutPending", !0);
	let s = r.render ? await r.render() : `<strong>${r.total}</strong>`, c = a?.render ? await a.render() : a ? `<strong>${a.total}</strong>` : "";
	await ChatMessage.create({
		content: `<section class="grimdark-damage-card">
      <h3><i class="fa-solid fa-droplet"></i> Bleeding — ${e.name}</h3>
      <p>Bleeding ${t} · Hit Die d${n} · ${r.total} Hit Points lost.</p>
      <details><summary>Bleeding damage</summary>${s}</details>
      ${i ? "<p><strong>0 HP:</strong> the creature is Unconscious.</p>" : ""}
      ${a ? `<p>Bleed-out roll: <strong>${a.total}</strong>.</p><details><summary>Bleed-out roll</summary>${c}</details>` : ""}
      ${o ? "<p><strong>Bleeds out and dies unless Fate intervenes.</strong></p>" : ""}
    </section>`,
		flags: { [Z]: { bleedingTurn: {
			bleeding: t,
			bleedOutTotal: a?.total,
			damage: r.total,
			died: o
		} } },
		speaker: ChatMessage.getSpeaker({ actor: e })
	});
}
function zc(e, t, n) {
	!Pc() || !Eo() || !t?.actor || Nc.get(e.id) !== n && (Nc.set(e.id, n), Qo("Bleeding turn resolution", Rc(t.actor)));
}
function Bc() {
	Hooks.on("combatStart", ((e, t) => {
		let n = e.turns?.[t.turn];
		zc(e, n, `${t.round}:${t.turn}:${n?.id ?? ""}`);
	})), Hooks.on("combatTurnChange", ((e, t, n) => {
		zc(e, n.combatantId ? e.combatants.get(n.combatantId) : void 0, `${n.round}:${n.turn ?? ""}:${n.combatantId ?? ""}`);
	}));
}
//#endregion
//#region src/module/ui/register-ui-hooks.ts
function Vc() {
	new Ls().render(!0);
}
function Hc() {
	Hooks.on("getSceneControlButtons", ((e) => {
		let t = e.tokens;
		t && (t.tools ??= {}, t.tools[Z] = {
			name: Z,
			title: "Open Grimdark 5e dashboard",
			icon: "fa-solid fa-shield-halved",
			order: Object.keys(t.tools).length,
			button: !0,
			visible: !0,
			onChange: Vc
		});
	}));
}
//#endregion
//#region src/module/hooks/register-module-hooks.ts
function Uc() {
	Hooks.once("init", () => {
		Vs(), To(), Bs(), Bc(), fs(), Mc(), ic(), cc(), Hc(), Hooks.once("ready", () => {
			Hs();
		});
	});
}
//#endregion
//#region src/main.ts
Uc();
//#endregion

//# sourceMappingURL=grimdark-5e.mjs.map