//#region src/functions/combat/toughness.ts
function e(e) {
	return e.constitutionModifier + (e.proficiencyBonus - 2);
}
//#endregion
//#region src/functions/combat/damage-negation.ts
function t(t) {
	let n = t.toughnessApplies === !1 ? 0 : e(t), r = t.armourApplies === !1 ? 0 : Math.max(0, (t.armourBaseAc ?? 10) - 10), i = t.shieldApplies === !1 ? 0 : t.shieldBonus ?? 0, a = t.tanking ? t.strengthModifier ?? 0 : 0;
	return {
		armour: r,
		shield: i,
		tanking: a,
		toughness: n,
		total: n + r + i + a
	};
}
//#endregion
//#region src/functions/combat/defense-responses.ts
var n = [
	{
		criticalEffect: "A natural 20 inflicts a Critical Injury on the attacker.",
		id: "parry",
		label: "Parry",
		opposed: !0,
		summary: "Oppose the attack with a weapon-based defense roll."
	},
	{
		criticalEffect: "A natural 20 negates all damage, even if the attacker wins the exchange.",
		id: "dodge",
		label: "Dodge",
		opposed: !0,
		summary: "Oppose the attack using Dexterity and movement."
	},
	{
		criticalEffect: "No defense roll means no defensive critical.",
		id: "tank",
		label: "Tank the Hit",
		opposed: !1,
		summary: "Accept the hit and add Strength modifier to Negation for this hit."
	},
	{
		criticalEffect: "No defense roll means no defensive critical.",
		id: "unopposed",
		label: "Unopposed",
		opposed: !1,
		summary: "Resolve the attack without a defense roll."
	},
	{
		criticalEffect: "A successful Surprised attack inflicts one unmodified Critical Injury; damage dice are not doubled.",
		id: "surprised",
		label: "Surprised",
		opposed: !1,
		summary: "Resolve the attack without a defense roll and inflict a Critical Injury if it deals damage."
	}
];
//#endregion
//#region src/functions/combat/momentum-cap.ts
function r(e) {
	return Math.max(1, Math.trunc(e));
}
//#endregion
//#region src/functions/combat/resolve-damage-after-negation.ts
function i(e) {
	return e.damage <= 0 ? 0 : Math.max(1, e.damage - e.negation);
}
//#endregion
//#region node_modules/@vue/shared/dist/shared.esm-bundler.js
// @__NO_SIDE_EFFECTS__
function a(e) {
	let t = /* @__PURE__ */ Object.create(null);
	for (let n of e.split(",")) t[n] = 1;
	return (e) => e in t;
}
var o = {}, s = [], c = () => {}, l = () => !1, u = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && (e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97), d = (e) => e.startsWith("onUpdate:"), f = Object.assign, p = (e, t) => {
	let n = e.indexOf(t);
	n > -1 && e.splice(n, 1);
}, m = Object.prototype.hasOwnProperty, h = (e, t) => m.call(e, t), g = Array.isArray, _ = (e) => te(e) === "[object Map]", v = (e) => te(e) === "[object Set]", y = (e) => te(e) === "[object Date]", b = (e) => typeof e == "function", x = (e) => typeof e == "string", S = (e) => typeof e == "symbol", C = (e) => typeof e == "object" && !!e, w = (e) => (C(e) || b(e)) && b(e.then) && b(e.catch), ee = Object.prototype.toString, te = (e) => ee.call(e), ne = (e) => te(e).slice(8, -1), re = (e) => te(e) === "[object Object]", ie = (e) => x(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e, ae = /* @__PURE__ */ a(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"), oe = (e) => {
	let t = /* @__PURE__ */ Object.create(null);
	return ((n) => t[n] || (t[n] = e(n)));
}, se = /-\w/g, T = oe((e) => e.replace(se, (e) => e.slice(1).toUpperCase())), ce = /\B([A-Z])/g, E = oe((e) => e.replace(ce, "-$1").toLowerCase()), le = oe((e) => e.charAt(0).toUpperCase() + e.slice(1)), ue = oe((e) => e ? `on${le(e)}` : ""), D = (e, t) => !Object.is(e, t), de = (e, ...t) => {
	for (let n = 0; n < e.length; n++) e[n](...t);
}, fe = (e, t, n, r = !1) => {
	Object.defineProperty(e, t, {
		configurable: !0,
		enumerable: !1,
		writable: r,
		value: n
	});
}, pe = (e) => {
	let t = parseFloat(e);
	return isNaN(t) ? e : t;
}, me, he = () => me ||= typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {};
function O(e) {
	if (g(e)) {
		let t = {};
		for (let n = 0; n < e.length; n++) {
			let r = e[n], i = x(r) ? ye(r) : O(r);
			if (i) for (let e in i) t[e] = i[e];
		}
		return t;
	} else if (x(e) || C(e)) return e;
}
var ge = /;(?![^(]*\))/g, _e = /:([^]+)/, ve = /\/\*[^]*?\*\//g;
function ye(e) {
	let t = {};
	return e.replace(ve, "").split(ge).forEach((e) => {
		if (e) {
			let n = e.split(_e);
			n.length > 1 && (t[n[0].trim()] = n[1].trim());
		}
	}), t;
}
function be(e) {
	let t = "";
	if (x(e)) t = e;
	else if (g(e)) for (let n = 0; n < e.length; n++) {
		let r = be(e[n]);
		r && (t += r + " ");
	}
	else if (C(e)) for (let n in e) e[n] && (t += n + " ");
	return t.trim();
}
var xe = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly", Se = /* @__PURE__ */ a(xe);
xe + "";
function Ce(e) {
	return !!e || e === "";
}
function we(e, t) {
	if (e.length !== t.length) return !1;
	let n = !0;
	for (let r = 0; n && r < e.length; r++) n = Te(e[r], t[r]);
	return n;
}
function Te(e, t) {
	if (e === t) return !0;
	let n = y(e), r = y(t);
	if (n || r) return n && r ? e.getTime() === t.getTime() : !1;
	if (n = S(e), r = S(t), n || r) return e === t;
	if (n = g(e), r = g(t), n || r) return n && r ? we(e, t) : !1;
	if (n = C(e), r = C(t), n || r) {
		if (!n || !r || Object.keys(e).length !== Object.keys(t).length) return !1;
		for (let n in e) {
			let r = e.hasOwnProperty(n), i = t.hasOwnProperty(n);
			if (r && !i || !r && i || !Te(e[n], t[n])) return !1;
		}
	}
	return String(e) === String(t);
}
var Ee = (e) => !!(e && e.__v_isRef === !0), k = (e) => x(e) ? e : e == null ? "" : g(e) || C(e) && (e.toString === ee || !b(e.toString)) ? Ee(e) ? k(e.value) : JSON.stringify(e, De, 2) : String(e), De = (e, t) => Ee(t) ? De(e, t.value) : _(t) ? { [`Map(${t.size})`]: [...t.entries()].reduce((e, [t, n], r) => (e[Oe(t, r) + " =>"] = n, e), {}) } : v(t) ? { [`Set(${t.size})`]: [...t.values()].map((e) => Oe(e)) } : S(t) ? Oe(t) : C(t) && !g(t) && !re(t) ? String(t) : t, Oe = (e, t = "") => S(e) ? `Symbol(${e.description ?? t})` : e, A, ke = class {
	constructor(e = !1) {
		this.detached = e, this._active = !0, this._on = 0, this.effects = [], this.cleanups = [], this._isPaused = !1, this._warnOnRun = !0, this.__v_skip = !0, !e && A && (A.active ? (this.parent = A, this.index = (A.scopes ||= []).push(this) - 1) : (this._active = !1, this._warnOnRun = !1));
	}
	get active() {
		return this._active;
	}
	pause() {
		if (this._active) {
			this._isPaused = !0;
			let e, t;
			if (this.scopes) for (e = 0, t = this.scopes.length; e < t; e++) this.scopes[e].pause();
			for (e = 0, t = this.effects.length; e < t; e++) this.effects[e].pause();
		}
	}
	resume() {
		if (this._active && this._isPaused) {
			this._isPaused = !1;
			let e, t;
			if (this.scopes) for (e = 0, t = this.scopes.length; e < t; e++) this.scopes[e].resume();
			for (e = 0, t = this.effects.length; e < t; e++) this.effects[e].resume();
		}
	}
	run(e) {
		if (this._active) {
			let t = A;
			try {
				return A = this, e();
			} finally {
				A = t;
			}
		}
	}
	on() {
		++this._on === 1 && (this.prevScope = A, A = this);
	}
	off() {
		if (this._on > 0 && --this._on === 0) {
			if (A === this) A = this.prevScope;
			else {
				let e = A;
				for (; e;) {
					if (e.prevScope === this) {
						e.prevScope = this.prevScope;
						break;
					}
					e = e.prevScope;
				}
			}
			this.prevScope = void 0;
		}
	}
	stop(e) {
		if (this._active) {
			this._active = !1;
			let t, n;
			for (t = 0, n = this.effects.length; t < n; t++) this.effects[t].stop();
			for (this.effects.length = 0, t = 0, n = this.cleanups.length; t < n; t++) this.cleanups[t]();
			if (this.cleanups.length = 0, this.scopes) {
				for (t = 0, n = this.scopes.length; t < n; t++) this.scopes[t].stop(!0);
				this.scopes.length = 0;
			}
			if (!this.detached && this.parent && !e) {
				let e = this.parent.scopes.pop();
				e && e !== this && (this.parent.scopes[this.index] = e, e.index = this.index);
			}
			this.parent = void 0;
		}
	}
};
function Ae(e) {
	return new ke(e);
}
function je() {
	return A;
}
var j, Me = /* @__PURE__ */ new WeakSet(), Ne = class {
	constructor(e) {
		this.fn = e, this.deps = void 0, this.depsTail = void 0, this.flags = 5, this.next = void 0, this.cleanup = void 0, this.scheduler = void 0, A && (A.active ? A.effects.push(this) : this.flags &= -2);
	}
	pause() {
		this.flags |= 64;
	}
	resume() {
		this.flags & 64 && (this.flags &= -65, Me.has(this) && (Me.delete(this), this.trigger()));
	}
	notify() {
		this.flags & 2 && !(this.flags & 32) || this.flags & 8 || Le(this);
	}
	run() {
		if (!(this.flags & 1)) return this.fn();
		this.flags |= 2, Ye(this), Be(this);
		let e = j, t = M;
		j = this, M = !0;
		try {
			return this.fn();
		} finally {
			Ve(this), j = e, M = t, this.flags &= -3;
		}
	}
	stop() {
		if (this.flags & 1) {
			for (let e = this.deps; e; e = e.nextDep) We(e);
			this.deps = this.depsTail = void 0, Ye(this), this.onStop && this.onStop(), this.flags &= -2;
		}
	}
	trigger() {
		this.flags & 64 ? Me.add(this) : this.scheduler ? this.scheduler() : this.runIfDirty();
	}
	runIfDirty() {
		He(this) && this.run();
	}
	get dirty() {
		return He(this);
	}
}, Pe = 0, Fe, Ie;
function Le(e, t = !1) {
	if (e.flags |= 8, t) {
		e.next = Ie, Ie = e;
		return;
	}
	e.next = Fe, Fe = e;
}
function Re() {
	Pe++;
}
function ze() {
	if (--Pe > 0) return;
	if (Ie) {
		let e = Ie;
		for (Ie = void 0; e;) {
			let t = e.next;
			e.next = void 0, e.flags &= -9, e = t;
		}
	}
	let e;
	for (; Fe;) {
		let t = Fe;
		for (Fe = void 0; t;) {
			let n = t.next;
			if (t.next = void 0, t.flags &= -9, t.flags & 1) try {
				t.trigger();
			} catch (t) {
				e ||= t;
			}
			t = n;
		}
	}
	if (e) throw e;
}
function Be(e) {
	for (let t = e.deps; t; t = t.nextDep) t.version = -1, t.prevActiveLink = t.dep.activeLink, t.dep.activeLink = t;
}
function Ve(e) {
	let t, n = e.depsTail, r = n;
	for (; r;) {
		let e = r.prevDep;
		r.version === -1 ? (r === n && (n = e), We(r), Ge(r)) : t = r, r.dep.activeLink = r.prevActiveLink, r.prevActiveLink = void 0, r = e;
	}
	e.deps = t, e.depsTail = n;
}
function He(e) {
	for (let t = e.deps; t; t = t.nextDep) if (t.dep.version !== t.version || t.dep.computed && (Ue(t.dep.computed) || t.dep.version !== t.version)) return !0;
	return !!e._dirty;
}
function Ue(e) {
	if (e.flags & 4 && !(e.flags & 16) || (e.flags &= -17, e.globalVersion === Xe) || (e.globalVersion = Xe, !e.isSSR && e.flags & 128 && (!e.deps && !e._dirty || !He(e)))) return;
	e.flags |= 2;
	let t = e.dep, n = j, r = M;
	j = e, M = !0;
	try {
		Be(e);
		let n = e.fn(e._value);
		(t.version === 0 || D(n, e._value)) && (e.flags |= 128, e._value = n, t.version++);
	} catch (e) {
		throw t.version++, e;
	} finally {
		j = n, M = r, Ve(e), e.flags &= -3;
	}
}
function We(e, t = !1) {
	let { dep: n, prevSub: r, nextSub: i } = e;
	if (r && (r.nextSub = i, e.prevSub = void 0), i && (i.prevSub = r, e.nextSub = void 0), n.subs === e && (n.subs = r, !r && n.computed)) {
		n.computed.flags &= -5;
		for (let e = n.computed.deps; e; e = e.nextDep) We(e, !0);
	}
	!t && !--n.sc && n.map && n.map.delete(n.key);
}
function Ge(e) {
	let { prevDep: t, nextDep: n } = e;
	t && (t.nextDep = n, e.prevDep = void 0), n && (n.prevDep = t, e.nextDep = void 0);
}
var M = !0, Ke = [];
function qe() {
	Ke.push(M), M = !1;
}
function Je() {
	let e = Ke.pop();
	M = e === void 0 ? !0 : e;
}
function Ye(e) {
	let { cleanup: t } = e;
	if (e.cleanup = void 0, t) {
		let e = j;
		j = void 0;
		try {
			t();
		} finally {
			j = e;
		}
	}
}
var Xe = 0, Ze = class {
	constructor(e, t) {
		this.sub = e, this.dep = t, this.version = t.version, this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
	}
}, Qe = class {
	constructor(e) {
		this.computed = e, this.version = 0, this.activeLink = void 0, this.subs = void 0, this.map = void 0, this.key = void 0, this.sc = 0, this.__v_skip = !0;
	}
	track(e) {
		if (!j || !M || j === this.computed) return;
		let t = this.activeLink;
		if (t === void 0 || t.sub !== j) t = this.activeLink = new Ze(j, this), j.deps ? (t.prevDep = j.depsTail, j.depsTail.nextDep = t, j.depsTail = t) : j.deps = j.depsTail = t, $e(t);
		else if (t.version === -1 && (t.version = this.version, t.nextDep)) {
			let e = t.nextDep;
			e.prevDep = t.prevDep, t.prevDep && (t.prevDep.nextDep = e), t.prevDep = j.depsTail, t.nextDep = void 0, j.depsTail.nextDep = t, j.depsTail = t, j.deps === t && (j.deps = e);
		}
		return t;
	}
	trigger(e) {
		this.version++, Xe++, this.notify(e);
	}
	notify(e) {
		Re();
		try {
			for (let e = this.subs; e; e = e.prevSub) e.sub.notify() && e.sub.dep.notify();
		} finally {
			ze();
		}
	}
};
function $e(e) {
	if (e.dep.sc++, e.sub.flags & 4) {
		let t = e.dep.computed;
		if (t && !e.dep.subs) {
			t.flags |= 20;
			for (let e = t.deps; e; e = e.nextDep) $e(e);
		}
		let n = e.dep.subs;
		n !== e && (e.prevSub = n, n && (n.nextSub = e)), e.dep.subs = e;
	}
}
var et = /* @__PURE__ */ new WeakMap(), tt = /* @__PURE__ */ Symbol(""), nt = /* @__PURE__ */ Symbol(""), rt = /* @__PURE__ */ Symbol("");
function N(e, t, n) {
	if (M && j) {
		let t = et.get(e);
		t || et.set(e, t = /* @__PURE__ */ new Map());
		let r = t.get(n);
		r || (t.set(n, r = new Qe()), r.map = t, r.key = n), r.track();
	}
}
function it(e, t, n, r, i, a) {
	let o = et.get(e);
	if (!o) {
		Xe++;
		return;
	}
	let s = (e) => {
		e && e.trigger();
	};
	if (Re(), t === "clear") o.forEach(s);
	else {
		let i = g(e), a = i && ie(n);
		if (i && n === "length") {
			let e = Number(r);
			o.forEach((t, n) => {
				(n === "length" || n === rt || !S(n) && n >= e) && s(t);
			});
		} else switch ((n !== void 0 || o.has(void 0)) && s(o.get(n)), a && s(o.get(rt)), t) {
			case "add":
				i ? a && s(o.get("length")) : (s(o.get(tt)), _(e) && s(o.get(nt)));
				break;
			case "delete":
				i || (s(o.get(tt)), _(e) && s(o.get(nt)));
				break;
			case "set":
				_(e) && s(o.get(tt));
				break;
		}
	}
	ze();
}
function at(e) {
	let t = /* @__PURE__ */ I(e);
	return t === e ? t : (N(t, "iterate", rt), /* @__PURE__ */ F(e) ? t : t.map(L));
}
function ot(e) {
	return N(e = /* @__PURE__ */ I(e), "iterate", rt), e;
}
function P(e, t) {
	return /* @__PURE__ */ Ht(e) ? Gt(/* @__PURE__ */ Vt(e) ? L(t) : t) : L(t);
}
var st = {
	__proto__: null,
	[Symbol.iterator]() {
		return ct(this, Symbol.iterator, (e) => P(this, e));
	},
	concat(...e) {
		return at(this).concat(...e.map((e) => g(e) ? at(e) : e));
	},
	entries() {
		return ct(this, "entries", (e) => (e[1] = P(this, e[1]), e));
	},
	every(e, t) {
		return ut(this, "every", e, t, void 0, arguments);
	},
	filter(e, t) {
		return ut(this, "filter", e, t, (e) => e.map((e) => P(this, e)), arguments);
	},
	find(e, t) {
		return ut(this, "find", e, t, (e) => P(this, e), arguments);
	},
	findIndex(e, t) {
		return ut(this, "findIndex", e, t, void 0, arguments);
	},
	findLast(e, t) {
		return ut(this, "findLast", e, t, (e) => P(this, e), arguments);
	},
	findLastIndex(e, t) {
		return ut(this, "findLastIndex", e, t, void 0, arguments);
	},
	forEach(e, t) {
		return ut(this, "forEach", e, t, void 0, arguments);
	},
	includes(...e) {
		return ft(this, "includes", e);
	},
	indexOf(...e) {
		return ft(this, "indexOf", e);
	},
	join(e) {
		return at(this).join(e);
	},
	lastIndexOf(...e) {
		return ft(this, "lastIndexOf", e);
	},
	map(e, t) {
		return ut(this, "map", e, t, void 0, arguments);
	},
	pop() {
		return pt(this, "pop");
	},
	push(...e) {
		return pt(this, "push", e);
	},
	reduce(e, ...t) {
		return dt(this, "reduce", e, t);
	},
	reduceRight(e, ...t) {
		return dt(this, "reduceRight", e, t);
	},
	shift() {
		return pt(this, "shift");
	},
	some(e, t) {
		return ut(this, "some", e, t, void 0, arguments);
	},
	splice(...e) {
		return pt(this, "splice", e);
	},
	toReversed() {
		return at(this).toReversed();
	},
	toSorted(e) {
		return at(this).toSorted(e);
	},
	toSpliced(...e) {
		return at(this).toSpliced(...e);
	},
	unshift(...e) {
		return pt(this, "unshift", e);
	},
	values() {
		return ct(this, "values", (e) => P(this, e));
	}
};
function ct(e, t, n) {
	let r = ot(e), i = r[t]();
	return r !== e && !/* @__PURE__ */ F(e) && (i._next = i.next, i.next = () => {
		let e = i._next();
		return e.done || (e.value = n(e.value)), e;
	}), i;
}
var lt = Array.prototype;
function ut(e, t, n, r, i, a) {
	let o = ot(e), s = o !== e && !/* @__PURE__ */ F(e), c = o[t];
	if (c !== lt[t]) {
		let t = c.apply(e, a);
		return s ? L(t) : t;
	}
	let l = n;
	o !== e && (s ? l = function(t, r) {
		return n.call(this, P(e, t), r, e);
	} : n.length > 2 && (l = function(t, r) {
		return n.call(this, t, r, e);
	}));
	let u = c.call(o, l, r);
	return s && i ? i(u) : u;
}
function dt(e, t, n, r) {
	let i = ot(e), a = i !== e && !/* @__PURE__ */ F(e), o = n, s = !1;
	i !== e && (a ? (s = r.length === 0, o = function(t, r, i) {
		return s && (s = !1, t = P(e, t)), n.call(this, t, P(e, r), i, e);
	}) : n.length > 3 && (o = function(t, r, i) {
		return n.call(this, t, r, i, e);
	}));
	let c = i[t](o, ...r);
	return s ? P(e, c) : c;
}
function ft(e, t, n) {
	let r = /* @__PURE__ */ I(e);
	N(r, "iterate", rt);
	let i = r[t](...n);
	return (i === -1 || i === !1) && /* @__PURE__ */ Ut(n[0]) ? (n[0] = /* @__PURE__ */ I(n[0]), r[t](...n)) : i;
}
function pt(e, t, n = []) {
	qe(), Re();
	let r = (/* @__PURE__ */ I(e))[t].apply(e, n);
	return ze(), Je(), r;
}
var mt = /* @__PURE__ */ a("__proto__,__v_isRef,__isVue"), ht = new Set(/* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((e) => e !== "arguments" && e !== "caller").map((e) => Symbol[e]).filter(S));
function gt(e) {
	S(e) || (e = String(e));
	let t = /* @__PURE__ */ I(this);
	return N(t, "has", e), t.hasOwnProperty(e);
}
var _t = class {
	constructor(e = !1, t = !1) {
		this._isReadonly = e, this._isShallow = t;
	}
	get(e, t, n) {
		if (t === "__v_skip") return e.__v_skip;
		let r = this._isReadonly, i = this._isShallow;
		if (t === "__v_isReactive") return !r;
		if (t === "__v_isReadonly") return r;
		if (t === "__v_isShallow") return i;
		if (t === "__v_raw") return n === (r ? i ? Ft : Pt : i ? Nt : Mt).get(e) || Object.getPrototypeOf(e) === Object.getPrototypeOf(n) ? e : void 0;
		let a = g(e);
		if (!r) {
			let e;
			if (a && (e = st[t])) return e;
			if (t === "hasOwnProperty") return gt;
		}
		let o = Reflect.get(e, t, /* @__PURE__ */ R(e) ? e : n);
		if ((S(t) ? ht.has(t) : mt(t)) || (r || N(e, "get", t), i)) return o;
		if (/* @__PURE__ */ R(o)) {
			let e = a && ie(t) ? o : o.value;
			return r && C(e) ? /* @__PURE__ */ zt(e) : e;
		}
		return C(o) ? r ? /* @__PURE__ */ zt(o) : /* @__PURE__ */ Lt(o) : o;
	}
}, vt = class extends _t {
	constructor(e = !1) {
		super(!1, e);
	}
	set(e, t, n, r) {
		let i = e[t], a = g(e) && ie(t);
		if (!this._isShallow) {
			let e = /* @__PURE__ */ Ht(i);
			if (!/* @__PURE__ */ F(n) && !/* @__PURE__ */ Ht(n) && (i = /* @__PURE__ */ I(i), n = /* @__PURE__ */ I(n)), !a && /* @__PURE__ */ R(i) && !/* @__PURE__ */ R(n)) return e || (i.value = n), !0;
		}
		let o = a ? Number(t) < e.length : h(e, t), s = Reflect.set(e, t, n, /* @__PURE__ */ R(e) ? e : r);
		return e === /* @__PURE__ */ I(r) && (o ? D(n, i) && it(e, "set", t, n, i) : it(e, "add", t, n)), s;
	}
	deleteProperty(e, t) {
		let n = h(e, t), r = e[t], i = Reflect.deleteProperty(e, t);
		return i && n && it(e, "delete", t, void 0, r), i;
	}
	has(e, t) {
		let n = Reflect.has(e, t);
		return (!S(t) || !ht.has(t)) && N(e, "has", t), n;
	}
	ownKeys(e) {
		return N(e, "iterate", g(e) ? "length" : tt), Reflect.ownKeys(e);
	}
}, yt = class extends _t {
	constructor(e = !1) {
		super(!0, e);
	}
	set(e, t) {
		return !0;
	}
	deleteProperty(e, t) {
		return !0;
	}
}, bt = /* @__PURE__ */ new vt(), xt = /* @__PURE__ */ new yt(), St = /* @__PURE__ */ new vt(!0), Ct = (e) => e, wt = (e) => Reflect.getPrototypeOf(e);
function Tt(e, t, n) {
	return function(...r) {
		let i = this.__v_raw, a = /* @__PURE__ */ I(i), o = _(a), s = e === "entries" || e === Symbol.iterator && o, c = e === "keys" && o, l = i[e](...r), u = n ? Ct : t ? Gt : L;
		return !t && N(a, "iterate", c ? nt : tt), f(Object.create(l), { next() {
			let { value: e, done: t } = l.next();
			return t ? {
				value: e,
				done: t
			} : {
				value: s ? [u(e[0]), u(e[1])] : u(e),
				done: t
			};
		} });
	};
}
function Et(e) {
	return function(...t) {
		return e === "delete" ? !1 : e === "clear" ? void 0 : this;
	};
}
function Dt(e, t) {
	let n = {
		get(n) {
			let r = this.__v_raw, i = /* @__PURE__ */ I(r), a = /* @__PURE__ */ I(n);
			e || (D(n, a) && N(i, "get", n), N(i, "get", a));
			let { has: o } = wt(i), s = t ? Ct : e ? Gt : L;
			if (o.call(i, n)) return s(r.get(n));
			if (o.call(i, a)) return s(r.get(a));
			r !== i && r.get(n);
		},
		get size() {
			let t = this.__v_raw;
			return !e && N(/* @__PURE__ */ I(t), "iterate", tt), t.size;
		},
		has(t) {
			let n = this.__v_raw, r = /* @__PURE__ */ I(n), i = /* @__PURE__ */ I(t);
			return e || (D(t, i) && N(r, "has", t), N(r, "has", i)), t === i ? n.has(t) : n.has(t) || n.has(i);
		},
		forEach(n, r) {
			let i = this, a = i.__v_raw, o = /* @__PURE__ */ I(a), s = t ? Ct : e ? Gt : L;
			return !e && N(o, "iterate", tt), a.forEach((e, t) => n.call(r, s(e), s(t), i));
		}
	};
	return f(n, e ? {
		add: Et("add"),
		set: Et("set"),
		delete: Et("delete"),
		clear: Et("clear")
	} : {
		add(e) {
			let n = /* @__PURE__ */ I(this), r = wt(n), i = /* @__PURE__ */ I(e), a = !t && !/* @__PURE__ */ F(e) && !/* @__PURE__ */ Ht(e) ? i : e;
			return r.has.call(n, a) || D(e, a) && r.has.call(n, e) || D(i, a) && r.has.call(n, i) || (n.add(a), it(n, "add", a, a)), this;
		},
		set(e, n) {
			!t && !/* @__PURE__ */ F(n) && !/* @__PURE__ */ Ht(n) && (n = /* @__PURE__ */ I(n));
			let r = /* @__PURE__ */ I(this), { has: i, get: a } = wt(r), o = i.call(r, e);
			o ||= (e = /* @__PURE__ */ I(e), i.call(r, e));
			let s = a.call(r, e);
			return r.set(e, n), o ? D(n, s) && it(r, "set", e, n, s) : it(r, "add", e, n), this;
		},
		delete(e) {
			let t = /* @__PURE__ */ I(this), { has: n, get: r } = wt(t), i = n.call(t, e);
			i ||= (e = /* @__PURE__ */ I(e), n.call(t, e));
			let a = r ? r.call(t, e) : void 0, o = t.delete(e);
			return i && it(t, "delete", e, void 0, a), o;
		},
		clear() {
			let e = /* @__PURE__ */ I(this), t = e.size !== 0, n = e.clear();
			return t && it(e, "clear", void 0, void 0, void 0), n;
		}
	}), [
		"keys",
		"values",
		"entries",
		Symbol.iterator
	].forEach((r) => {
		n[r] = Tt(r, e, t);
	}), n;
}
function Ot(e, t) {
	let n = Dt(e, t);
	return (t, r, i) => r === "__v_isReactive" ? !e : r === "__v_isReadonly" ? e : r === "__v_raw" ? t : Reflect.get(h(n, r) && r in t ? n : t, r, i);
}
var kt = { get: /* @__PURE__ */ Ot(!1, !1) }, At = { get: /* @__PURE__ */ Ot(!1, !0) }, jt = { get: /* @__PURE__ */ Ot(!0, !1) }, Mt = /* @__PURE__ */ new WeakMap(), Nt = /* @__PURE__ */ new WeakMap(), Pt = /* @__PURE__ */ new WeakMap(), Ft = /* @__PURE__ */ new WeakMap();
function It(e) {
	switch (e) {
		case "Object":
		case "Array": return 1;
		case "Map":
		case "Set":
		case "WeakMap":
		case "WeakSet": return 2;
		default: return 0;
	}
}
// @__NO_SIDE_EFFECTS__
function Lt(e) {
	return /* @__PURE__ */ Ht(e) ? e : Bt(e, !1, bt, kt, Mt);
}
// @__NO_SIDE_EFFECTS__
function Rt(e) {
	return Bt(e, !1, St, At, Nt);
}
// @__NO_SIDE_EFFECTS__
function zt(e) {
	return Bt(e, !0, xt, jt, Pt);
}
function Bt(e, t, n, r, i) {
	if (!C(e) || e.__v_raw && !(t && e.__v_isReactive) || e.__v_skip || !Object.isExtensible(e)) return e;
	let a = i.get(e);
	if (a) return a;
	let o = It(ne(e));
	if (o === 0) return e;
	let s = new Proxy(e, o === 2 ? r : n);
	return i.set(e, s), s;
}
// @__NO_SIDE_EFFECTS__
function Vt(e) {
	return /* @__PURE__ */ Ht(e) ? /* @__PURE__ */ Vt(e.__v_raw) : !!(e && e.__v_isReactive);
}
// @__NO_SIDE_EFFECTS__
function Ht(e) {
	return !!(e && e.__v_isReadonly);
}
// @__NO_SIDE_EFFECTS__
function F(e) {
	return !!(e && e.__v_isShallow);
}
// @__NO_SIDE_EFFECTS__
function Ut(e) {
	return e ? !!e.__v_raw : !1;
}
// @__NO_SIDE_EFFECTS__
function I(e) {
	let t = e && e.__v_raw;
	return t ? /* @__PURE__ */ I(t) : e;
}
function Wt(e) {
	return !h(e, "__v_skip") && Object.isExtensible(e) && fe(e, "__v_skip", !0), e;
}
var L = (e) => C(e) ? /* @__PURE__ */ Lt(e) : e, Gt = (e) => C(e) ? /* @__PURE__ */ zt(e) : e;
// @__NO_SIDE_EFFECTS__
function R(e) {
	return e ? e.__v_isRef === !0 : !1;
}
// @__NO_SIDE_EFFECTS__
function Kt(e) {
	return qt(e, !1);
}
function qt(e, t) {
	return /* @__PURE__ */ R(e) ? e : new Jt(e, t);
}
var Jt = class {
	constructor(e, t) {
		this.dep = new Qe(), this.__v_isRef = !0, this.__v_isShallow = !1, this._rawValue = t ? e : /* @__PURE__ */ I(e), this._value = t ? e : L(e), this.__v_isShallow = t;
	}
	get value() {
		return this.dep.track(), this._value;
	}
	set value(e) {
		let t = this._rawValue, n = this.__v_isShallow || /* @__PURE__ */ F(e) || /* @__PURE__ */ Ht(e);
		e = n ? e : /* @__PURE__ */ I(e), D(e, t) && (this._rawValue = e, this._value = n ? e : L(e), this.dep.trigger());
	}
};
function Yt(e) {
	return /* @__PURE__ */ R(e) ? e.value : e;
}
var Xt = {
	get: (e, t, n) => t === "__v_raw" ? e : Yt(Reflect.get(e, t, n)),
	set: (e, t, n, r) => {
		let i = e[t];
		return /* @__PURE__ */ R(i) && !/* @__PURE__ */ R(n) ? (i.value = n, !0) : Reflect.set(e, t, n, r);
	}
};
function Zt(e) {
	return /* @__PURE__ */ Vt(e) ? e : new Proxy(e, Xt);
}
var Qt = class {
	constructor(e, t, n) {
		this.fn = e, this.setter = t, this._value = void 0, this.dep = new Qe(this), this.__v_isRef = !0, this.deps = void 0, this.depsTail = void 0, this.flags = 16, this.globalVersion = Xe - 1, this.next = void 0, this.effect = this, this.__v_isReadonly = !t, this.isSSR = n;
	}
	notify() {
		if (this.flags |= 16, !(this.flags & 8) && j !== this) return Le(this, !0), !0;
	}
	get value() {
		let e = this.dep.track();
		return Ue(this), e && (e.version = this.dep.version), this._value;
	}
	set value(e) {
		this.setter && this.setter(e);
	}
};
// @__NO_SIDE_EFFECTS__
function $t(e, t, n = !1) {
	let r, i;
	return b(e) ? r = e : (r = e.get, i = e.set), new Qt(r, i, n);
}
var en = {}, tn = /* @__PURE__ */ new WeakMap(), nn = void 0;
function rn(e, t = !1, n = nn) {
	if (n) {
		let t = tn.get(n);
		t || tn.set(n, t = []), t.push(e);
	}
}
function an(e, t, n = o) {
	let { immediate: r, deep: i, once: a, scheduler: s, augmentJob: l, call: u } = n, d = (e) => i ? e : /* @__PURE__ */ F(e) || i === !1 || i === 0 ? on(e, 1) : on(e), f, m, h, _, v = !1, y = !1;
	if (/* @__PURE__ */ R(e) ? (m = () => e.value, v = /* @__PURE__ */ F(e)) : /* @__PURE__ */ Vt(e) ? (m = () => d(e), v = !0) : g(e) ? (y = !0, v = e.some((e) => /* @__PURE__ */ Vt(e) || /* @__PURE__ */ F(e)), m = () => e.map((e) => {
		if (/* @__PURE__ */ R(e)) return e.value;
		if (/* @__PURE__ */ Vt(e)) return d(e);
		if (b(e)) return u ? u(e, 2) : e();
	})) : m = b(e) ? t ? u ? () => u(e, 2) : e : () => {
		if (h) {
			qe();
			try {
				h();
			} finally {
				Je();
			}
		}
		let t = nn;
		nn = f;
		try {
			return u ? u(e, 3, [_]) : e(_);
		} finally {
			nn = t;
		}
	} : c, t && i) {
		let e = m, t = i === !0 ? Infinity : i;
		m = () => on(e(), t);
	}
	let x = je(), S = () => {
		f.stop(), x && x.active && p(x.effects, f);
	};
	if (a && t) {
		let e = t;
		t = (...t) => {
			let n = e(...t);
			return S(), n;
		};
	}
	let C = y ? Array(e.length).fill(en) : en, w = (e) => {
		if (!(!(f.flags & 1) || !f.dirty && !e)) if (t) {
			let n = f.run();
			if (e || i || v || (y ? n.some((e, t) => D(e, C[t])) : D(n, C))) {
				h && h();
				let e = nn;
				nn = f;
				try {
					let e = [
						n,
						C === en ? void 0 : y && C[0] === en ? [] : C,
						_
					];
					C = n, u ? u(t, 3, e) : t(...e);
				} finally {
					nn = e;
				}
			}
		} else f.run();
	};
	return l && l(w), f = new Ne(m), f.scheduler = s ? () => s(w, !1) : w, _ = (e) => rn(e, !1, f), h = f.onStop = () => {
		let e = tn.get(f);
		if (e) {
			if (u) u(e, 4);
			else for (let t of e) t();
			tn.delete(f);
		}
	}, t ? r ? w(!0) : C = f.run() : s ? s(w.bind(null, !0), !0) : f.run(), S.pause = f.pause.bind(f), S.resume = f.resume.bind(f), S.stop = S, S;
}
function on(e, t = Infinity, n) {
	if (t <= 0 || !C(e) || e.__v_skip || (n ||= /* @__PURE__ */ new Map(), (n.get(e) || 0) >= t)) return e;
	if (n.set(e, t), t--, /* @__PURE__ */ R(e)) on(e.value, t, n);
	else if (g(e)) for (let r = 0; r < e.length; r++) on(e[r], t, n);
	else if (v(e) || _(e)) e.forEach((e) => {
		on(e, t, n);
	});
	else if (re(e)) {
		for (let r in e) on(e[r], t, n);
		for (let r of Object.getOwnPropertySymbols(e)) Object.prototype.propertyIsEnumerable.call(e, r) && on(e[r], t, n);
	}
	return e;
}
//#endregion
//#region node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
function sn(e, t, n, r) {
	try {
		return r ? e(...r) : e();
	} catch (e) {
		cn(e, t, n);
	}
}
function z(e, t, n, r) {
	if (b(e)) {
		let i = sn(e, t, n, r);
		return i && w(i) && i.catch((e) => {
			cn(e, t, n);
		}), i;
	}
	if (g(e)) {
		let i = [];
		for (let a = 0; a < e.length; a++) i.push(z(e[a], t, n, r));
		return i;
	}
}
function cn(e, t, n, r = !0) {
	let i = t ? t.vnode : null, { errorHandler: a, throwUnhandledErrorInProduction: s } = t && t.appContext.config || o;
	if (t) {
		let r = t.parent, i = t.proxy, o = `https://vuejs.org/error-reference/#runtime-${n}`;
		for (; r;) {
			let t = r.ec;
			if (t) {
				for (let n = 0; n < t.length; n++) if (t[n](e, i, o) === !1) return;
			}
			r = r.parent;
		}
		if (a) {
			qe(), sn(a, null, 10, [
				e,
				i,
				o
			]), Je();
			return;
		}
	}
	ln(e, n, i, r, s);
}
function ln(e, t, n, r = !0, i = !1) {
	if (i) throw e;
	console.error(e);
}
var B = [], V = -1, un = [], dn = null, fn = 0, pn = /* @__PURE__ */ Promise.resolve(), mn = null;
function hn(e) {
	let t = mn || pn;
	return e ? t.then(this ? e.bind(this) : e) : t;
}
function gn(e) {
	let t = V + 1, n = B.length;
	for (; t < n;) {
		let r = t + n >>> 1, i = B[r], a = Sn(i);
		a < e || a === e && i.flags & 2 ? t = r + 1 : n = r;
	}
	return t;
}
function _n(e) {
	if (!(e.flags & 1)) {
		let t = Sn(e), n = B[B.length - 1];
		!n || !(e.flags & 2) && t >= Sn(n) ? B.push(e) : B.splice(gn(t), 0, e), e.flags |= 1, vn();
	}
}
function vn() {
	mn ||= pn.then(Cn);
}
function yn(e) {
	g(e) ? un.push(...e) : dn && e.id === -1 ? dn.splice(fn + 1, 0, e) : e.flags & 1 || (un.push(e), e.flags |= 1), vn();
}
function bn(e, t, n = V + 1) {
	for (; n < B.length; n++) {
		let t = B[n];
		if (t && t.flags & 2) {
			if (e && t.id !== e.uid) continue;
			B.splice(n, 1), n--, t.flags & 4 && (t.flags &= -2), t(), t.flags & 4 || (t.flags &= -2);
		}
	}
}
function xn(e) {
	if (un.length) {
		let e = [...new Set(un)].sort((e, t) => Sn(e) - Sn(t));
		if (un.length = 0, dn) {
			dn.push(...e);
			return;
		}
		for (dn = e, fn = 0; fn < dn.length; fn++) {
			let e = dn[fn];
			e.flags & 4 && (e.flags &= -2), e.flags & 8 || e(), e.flags &= -2;
		}
		dn = null, fn = 0;
	}
}
var Sn = (e) => e.id == null ? e.flags & 2 ? -1 : Infinity : e.id;
function Cn(e) {
	try {
		for (V = 0; V < B.length; V++) {
			let e = B[V];
			e && !(e.flags & 8) && (e.flags & 4 && (e.flags &= -2), sn(e, e.i, e.i ? 15 : 14), e.flags & 4 || (e.flags &= -2));
		}
	} finally {
		for (; V < B.length; V++) {
			let e = B[V];
			e && (e.flags &= -2);
		}
		V = -1, B.length = 0, xn(e), mn = null, (B.length || un.length) && Cn(e);
	}
}
var H = null, wn = null;
function Tn(e) {
	let t = H;
	return H = e, wn = e && e.type.__scopeId || null, t;
}
function En(e, t = H, n) {
	if (!t || e._n) return e;
	let r = (...n) => {
		r._d && ji(-1);
		let i = Tn(t), a;
		try {
			a = e(...n);
		} finally {
			Tn(i), r._d && ji(1);
		}
		return a;
	};
	return r._n = !0, r._c = !0, r._d = !0, r;
}
function Dn(e, t, n, r) {
	let i = e.dirs, a = t && t.dirs;
	for (let o = 0; o < i.length; o++) {
		let s = i[o];
		a && (s.oldValue = a[o].value);
		let c = s.dir[r];
		c && (qe(), z(c, n, 8, [
			e.el,
			s,
			e,
			t
		]), Je());
	}
}
function On(e, t) {
	if (X) {
		let n = X.provides, r = X.parent && X.parent.provides;
		r === n && (n = X.provides = Object.create(r)), n[e] = t;
	}
}
function kn(e, t, n = !1) {
	let r = Zi();
	if (r || Pr) {
		let i = Pr ? Pr._context.provides : r ? r.parent == null || r.ce ? r.vnode.appContext && r.vnode.appContext.provides : r.parent.provides : void 0;
		if (i && e in i) return i[e];
		if (arguments.length > 1) return n && b(t) ? t.call(r && r.proxy) : t;
	}
}
var An = /* @__PURE__ */ Symbol.for("v-scx"), jn = () => kn(An);
function Mn(e, t, n) {
	return Nn(e, t, n);
}
function Nn(e, t, n = o) {
	let { immediate: r, deep: i, flush: a, once: s } = n, l = f({}, n), u = t && r || !t && a !== "post", d;
	if (ra) {
		if (a === "sync") {
			let e = jn();
			d = e.__watcherHandles ||= [];
		} else if (!u) {
			let e = () => {};
			return e.stop = c, e.resume = c, e.pause = c, e;
		}
	}
	let p = X;
	l.call = (e, t, n) => z(e, p, t, n);
	let m = !1;
	a === "post" ? l.scheduler = (e) => {
		W(e, p && p.suspense);
	} : a !== "sync" && (m = !0, l.scheduler = (e, t) => {
		t ? e() : _n(e);
	}), l.augmentJob = (e) => {
		t && (e.flags |= 4), m && (e.flags |= 2, p && (e.id = p.uid, e.i = p));
	};
	let h = an(e, t, l);
	return ra && (d ? d.push(h) : u && h()), h;
}
function Pn(e, t, n) {
	let r = this.proxy, i = x(e) ? e.includes(".") ? Fn(r, e) : () => r[e] : e.bind(r, r), a;
	b(t) ? a = t : (a = t.handler, n = t);
	let o = ea(this), s = Nn(i, a.bind(r), n);
	return o(), s;
}
function Fn(e, t) {
	let n = t.split(".");
	return () => {
		let t = e;
		for (let e = 0; e < n.length && t; e++) t = t[n[e]];
		return t;
	};
}
var In = /* @__PURE__ */ Symbol("_vte"), Ln = (e) => e.__isTeleport, Rn = /* @__PURE__ */ Symbol("_leaveCb");
function zn(e, t) {
	e.shapeFlag & 6 && e.component ? (e.transition = t, zn(e.component.subTree, t)) : e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t;
}
// @__NO_SIDE_EFFECTS__
function Bn(e, t) {
	return b(e) ? /* @__PURE__ */ f({ name: e.name }, t, { setup: e }) : e;
}
function Vn(e) {
	e.ids = [
		e.ids[0] + e.ids[2]++ + "-",
		0,
		0
	];
}
function Hn(e, t) {
	let n;
	return !!((n = Object.getOwnPropertyDescriptor(e, t)) && !n.configurable);
}
var Un = /* @__PURE__ */ new WeakMap();
function Wn(e, t, n, r, i = !1) {
	if (g(e)) {
		e.forEach((e, a) => Wn(e, t && (g(t) ? t[a] : t), n, r, i));
		return;
	}
	if (Kn(r) && !i) {
		r.shapeFlag & 512 && r.type.__asyncResolved && r.component.subTree.component && Wn(e, t, n, r.component.subTree);
		return;
	}
	let a = r.shapeFlag & 4 ? fa(r.component) : r.el, s = i ? null : a, { i: c, r: u } = e, d = t && t.r, f = c.refs === o ? c.refs = {} : c.refs, m = c.setupState, _ = /* @__PURE__ */ I(m), v = m === o ? l : (e) => Hn(f, e) ? !1 : h(_, e), y = (e, t) => !(t && Hn(f, t));
	if (d != null && d !== u) {
		if (Gn(t), x(d)) f[d] = null, v(d) && (m[d] = null);
		else if (/* @__PURE__ */ R(d)) {
			let e = t;
			y(d, e.k) && (d.value = null), e.k && (f[e.k] = null);
		}
	}
	if (b(u)) sn(u, c, 12, [s, f]);
	else {
		let t = x(u), r = /* @__PURE__ */ R(u);
		if (t || r) {
			let o = () => {
				if (e.f) {
					let n = t ? v(u) ? m[u] : f[u] : y(u) || !e.k ? u.value : f[e.k];
					if (i) g(n) && p(n, a);
					else if (g(n)) n.includes(a) || n.push(a);
					else if (t) f[u] = [a], v(u) && (m[u] = f[u]);
					else {
						let t = [a];
						y(u, e.k) && (u.value = t), e.k && (f[e.k] = t);
					}
				} else t ? (f[u] = s, v(u) && (m[u] = s)) : r && (y(u, e.k) && (u.value = s), e.k && (f[e.k] = s));
			};
			if (s) {
				let t = () => {
					o(), Un.delete(e);
				};
				t.id = -1, Un.set(e, t), W(t, n);
			} else Gn(e), o();
		}
	}
}
function Gn(e) {
	let t = Un.get(e);
	t && (t.flags |= 8, Un.delete(e));
}
he().requestIdleCallback, he().cancelIdleCallback;
var Kn = (e) => !!e.type.__asyncLoader, qn = (e) => e.type.__isKeepAlive;
function Jn(e, t) {
	Xn(e, "a", t);
}
function Yn(e, t) {
	Xn(e, "da", t);
}
function Xn(e, t, n = X) {
	let r = e.__wdc ||= () => {
		let t = n;
		for (; t;) {
			if (t.isDeactivated) return;
			t = t.parent;
		}
		return e();
	};
	if (Qn(t, r, n), n) {
		let e = n.parent;
		for (; e && e.parent;) qn(e.parent.vnode) && Zn(r, t, n, e), e = e.parent;
	}
}
function Zn(e, t, n, r) {
	let i = Qn(t, e, r, !0);
	ar(() => {
		p(r[t], i);
	}, n);
}
function Qn(e, t, n = X, r = !1) {
	if (n) {
		let i = n[e] || (n[e] = []), a = t.__weh ||= (...r) => {
			qe();
			let i = ea(n), a = z(t, n, e, r);
			return i(), Je(), a;
		};
		return r ? i.unshift(a) : i.push(a), a;
	}
}
var $n = (e) => (t, n = X) => {
	(!ra || e === "sp") && Qn(e, (...e) => t(...e), n);
}, er = $n("bm"), tr = $n("m"), nr = $n("bu"), rr = $n("u"), ir = $n("bum"), ar = $n("um"), or = $n("sp"), sr = $n("rtg"), cr = $n("rtc");
function lr(e, t = X) {
	Qn("ec", e, t);
}
var ur = /* @__PURE__ */ Symbol.for("v-ndc");
function dr(e, t, n, r) {
	let i, a = n && n[r], o = g(e);
	if (o || x(e)) {
		let n = o && /* @__PURE__ */ Vt(e), r = !1, s = !1;
		n && (r = !/* @__PURE__ */ F(e), s = /* @__PURE__ */ Ht(e), e = ot(e)), i = Array(e.length);
		for (let n = 0, o = e.length; n < o; n++) i[n] = t(r ? s ? Gt(L(e[n])) : L(e[n]) : e[n], n, void 0, a && a[n]);
	} else if (typeof e == "number") {
		i = Array(e);
		for (let n = 0; n < e; n++) i[n] = t(n + 1, n, void 0, a && a[n]);
	} else if (C(e)) if (e[Symbol.iterator]) i = Array.from(e, (e, n) => t(e, n, void 0, a && a[n]));
	else {
		let n = Object.keys(e);
		i = Array(n.length);
		for (let r = 0, o = n.length; r < o; r++) {
			let o = n[r];
			i[r] = t(e[o], o, r, a && a[r]);
		}
	}
	else i = [];
	return n && (n[r] = i), i;
}
var fr = (e) => e ? na(e) ? fa(e) : fr(e.parent) : null, pr = /* @__PURE__ */ f(/* @__PURE__ */ Object.create(null), {
	$: (e) => e,
	$el: (e) => e.vnode.el,
	$data: (e) => e.data,
	$props: (e) => e.props,
	$attrs: (e) => e.attrs,
	$slots: (e) => e.slots,
	$refs: (e) => e.refs,
	$parent: (e) => fr(e.parent),
	$root: (e) => fr(e.root),
	$host: (e) => e.ce,
	$emit: (e) => e.emit,
	$options: (e) => Sr(e),
	$forceUpdate: (e) => e.f ||= () => {
		_n(e.update);
	},
	$nextTick: (e) => e.n ||= hn.bind(e.proxy),
	$watch: (e) => Pn.bind(e)
}), mr = (e, t) => e !== o && !e.__isScriptSetup && h(e, t), hr = {
	get({ _: e }, t) {
		if (t === "__v_skip") return !0;
		let { ctx: n, setupState: r, data: i, props: a, accessCache: s, type: c, appContext: l } = e;
		if (t[0] !== "$") {
			let e = s[t];
			if (e !== void 0) switch (e) {
				case 1: return r[t];
				case 2: return i[t];
				case 4: return n[t];
				case 3: return a[t];
			}
			else if (mr(r, t)) return s[t] = 1, r[t];
			else if (i !== o && h(i, t)) return s[t] = 2, i[t];
			else if (h(a, t)) return s[t] = 3, a[t];
			else if (n !== o && h(n, t)) return s[t] = 4, n[t];
			else _r && (s[t] = 0);
		}
		let u = pr[t], d, f;
		if (u) return t === "$attrs" && N(e.attrs, "get", ""), u(e);
		if ((d = c.__cssModules) && (d = d[t])) return d;
		if (n !== o && h(n, t)) return s[t] = 4, n[t];
		if (f = l.config.globalProperties, h(f, t)) return f[t];
	},
	set({ _: e }, t, n) {
		let { data: r, setupState: i, ctx: a } = e;
		return mr(i, t) ? (i[t] = n, !0) : r !== o && h(r, t) ? (r[t] = n, !0) : h(e.props, t) || t[0] === "$" && t.slice(1) in e ? !1 : (a[t] = n, !0);
	},
	has({ _: { data: e, setupState: t, accessCache: n, ctx: r, appContext: i, props: a, type: s } }, c) {
		let l;
		return !!(n[c] || e !== o && c[0] !== "$" && h(e, c) || mr(t, c) || h(a, c) || h(r, c) || h(pr, c) || h(i.config.globalProperties, c) || (l = s.__cssModules) && l[c]);
	},
	defineProperty(e, t, n) {
		return n.get == null ? h(n, "value") && this.set(e, t, n.value, null) : e._.accessCache[t] = 0, Reflect.defineProperty(e, t, n);
	}
};
function gr(e) {
	return g(e) ? e.reduce((e, t) => (e[t] = null, e), {}) : e;
}
var _r = !0;
function vr(e) {
	let t = Sr(e), n = e.proxy, r = e.ctx;
	_r = !1, t.beforeCreate && br(t.beforeCreate, e, "bc");
	let { data: i, computed: a, methods: o, watch: s, provide: l, inject: u, created: d, beforeMount: f, mounted: p, beforeUpdate: m, updated: h, activated: _, deactivated: v, beforeDestroy: y, beforeUnmount: x, destroyed: S, unmounted: w, render: ee, renderTracked: te, renderTriggered: ne, errorCaptured: re, serverPrefetch: ie, expose: ae, inheritAttrs: oe, components: se, directives: T, filters: ce } = t;
	if (u && yr(u, r, null), o) for (let e in o) {
		let t = o[e];
		b(t) && (r[e] = t.bind(n));
	}
	if (i) {
		let t = i.call(n, n);
		C(t) && (e.data = /* @__PURE__ */ Lt(t));
	}
	if (_r = !0, a) for (let e in a) {
		let t = a[e], i = ma({
			get: b(t) ? t.bind(n, n) : b(t.get) ? t.get.bind(n, n) : c,
			set: !b(t) && b(t.set) ? t.set.bind(n) : c
		});
		Object.defineProperty(r, e, {
			enumerable: !0,
			configurable: !0,
			get: () => i.value,
			set: (e) => i.value = e
		});
	}
	if (s) for (let e in s) xr(s[e], r, n, e);
	if (l) {
		let e = b(l) ? l.call(n) : l;
		Reflect.ownKeys(e).forEach((t) => {
			On(t, e[t]);
		});
	}
	d && br(d, e, "c");
	function E(e, t) {
		g(t) ? t.forEach((t) => e(t.bind(n))) : t && e(t.bind(n));
	}
	if (E(er, f), E(tr, p), E(nr, m), E(rr, h), E(Jn, _), E(Yn, v), E(lr, re), E(cr, te), E(sr, ne), E(ir, x), E(ar, w), E(or, ie), g(ae)) if (ae.length) {
		let t = e.exposed ||= {};
		ae.forEach((e) => {
			Object.defineProperty(t, e, {
				get: () => n[e],
				set: (t) => n[e] = t,
				enumerable: !0
			});
		});
	} else e.exposed ||= {};
	ee && e.render === c && (e.render = ee), oe != null && (e.inheritAttrs = oe), se && (e.components = se), T && (e.directives = T), ie && Vn(e);
}
function yr(e, t, n = c) {
	g(e) && (e = Dr(e));
	for (let n in e) {
		let r = e[n], i;
		i = C(r) ? "default" in r ? kn(r.from || n, r.default, !0) : kn(r.from || n) : kn(r), /* @__PURE__ */ R(i) ? Object.defineProperty(t, n, {
			enumerable: !0,
			configurable: !0,
			get: () => i.value,
			set: (e) => i.value = e
		}) : t[n] = i;
	}
}
function br(e, t, n) {
	z(g(e) ? e.map((e) => e.bind(t.proxy)) : e.bind(t.proxy), t, n);
}
function xr(e, t, n, r) {
	let i = r.includes(".") ? Fn(n, r) : () => n[r];
	if (x(e)) {
		let n = t[e];
		b(n) && Mn(i, n);
	} else if (b(e)) Mn(i, e.bind(n));
	else if (C(e)) if (g(e)) e.forEach((e) => xr(e, t, n, r));
	else {
		let r = b(e.handler) ? e.handler.bind(n) : t[e.handler];
		b(r) && Mn(i, r, e);
	}
}
function Sr(e) {
	let t = e.type, { mixins: n, extends: r } = t, { mixins: i, optionsCache: a, config: { optionMergeStrategies: o } } = e.appContext, s = a.get(t), c;
	return s ? c = s : !i.length && !n && !r ? c = t : (c = {}, i.length && i.forEach((e) => Cr(c, e, o, !0)), Cr(c, t, o)), C(t) && a.set(t, c), c;
}
function Cr(e, t, n, r = !1) {
	let { mixins: i, extends: a } = t;
	a && Cr(e, a, n, !0), i && i.forEach((t) => Cr(e, t, n, !0));
	for (let i in t) if (!(r && i === "expose")) {
		let r = wr[i] || n && n[i];
		e[i] = r ? r(e[i], t[i]) : t[i];
	}
	return e;
}
var wr = {
	data: Tr,
	props: kr,
	emits: kr,
	methods: Or,
	computed: Or,
	beforeCreate: U,
	created: U,
	beforeMount: U,
	mounted: U,
	beforeUpdate: U,
	updated: U,
	beforeDestroy: U,
	beforeUnmount: U,
	destroyed: U,
	unmounted: U,
	activated: U,
	deactivated: U,
	errorCaptured: U,
	serverPrefetch: U,
	components: Or,
	directives: Or,
	watch: Ar,
	provide: Tr,
	inject: Er
};
function Tr(e, t) {
	return t ? e ? function() {
		return f(b(e) ? e.call(this, this) : e, b(t) ? t.call(this, this) : t);
	} : t : e;
}
function Er(e, t) {
	return Or(Dr(e), Dr(t));
}
function Dr(e) {
	if (g(e)) {
		let t = {};
		for (let n = 0; n < e.length; n++) t[e[n]] = e[n];
		return t;
	}
	return e;
}
function U(e, t) {
	return e ? [...new Set([].concat(e, t))] : t;
}
function Or(e, t) {
	return e ? f(/* @__PURE__ */ Object.create(null), e, t) : t;
}
function kr(e, t) {
	return e ? g(e) && g(t) ? [.../* @__PURE__ */ new Set([...e, ...t])] : f(/* @__PURE__ */ Object.create(null), gr(e), gr(t ?? {})) : t;
}
function Ar(e, t) {
	if (!e) return t;
	if (!t) return e;
	let n = f(/* @__PURE__ */ Object.create(null), e);
	for (let r in t) n[r] = U(e[r], t[r]);
	return n;
}
function jr() {
	return {
		app: null,
		config: {
			isNativeTag: l,
			performance: !1,
			globalProperties: {},
			optionMergeStrategies: {},
			errorHandler: void 0,
			warnHandler: void 0,
			compilerOptions: {}
		},
		mixins: [],
		components: {},
		directives: {},
		provides: /* @__PURE__ */ Object.create(null),
		optionsCache: /* @__PURE__ */ new WeakMap(),
		propsCache: /* @__PURE__ */ new WeakMap(),
		emitsCache: /* @__PURE__ */ new WeakMap()
	};
}
var Mr = 0;
function Nr(e, t) {
	return function(n, r = null) {
		b(n) || (n = f({}, n)), r != null && !C(r) && (r = null);
		let i = jr(), a = /* @__PURE__ */ new WeakSet(), o = [], s = !1, c = i.app = {
			_uid: Mr++,
			_component: n,
			_props: r,
			_container: null,
			_context: i,
			_instance: null,
			version: ha,
			get config() {
				return i.config;
			},
			set config(e) {},
			use(e, ...t) {
				return a.has(e) || (e && b(e.install) ? (a.add(e), e.install(c, ...t)) : b(e) && (a.add(e), e(c, ...t))), c;
			},
			mixin(e) {
				return i.mixins.includes(e) || i.mixins.push(e), c;
			},
			component(e, t) {
				return t ? (i.components[e] = t, c) : i.components[e];
			},
			directive(e, t) {
				return t ? (i.directives[e] = t, c) : i.directives[e];
			},
			mount(a, o, l) {
				if (!s) {
					let u = c._ceVNode || zi(n, r);
					return u.appContext = i, l === !0 ? l = "svg" : l === !1 && (l = void 0), o && t ? t(u, a) : e(u, a, l), s = !0, c._container = a, a.__vue_app__ = c, fa(u.component);
				}
			},
			onUnmount(e) {
				o.push(e);
			},
			unmount() {
				s && (z(o, c._instance, 16), e(null, c._container), delete c._container.__vue_app__);
			},
			provide(e, t) {
				return i.provides[e] = t, c;
			},
			runWithContext(e) {
				let t = Pr;
				Pr = c;
				try {
					return e();
				} finally {
					Pr = t;
				}
			}
		};
		return c;
	};
}
var Pr = null, Fr = (e, t) => t === "modelValue" || t === "model-value" ? e.modelModifiers : e[`${t}Modifiers`] || e[`${T(t)}Modifiers`] || e[`${E(t)}Modifiers`];
function Ir(e, t, ...n) {
	if (e.isUnmounted) return;
	let r = e.vnode.props || o, i = n, a = t.startsWith("update:"), s = a && Fr(r, t.slice(7));
	s && (s.trim && (i = n.map((e) => x(e) ? e.trim() : e)), s.number && (i = n.map(pe)));
	let c, l = r[c = ue(t)] || r[c = ue(T(t))];
	!l && a && (l = r[c = ue(E(t))]), l && z(l, e, 6, i);
	let u = r[c + "Once"];
	if (u) {
		if (!e.emitted) e.emitted = {};
		else if (e.emitted[c]) return;
		e.emitted[c] = !0, z(u, e, 6, i);
	}
}
var Lr = /* @__PURE__ */ new WeakMap();
function Rr(e, t, n = !1) {
	let r = n ? Lr : t.emitsCache, i = r.get(e);
	if (i !== void 0) return i;
	let a = e.emits, o = {}, s = !1;
	if (!b(e)) {
		let r = (e) => {
			let n = Rr(e, t, !0);
			n && (s = !0, f(o, n));
		};
		!n && t.mixins.length && t.mixins.forEach(r), e.extends && r(e.extends), e.mixins && e.mixins.forEach(r);
	}
	return !a && !s ? (C(e) && r.set(e, null), null) : (g(a) ? a.forEach((e) => o[e] = null) : f(o, a), C(e) && r.set(e, o), o);
}
function zr(e, t) {
	return !e || !u(t) ? !1 : (t = t.slice(2).replace(/Once$/, ""), h(e, t[0].toLowerCase() + t.slice(1)) || h(e, E(t)) || h(e, t));
}
function Br(e) {
	let { type: t, vnode: n, proxy: r, withProxy: i, propsOptions: [a], slots: o, attrs: s, emit: c, render: l, renderCache: u, props: f, data: p, setupState: m, ctx: h, inheritAttrs: g } = e, _ = Tn(e), v, y;
	try {
		if (n.shapeFlag & 4) {
			let e = i || r, t = e;
			v = J(l.call(t, e, u, f, m, p, h)), y = s;
		} else {
			let e = t;
			v = J(e.length > 1 ? e(f, {
				attrs: s,
				slots: o,
				emit: c
			}) : e(f, null)), y = t.props ? s : Vr(s);
		}
	} catch (t) {
		Di.length = 0, cn(t, e, 1), v = zi(Ti);
	}
	let b = v;
	if (y && g !== !1) {
		let e = Object.keys(y), { shapeFlag: t } = b;
		e.length && t & 7 && (a && e.some(d) && (y = Hr(y, a)), b = Hi(b, y, !1, !0));
	}
	return n.dirs && (b = Hi(b, null, !1, !0), b.dirs = b.dirs ? b.dirs.concat(n.dirs) : n.dirs), n.transition && zn(b, n.transition), v = b, Tn(_), v;
}
var Vr = (e) => {
	let t;
	for (let n in e) (n === "class" || n === "style" || u(n)) && ((t ||= {})[n] = e[n]);
	return t;
}, Hr = (e, t) => {
	let n = {};
	for (let r in e) (!d(r) || !(r.slice(9) in t)) && (n[r] = e[r]);
	return n;
};
function Ur(e, t, n) {
	let { props: r, children: i, component: a } = e, { props: o, children: s, patchFlag: c } = t, l = a.emitsOptions;
	if (t.dirs || t.transition) return !0;
	if (n && c >= 0) {
		if (c & 1024) return !0;
		if (c & 16) return r ? Wr(r, o, l) : !!o;
		if (c & 8) {
			let e = t.dynamicProps;
			for (let t = 0; t < e.length; t++) {
				let n = e[t];
				if (Gr(o, r, n) && !zr(l, n)) return !0;
			}
		}
	} else return (i || s) && (!s || !s.$stable) ? !0 : r === o ? !1 : r ? o ? Wr(r, o, l) : !0 : !!o;
	return !1;
}
function Wr(e, t, n) {
	let r = Object.keys(t);
	if (r.length !== Object.keys(e).length) return !0;
	for (let i = 0; i < r.length; i++) {
		let a = r[i];
		if (Gr(t, e, a) && !zr(n, a)) return !0;
	}
	return !1;
}
function Gr(e, t, n) {
	let r = e[n], i = t[n];
	return n === "style" && C(r) && C(i) ? !Te(r, i) : r !== i;
}
function Kr({ vnode: e, parent: t, suspense: n }, r) {
	for (; t;) {
		let n = t.subTree;
		if (n.suspense && n.suspense.activeBranch === e && (n.suspense.vnode.el = n.el = r, e = n), n === e) (e = t.vnode).el = r, t = t.parent;
		else break;
	}
	n && n.activeBranch === e && (n.vnode.el = r);
}
var qr = {}, Jr = () => Object.create(qr), Yr = (e) => Object.getPrototypeOf(e) === qr;
function Xr(e, t, n, r = !1) {
	let i = {}, a = Jr();
	e.propsDefaults = /* @__PURE__ */ Object.create(null), Qr(e, t, i, a);
	for (let t in e.propsOptions[0]) t in i || (i[t] = void 0);
	n ? e.props = r ? i : /* @__PURE__ */ Rt(i) : e.type.props ? e.props = i : e.props = a, e.attrs = a;
}
function Zr(e, t, n, r) {
	let { props: i, attrs: a, vnode: { patchFlag: o } } = e, s = /* @__PURE__ */ I(i), [c] = e.propsOptions, l = !1;
	if ((r || o > 0) && !(o & 16)) {
		if (o & 8) {
			let n = e.vnode.dynamicProps;
			for (let r = 0; r < n.length; r++) {
				let o = n[r];
				if (zr(e.emitsOptions, o)) continue;
				let u = t[o];
				if (c) if (h(a, o)) u !== a[o] && (a[o] = u, l = !0);
				else {
					let t = T(o);
					i[t] = $r(c, s, t, u, e, !1);
				}
				else u !== a[o] && (a[o] = u, l = !0);
			}
		}
	} else {
		Qr(e, t, i, a) && (l = !0);
		let r;
		for (let a in s) (!t || !h(t, a) && ((r = E(a)) === a || !h(t, r))) && (c ? n && (n[a] !== void 0 || n[r] !== void 0) && (i[a] = $r(c, s, a, void 0, e, !0)) : delete i[a]);
		if (a !== s) for (let e in a) (!t || !h(t, e)) && (delete a[e], l = !0);
	}
	l && it(e.attrs, "set", "");
}
function Qr(e, t, n, r) {
	let [i, a] = e.propsOptions, s = !1, c;
	if (t) for (let o in t) {
		if (ae(o)) continue;
		let l = t[o], u;
		i && h(i, u = T(o)) ? !a || !a.includes(u) ? n[u] = l : (c ||= {})[u] = l : zr(e.emitsOptions, o) || (!(o in r) || l !== r[o]) && (r[o] = l, s = !0);
	}
	if (a) {
		let t = /* @__PURE__ */ I(n), r = c || o;
		for (let o = 0; o < a.length; o++) {
			let s = a[o];
			n[s] = $r(i, t, s, r[s], e, !h(r, s));
		}
	}
	return s;
}
function $r(e, t, n, r, i, a) {
	let o = e[n];
	if (o != null) {
		let e = h(o, "default");
		if (e && r === void 0) {
			let e = o.default;
			if (o.type !== Function && !o.skipFactory && b(e)) {
				let { propsDefaults: a } = i;
				if (n in a) r = a[n];
				else {
					let o = ea(i);
					r = a[n] = e.call(null, t), o();
				}
			} else r = e;
			i.ce && i.ce._setProp(n, r);
		}
		o[0] && (a && !e ? r = !1 : o[1] && (r === "" || r === E(n)) && (r = !0));
	}
	return r;
}
var ei = /* @__PURE__ */ new WeakMap();
function ti(e, t, n = !1) {
	let r = n ? ei : t.propsCache, i = r.get(e);
	if (i) return i;
	let a = e.props, c = {}, l = [], u = !1;
	if (!b(e)) {
		let r = (e) => {
			u = !0;
			let [n, r] = ti(e, t, !0);
			f(c, n), r && l.push(...r);
		};
		!n && t.mixins.length && t.mixins.forEach(r), e.extends && r(e.extends), e.mixins && e.mixins.forEach(r);
	}
	if (!a && !u) return C(e) && r.set(e, s), s;
	if (g(a)) for (let e = 0; e < a.length; e++) {
		let t = T(a[e]);
		ni(t) && (c[t] = o);
	}
	else if (a) for (let e in a) {
		let t = T(e);
		if (ni(t)) {
			let n = a[e], r = c[t] = g(n) || b(n) ? { type: n } : f({}, n), i = r.type, o = !1, s = !0;
			if (g(i)) for (let e = 0; e < i.length; ++e) {
				let t = i[e], n = b(t) && t.name;
				if (n === "Boolean") {
					o = !0;
					break;
				} else n === "String" && (s = !1);
			}
			else o = b(i) && i.name === "Boolean";
			r[0] = o, r[1] = s, (o || h(r, "default")) && l.push(t);
		}
	}
	let d = [c, l];
	return C(e) && r.set(e, d), d;
}
function ni(e) {
	return e[0] !== "$" && !ae(e);
}
var ri = (e) => e === "_" || e === "_ctx" || e === "$stable", ii = (e) => g(e) ? e.map(J) : [J(e)], ai = (e, t, n) => {
	if (t._n) return t;
	let r = En((...e) => ii(t(...e)), n);
	return r._c = !1, r;
}, oi = (e, t, n) => {
	let r = e._ctx;
	for (let n in e) {
		if (ri(n)) continue;
		let i = e[n];
		if (b(i)) t[n] = ai(n, i, r);
		else if (i != null) {
			let e = ii(i);
			t[n] = () => e;
		}
	}
}, si = (e, t) => {
	let n = ii(t);
	e.slots.default = () => n;
}, ci = (e, t, n) => {
	for (let r in t) (n || !ri(r)) && (e[r] = t[r]);
}, li = (e, t, n) => {
	let r = e.slots = Jr();
	if (e.vnode.shapeFlag & 32) {
		let e = t._;
		e ? (ci(r, t, n), n && fe(r, "_", e, !0)) : oi(t, r);
	} else t && si(e, t);
}, di = (e, t, n) => {
	let { vnode: r, slots: i } = e, a = !0, s = o;
	if (r.shapeFlag & 32) {
		let e = t._;
		e ? n && e === 1 ? a = !1 : ci(i, t, n) : (a = !t.$stable, oi(t, i)), s = t;
	} else t && (si(e, t), s = { default: 1 });
	if (a) for (let e in i) !ri(e) && s[e] == null && delete i[e];
}, W = Ci;
function fi(e) {
	return pi(e);
}
function pi(e, t) {
	let n = he();
	n.__VUE__ = !0;
	let { insert: r, remove: i, patchProp: a, createElement: l, createText: u, createComment: d, setText: f, setElementText: p, parentNode: m, nextSibling: h, setScopeId: g = c, insertStaticContent: _ } = e, v = (e, t, n, r = null, i = null, a = null, o = void 0, s = null, c = !!t.dynamicChildren) => {
		if (e === t) return;
		e && !Ii(e, t) && (r = be(e), O(e, i, a, !0), e = null), t.patchFlag === -2 && (c = !1, t.dynamicChildren = null);
		let { type: l, ref: u, shapeFlag: d } = t;
		switch (l) {
			case wi:
				y(e, t, n, r);
				break;
			case Ti:
				b(e, t, n, r);
				break;
			case Ei:
				e ?? x(t, n, r, o);
				break;
			case G:
				se(e, t, n, r, i, a, o, s, c);
				break;
			default: d & 1 ? w(e, t, n, r, i, a, o, s, c) : d & 6 ? T(e, t, n, r, i, a, o, s, c) : (d & 64 || d & 128) && l.process(e, t, n, r, i, a, o, s, c, Ce);
		}
		u != null && i ? Wn(u, e && e.ref, a, t || e, !t) : u == null && e && e.ref != null && Wn(e.ref, null, a, e, !0);
	}, y = (e, t, n, i) => {
		if (e == null) r(t.el = u(t.children), n, i);
		else {
			let n = t.el = e.el;
			t.children !== e.children && f(n, t.children);
		}
	}, b = (e, t, n, i) => {
		e == null ? r(t.el = d(t.children || ""), n, i) : t.el = e.el;
	}, x = (e, t, n, r) => {
		[e.el, e.anchor] = _(e.children, t, n, r, e.el, e.anchor);
	}, S = ({ el: e, anchor: t }, n, i) => {
		let a;
		for (; e && e !== t;) a = h(e), r(e, n, i), e = a;
		r(t, n, i);
	}, C = ({ el: e, anchor: t }) => {
		let n;
		for (; e && e !== t;) n = h(e), i(e), e = n;
		i(t);
	}, w = (e, t, n, r, i, a, o, s, c) => {
		if (t.type === "svg" ? o = "svg" : t.type === "math" && (o = "mathml"), e == null) ee(t, n, r, i, a, o, s, c);
		else {
			let n = e.el && e.el._isVueCE ? e.el : null;
			try {
				n && n._beginPatch(), re(e, t, i, a, o, s, c);
			} finally {
				n && n._endPatch();
			}
		}
	}, ee = (e, t, n, i, o, s, c, u) => {
		let d, f, { props: m, shapeFlag: h, transition: g, dirs: _ } = e;
		if (d = e.el = l(e.type, s, m && m.is, m), h & 8 ? p(d, e.children) : h & 16 && ne(e.children, d, null, i, o, mi(e, s), c, u), _ && Dn(e, null, i, "created"), te(d, e, e.scopeId, c, i), m) {
			for (let e in m) e !== "value" && !ae(e) && a(d, e, null, m[e], s, i);
			"value" in m && a(d, "value", null, m.value, s), (f = m.onVnodeBeforeMount) && Y(f, i, e);
		}
		_ && Dn(e, null, i, "beforeMount");
		let v = gi(o, g);
		v && g.beforeEnter(d), r(d, t, n), ((f = m && m.onVnodeMounted) || v || _) && W(() => {
			try {
				f && Y(f, i, e), v && g.enter(d), _ && Dn(e, null, i, "mounted");
			} finally {}
		}, o);
	}, te = (e, t, n, r, i) => {
		if (n && g(e, n), r) for (let t = 0; t < r.length; t++) g(e, r[t]);
		if (i) {
			let n = i.subTree;
			if (t === n || Si(n.type) && (n.ssContent === t || n.ssFallback === t)) {
				let t = i.vnode;
				te(e, t, t.scopeId, t.slotScopeIds, i.parent);
			}
		}
	}, ne = (e, t, n, r, i, a, o, s, c = 0) => {
		for (let l = c; l < e.length; l++) v(null, e[l] = s ? Gi(e[l]) : J(e[l]), t, n, r, i, a, o, s);
	}, re = (e, t, n, r, i, s, c) => {
		let l = t.el = e.el, { patchFlag: u, dynamicChildren: d, dirs: f } = t;
		u |= e.patchFlag & 16;
		let m = e.props || o, h = t.props || o, g;
		if (n && hi(n, !1), (g = h.onVnodeBeforeUpdate) && Y(g, n, t, e), f && Dn(t, e, n, "beforeUpdate"), n && hi(n, !0), (m.innerHTML && h.innerHTML == null || m.textContent && h.textContent == null) && p(l, ""), d ? ie(e.dynamicChildren, d, l, n, r, mi(t, i), s) : c || D(e, t, l, null, n, r, mi(t, i), s, !1), u > 0) {
			if (u & 16) oe(l, m, h, n, i);
			else if (u & 2 && m.class !== h.class && a(l, "class", null, h.class, i), u & 4 && a(l, "style", m.style, h.style, i), u & 8) {
				let e = t.dynamicProps;
				for (let t = 0; t < e.length; t++) {
					let r = e[t], o = m[r], s = h[r];
					(s !== o || r === "value") && a(l, r, o, s, i, n);
				}
			}
			u & 1 && e.children !== t.children && p(l, t.children);
		} else !c && d == null && oe(l, m, h, n, i);
		((g = h.onVnodeUpdated) || f) && W(() => {
			g && Y(g, n, t, e), f && Dn(t, e, n, "updated");
		}, r);
	}, ie = (e, t, n, r, i, a, o) => {
		for (let s = 0; s < t.length; s++) {
			let c = e[s], l = t[s];
			v(c, l, c.el && (c.type === G || !Ii(c, l) || c.shapeFlag & 198) ? m(c.el) : n, null, r, i, a, o, !0);
		}
	}, oe = (e, t, n, r, i) => {
		if (t !== n) {
			if (t !== o) for (let o in t) !ae(o) && !(o in n) && a(e, o, t[o], null, i, r);
			for (let o in n) {
				if (ae(o)) continue;
				let s = n[o], c = t[o];
				s !== c && o !== "value" && a(e, o, c, s, i, r);
			}
			"value" in n && a(e, "value", t.value, n.value, i);
		}
	}, se = (e, t, n, i, a, o, s, c, l) => {
		let d = t.el = e ? e.el : u(""), f = t.anchor = e ? e.anchor : u(""), { patchFlag: p, dynamicChildren: m, slotScopeIds: h } = t;
		h && (c = c ? c.concat(h) : h), e == null ? (r(d, n, i), r(f, n, i), ne(t.children || [], n, f, a, o, s, c, l)) : p > 0 && p & 64 && m && e.dynamicChildren && e.dynamicChildren.length === m.length ? (ie(e.dynamicChildren, m, n, a, o, s, c), (t.key != null || a && t === a.subTree) && _i(e, t, !0)) : D(e, t, n, f, a, o, s, c, l);
	}, T = (e, t, n, r, i, a, o, s, c) => {
		t.slotScopeIds = s, e == null ? t.shapeFlag & 512 ? i.ctx.activate(t, n, r, o, c) : ce(t, n, r, i, a, o, c) : E(e, t, c);
	}, ce = (e, t, n, r, i, a, o) => {
		let s = e.component = Xi(e, r, i);
		if (qn(e) && (s.ctx.renderer = Ce), ia(s, !1, o), s.asyncDep) {
			if (i && i.registerDep(s, le, o), !e.el) {
				let r = s.subTree = zi(Ti);
				b(null, r, t, n), e.placeholder = r.el;
			}
		} else le(s, e, t, n, i, a, o);
	}, E = (e, t, n) => {
		let r = t.component = e.component;
		if (Ur(e, t, n)) if (r.asyncDep && !r.asyncResolved) {
			ue(r, t, n);
			return;
		} else r.next = t, r.update();
		else t.el = e.el, r.vnode = t;
	}, le = (e, t, n, r, i, a, o) => {
		let s = () => {
			if (e.isMounted) {
				let { next: t, bu: n, u: r, parent: s, vnode: c } = e;
				{
					let n = yi(e);
					if (n) {
						t && (t.el = c.el, ue(e, t, o)), n.asyncDep.then(() => {
							W(() => {
								e.isUnmounted || l();
							}, i);
						});
						return;
					}
				}
				let u = t, d;
				hi(e, !1), t ? (t.el = c.el, ue(e, t, o)) : t = c, n && de(n), (d = t.props && t.props.onVnodeBeforeUpdate) && Y(d, s, t, c), hi(e, !0);
				let f = Br(e), p = e.subTree;
				e.subTree = f, v(p, f, m(p.el), be(p), e, i, a), t.el = f.el, u === null && Kr(e, f.el), r && W(r, i), (d = t.props && t.props.onVnodeUpdated) && W(() => Y(d, s, t, c), i);
			} else {
				let o, { el: s, props: c } = t, { bm: l, m: u, parent: d, root: f, type: p } = e, m = Kn(t);
				if (hi(e, !1), l && de(l), !m && (o = c && c.onVnodeBeforeMount) && Y(o, d, t), hi(e, !0), s && Te) {
					let t = () => {
						e.subTree = Br(e), Te(s, e.subTree, e, i, null);
					};
					m && p.__asyncHydrate ? p.__asyncHydrate(s, e, t) : t();
				} else {
					f.ce && f.ce._hasShadowRoot() && f.ce._injectChildStyle(p, e.parent ? e.parent.type : void 0);
					let o = e.subTree = Br(e);
					v(null, o, n, r, e, i, a), t.el = o.el;
				}
				if (u && W(u, i), !m && (o = c && c.onVnodeMounted)) {
					let e = t;
					W(() => Y(o, d, e), i);
				}
				(t.shapeFlag & 256 || d && Kn(d.vnode) && d.vnode.shapeFlag & 256) && e.a && W(e.a, i), e.isMounted = !0, t = n = r = null;
			}
		};
		e.scope.on();
		let c = e.effect = new Ne(s);
		e.scope.off();
		let l = e.update = c.run.bind(c), u = e.job = c.runIfDirty.bind(c);
		u.i = e, u.id = e.uid, c.scheduler = () => _n(u), hi(e, !0), l();
	}, ue = (e, t, n) => {
		t.component = e;
		let r = e.vnode.props;
		e.vnode = t, e.next = null, Zr(e, t.props, r, n), di(e, t.children, n), qe(), bn(e), Je();
	}, D = (e, t, n, r, i, a, o, s, c = !1) => {
		let l = e && e.children, u = e ? e.shapeFlag : 0, d = t.children, { patchFlag: f, shapeFlag: m } = t;
		if (f > 0) {
			if (f & 128) {
				pe(l, d, n, r, i, a, o, s, c);
				return;
			} else if (f & 256) {
				fe(l, d, n, r, i, a, o, s, c);
				return;
			}
		}
		m & 8 ? (u & 16 && ye(l, i, a), d !== l && p(n, d)) : u & 16 ? m & 16 ? pe(l, d, n, r, i, a, o, s, c) : ye(l, i, a, !0) : (u & 8 && p(n, ""), m & 16 && ne(d, n, r, i, a, o, s, c));
	}, fe = (e, t, n, r, i, a, o, c, l) => {
		e ||= s, t ||= s;
		let u = e.length, d = t.length, f = Math.min(u, d), p;
		for (p = 0; p < f; p++) {
			let r = t[p] = l ? Gi(t[p]) : J(t[p]);
			v(e[p], r, n, null, i, a, o, c, l);
		}
		u > d ? ye(e, i, a, !0, !1, f) : ne(t, n, r, i, a, o, c, l, f);
	}, pe = (e, t, n, r, i, a, o, c, l) => {
		let u = 0, d = t.length, f = e.length - 1, p = d - 1;
		for (; u <= f && u <= p;) {
			let r = e[u], s = t[u] = l ? Gi(t[u]) : J(t[u]);
			if (Ii(r, s)) v(r, s, n, null, i, a, o, c, l);
			else break;
			u++;
		}
		for (; u <= f && u <= p;) {
			let r = e[f], s = t[p] = l ? Gi(t[p]) : J(t[p]);
			if (Ii(r, s)) v(r, s, n, null, i, a, o, c, l);
			else break;
			f--, p--;
		}
		if (u > f) {
			if (u <= p) {
				let e = p + 1, s = e < d ? t[e].el : r;
				for (; u <= p;) v(null, t[u] = l ? Gi(t[u]) : J(t[u]), n, s, i, a, o, c, l), u++;
			}
		} else if (u > p) for (; u <= f;) O(e[u], i, a, !0), u++;
		else {
			let m = u, h = u, g = /* @__PURE__ */ new Map();
			for (u = h; u <= p; u++) {
				let e = t[u] = l ? Gi(t[u]) : J(t[u]);
				e.key != null && g.set(e.key, u);
			}
			let _, y = 0, b = p - h + 1, x = !1, S = 0, C = Array(b);
			for (u = 0; u < b; u++) C[u] = 0;
			for (u = m; u <= f; u++) {
				let r = e[u];
				if (y >= b) {
					O(r, i, a, !0);
					continue;
				}
				let s;
				if (r.key != null) s = g.get(r.key);
				else for (_ = h; _ <= p; _++) if (C[_ - h] === 0 && Ii(r, t[_])) {
					s = _;
					break;
				}
				s === void 0 ? O(r, i, a, !0) : (C[s - h] = u + 1, s >= S ? S = s : x = !0, v(r, t[s], n, null, i, a, o, c, l), y++);
			}
			let w = x ? vi(C) : s;
			for (_ = w.length - 1, u = b - 1; u >= 0; u--) {
				let e = h + u, s = t[e], f = t[e + 1], p = e + 1 < d ? f.el || xi(f) : r;
				C[u] === 0 ? v(null, s, n, p, i, a, o, c, l) : x && (_ < 0 || u !== w[_] ? me(s, n, p, 2) : _--);
			}
		}
	}, me = (e, t, n, a, o = null) => {
		let { el: s, type: c, transition: l, children: u, shapeFlag: d } = e;
		if (d & 6) {
			me(e.component.subTree, t, n, a);
			return;
		}
		if (d & 128) {
			e.suspense.move(t, n, a);
			return;
		}
		if (d & 64) {
			c.move(e, t, n, Ce);
			return;
		}
		if (c === G) {
			r(s, t, n);
			for (let e = 0; e < u.length; e++) me(u[e], t, n, a);
			r(e.anchor, t, n);
			return;
		}
		if (c === Ei) {
			S(e, t, n);
			return;
		}
		if (a !== 2 && d & 1 && l) if (a === 0) l.persisted && !s[Rn] ? r(s, t, n) : (l.beforeEnter(s), r(s, t, n), W(() => l.enter(s), o));
		else {
			let { leave: a, delayLeave: o, afterLeave: c } = l, u = () => {
				e.ctx.isUnmounted ? i(s) : r(s, t, n);
			}, d = () => {
				let e = s._isLeaving || !!s[Rn];
				s._isLeaving && s[Rn](!0), l.persisted && !e ? u() : a(s, () => {
					u(), c && c();
				});
			};
			o ? o(s, u, d) : d();
		}
		else r(s, t, n);
	}, O = (e, t, n, r = !1, i = !1) => {
		let { type: a, props: o, ref: s, children: c, dynamicChildren: l, shapeFlag: u, patchFlag: d, dirs: f, cacheIndex: p, memo: m } = e;
		if (d === -2 && (i = !1), s != null && (qe(), Wn(s, null, n, e, !0), Je()), p != null && (t.renderCache[p] = void 0), u & 256) {
			t.ctx.deactivate(e);
			return;
		}
		let h = u & 1 && f, g = !Kn(e), _;
		if (g && (_ = o && o.onVnodeBeforeUnmount) && Y(_, t, e), u & 6) ve(e.component, n, r);
		else {
			if (u & 128) {
				e.suspense.unmount(n, r);
				return;
			}
			h && Dn(e, null, t, "beforeUnmount"), u & 64 ? e.type.remove(e, t, n, Ce, r) : l && !l.hasOnce && (a !== G || d > 0 && d & 64) ? ye(l, t, n, !1, !0) : (a === G && d & 384 || !i && u & 16) && ye(c, t, n), r && ge(e);
		}
		let v = m != null && p == null;
		(g && (_ = o && o.onVnodeUnmounted) || h || v) && W(() => {
			_ && Y(_, t, e), h && Dn(e, null, t, "unmounted"), v && (e.el = null);
		}, n);
	}, ge = (e) => {
		let { type: t, el: n, anchor: r, transition: a } = e;
		if (t === G) {
			_e(n, r);
			return;
		}
		if (t === Ei) {
			C(e);
			return;
		}
		let o = () => {
			i(n), a && !a.persisted && a.afterLeave && a.afterLeave();
		};
		if (e.shapeFlag & 1 && a && !a.persisted) {
			let { leave: t, delayLeave: r } = a, i = () => t(n, o);
			r ? r(e.el, o, i) : i();
		} else o();
	}, _e = (e, t) => {
		let n;
		for (; e !== t;) n = h(e), i(e), e = n;
		i(t);
	}, ve = (e, t, n) => {
		let { bum: r, scope: i, job: a, subTree: o, um: s, m: c, a: l } = e;
		bi(c), bi(l), r && de(r), i.stop(), a && (a.flags |= 8, O(o, e, t, n)), s && W(s, t), W(() => {
			e.isUnmounted = !0;
		}, t);
	}, ye = (e, t, n, r = !1, i = !1, a = 0) => {
		for (let o = a; o < e.length; o++) O(e[o], t, n, r, i);
	}, be = (e) => {
		if (e.shapeFlag & 6) return be(e.component.subTree);
		if (e.shapeFlag & 128) return e.suspense.next();
		let t = h(e.anchor || e.el), n = t && t[In];
		return n ? h(n) : t;
	}, xe = !1, Se = (e, t, n) => {
		let r;
		e == null ? t._vnode && (O(t._vnode, null, null, !0), r = t._vnode.component) : v(t._vnode || null, e, t, null, null, null, n), t._vnode = e, xe ||= (xe = !0, bn(r), xn(), !1);
	}, Ce = {
		p: v,
		um: O,
		m: me,
		r: ge,
		mt: ce,
		mc: ne,
		pc: D,
		pbc: ie,
		n: be,
		o: e
	}, we, Te;
	return t && ([we, Te] = t(Ce)), {
		render: Se,
		hydrate: we,
		createApp: Nr(Se, we)
	};
}
function mi({ type: e, props: t }, n) {
	return n === "svg" && e === "foreignObject" || n === "mathml" && e === "annotation-xml" && t && t.encoding && t.encoding.includes("html") ? void 0 : n;
}
function hi({ effect: e, job: t }, n) {
	n ? (e.flags |= 32, t.flags |= 4) : (e.flags &= -33, t.flags &= -5);
}
function gi(e, t) {
	return (!e || e && !e.pendingBranch) && t && !t.persisted;
}
function _i(e, t, n = !1) {
	let r = e.children, i = t.children;
	if (g(r) && g(i)) for (let e = 0; e < r.length; e++) {
		let t = r[e], a = i[e];
		a.shapeFlag & 1 && !a.dynamicChildren && ((a.patchFlag <= 0 || a.patchFlag === 32) && (a = i[e] = Gi(i[e]), a.el = t.el), !n && a.patchFlag !== -2 && _i(t, a)), a.type === wi && (a.patchFlag === -1 && (a = i[e] = Gi(a)), a.el = t.el), a.type === Ti && !a.el && (a.el = t.el);
	}
}
function vi(e) {
	let t = e.slice(), n = [0], r, i, a, o, s, c = e.length;
	for (r = 0; r < c; r++) {
		let c = e[r];
		if (c !== 0) {
			if (i = n[n.length - 1], e[i] < c) {
				t[r] = i, n.push(r);
				continue;
			}
			for (a = 0, o = n.length - 1; a < o;) s = a + o >> 1, e[n[s]] < c ? a = s + 1 : o = s;
			c < e[n[a]] && (a > 0 && (t[r] = n[a - 1]), n[a] = r);
		}
	}
	for (a = n.length, o = n[a - 1]; a-- > 0;) n[a] = o, o = t[o];
	return n;
}
function yi(e) {
	let t = e.subTree.component;
	if (t) return t.asyncDep && !t.asyncResolved ? t : yi(t);
}
function bi(e) {
	if (e) for (let t = 0; t < e.length; t++) e[t].flags |= 8;
}
function xi(e) {
	if (e.placeholder) return e.placeholder;
	let t = e.component;
	return t ? xi(t.subTree) : null;
}
var Si = (e) => e.__isSuspense;
function Ci(e, t) {
	t && t.pendingBranch ? g(e) ? t.effects.push(...e) : t.effects.push(e) : yn(e);
}
var G = /* @__PURE__ */ Symbol.for("v-fgt"), wi = /* @__PURE__ */ Symbol.for("v-txt"), Ti = /* @__PURE__ */ Symbol.for("v-cmt"), Ei = /* @__PURE__ */ Symbol.for("v-stc"), Di = [], K = null;
function Oi(e = !1) {
	Di.push(K = e ? null : []);
}
function ki() {
	Di.pop(), K = Di[Di.length - 1] || null;
}
var Ai = 1;
function ji(e, t = !1) {
	Ai += e, e < 0 && K && t && (K.hasOnce = !0);
}
function Mi(e) {
	return e.dynamicChildren = Ai > 0 ? K || s : null, ki(), Ai > 0 && K && K.push(e), e;
}
function Ni(e, t, n, r, i, a) {
	return Mi(q(e, t, n, r, i, a, !0));
}
function Pi(e, t, n, r, i) {
	return Mi(zi(e, t, n, r, i, !0));
}
function Fi(e) {
	return e ? e.__v_isVNode === !0 : !1;
}
function Ii(e, t) {
	return e.type === t.type && e.key === t.key;
}
var Li = ({ key: e }) => e ?? null, Ri = ({ ref: e, ref_key: t, ref_for: n }) => (typeof e == "number" && (e = "" + e), e == null ? null : x(e) || /* @__PURE__ */ R(e) || b(e) ? {
	i: H,
	r: e,
	k: t,
	f: !!n
} : e);
function q(e, t = null, n = null, r = 0, i = null, a = e === G ? 0 : 1, o = !1, s = !1) {
	let c = {
		__v_isVNode: !0,
		__v_skip: !0,
		type: e,
		props: t,
		key: t && Li(t),
		ref: t && Ri(t),
		scopeId: wn,
		slotScopeIds: null,
		children: n,
		component: null,
		suspense: null,
		ssContent: null,
		ssFallback: null,
		dirs: null,
		transition: null,
		el: null,
		anchor: null,
		target: null,
		targetStart: null,
		targetAnchor: null,
		staticCount: 0,
		shapeFlag: a,
		patchFlag: r,
		dynamicProps: i,
		dynamicChildren: null,
		appContext: null,
		ctx: H
	};
	return s ? (Ki(c, n), a & 128 && e.normalize(c)) : n && (c.shapeFlag |= x(n) ? 8 : 16), Ai > 0 && !o && K && (c.patchFlag > 0 || a & 6) && c.patchFlag !== 32 && K.push(c), c;
}
var zi = Bi;
function Bi(e, t = null, n = null, r = 0, i = null, a = !1) {
	if ((!e || e === ur) && (e = Ti), Fi(e)) {
		let r = Hi(e, t, !0);
		return n && Ki(r, n), Ai > 0 && !a && K && (r.shapeFlag & 6 ? K[K.indexOf(e)] = r : K.push(r)), r.patchFlag = -2, r;
	}
	if (pa(e) && (e = e.__vccOpts), t) {
		t = Vi(t);
		let { class: e, style: n } = t;
		e && !x(e) && (t.class = be(e)), C(n) && (/* @__PURE__ */ Ut(n) && !g(n) && (n = f({}, n)), t.style = O(n));
	}
	let o = x(e) ? 1 : Si(e) ? 128 : Ln(e) ? 64 : C(e) ? 4 : b(e) ? 2 : 0;
	return q(e, t, n, r, i, o, a, !0);
}
function Vi(e) {
	return e ? /* @__PURE__ */ Ut(e) || Yr(e) ? f({}, e) : e : null;
}
function Hi(e, t, n = !1, r = !1) {
	let { props: i, ref: a, patchFlag: o, children: s, transition: c } = e, l = t ? qi(i || {}, t) : i, u = {
		__v_isVNode: !0,
		__v_skip: !0,
		type: e.type,
		props: l,
		key: l && Li(l),
		ref: t && t.ref ? n && a ? g(a) ? a.concat(Ri(t)) : [a, Ri(t)] : Ri(t) : a,
		scopeId: e.scopeId,
		slotScopeIds: e.slotScopeIds,
		children: s,
		target: e.target,
		targetStart: e.targetStart,
		targetAnchor: e.targetAnchor,
		staticCount: e.staticCount,
		shapeFlag: e.shapeFlag,
		patchFlag: t && e.type !== G ? o === -1 ? 16 : o | 16 : o,
		dynamicProps: e.dynamicProps,
		dynamicChildren: e.dynamicChildren,
		appContext: e.appContext,
		dirs: e.dirs,
		transition: c,
		component: e.component,
		suspense: e.suspense,
		ssContent: e.ssContent && Hi(e.ssContent),
		ssFallback: e.ssFallback && Hi(e.ssFallback),
		placeholder: e.placeholder,
		el: e.el,
		anchor: e.anchor,
		ctx: e.ctx,
		ce: e.ce
	};
	return c && r && zn(u, c.clone(u)), u;
}
function Ui(e = " ", t = 0) {
	return zi(wi, null, e, t);
}
function Wi(e = "", t = !1) {
	return t ? (Oi(), Pi(Ti, null, e)) : zi(Ti, null, e);
}
function J(e) {
	return e == null || typeof e == "boolean" ? zi(Ti) : g(e) ? zi(G, null, e.slice()) : Fi(e) ? Gi(e) : zi(wi, null, String(e));
}
function Gi(e) {
	return e.el === null && e.patchFlag !== -1 || e.memo ? e : Hi(e);
}
function Ki(e, t) {
	let n = 0, { shapeFlag: r } = e;
	if (t == null) t = null;
	else if (g(t)) n = 16;
	else if (typeof t == "object") if (r & 65) {
		let n = t.default;
		n && (n._c && (n._d = !1), Ki(e, n()), n._c && (n._d = !0));
		return;
	} else {
		n = 32;
		let r = t._;
		!r && !Yr(t) ? t._ctx = H : r === 3 && H && (H.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024));
	}
	else b(t) ? (t = {
		default: t,
		_ctx: H
	}, n = 32) : (t = String(t), r & 64 ? (n = 16, t = [Ui(t)]) : n = 8);
	e.children = t, e.shapeFlag |= n;
}
function qi(...e) {
	let t = {};
	for (let n = 0; n < e.length; n++) {
		let r = e[n];
		for (let e in r) if (e === "class") t.class !== r.class && (t.class = be([t.class, r.class]));
		else if (e === "style") t.style = O([t.style, r.style]);
		else if (u(e)) {
			let n = t[e], i = r[e];
			i && n !== i && !(g(n) && n.includes(i)) ? t[e] = n ? [].concat(n, i) : i : i == null && n == null && !d(e) && (t[e] = i);
		} else e !== "" && (t[e] = r[e]);
	}
	return t;
}
function Y(e, t, n, r = null) {
	z(e, t, 7, [n, r]);
}
var Ji = jr(), Yi = 0;
function Xi(e, t, n) {
	let r = e.type, i = (t ? t.appContext : e.appContext) || Ji, a = {
		uid: Yi++,
		vnode: e,
		type: r,
		parent: t,
		appContext: i,
		root: null,
		next: null,
		subTree: null,
		effect: null,
		update: null,
		job: null,
		scope: new ke(!0),
		render: null,
		proxy: null,
		exposed: null,
		exposeProxy: null,
		withProxy: null,
		provides: t ? t.provides : Object.create(i.provides),
		ids: t ? t.ids : [
			"",
			0,
			0
		],
		accessCache: null,
		renderCache: [],
		components: null,
		directives: null,
		propsOptions: ti(r, i),
		emitsOptions: Rr(r, i),
		emit: null,
		emitted: null,
		propsDefaults: o,
		inheritAttrs: r.inheritAttrs,
		ctx: o,
		data: o,
		props: o,
		attrs: o,
		slots: o,
		refs: o,
		setupState: o,
		setupContext: null,
		suspense: n,
		suspenseId: n ? n.pendingId : 0,
		asyncDep: null,
		asyncResolved: !1,
		isMounted: !1,
		isUnmounted: !1,
		isDeactivated: !1,
		bc: null,
		c: null,
		bm: null,
		m: null,
		bu: null,
		u: null,
		um: null,
		bum: null,
		da: null,
		a: null,
		rtg: null,
		rtc: null,
		ec: null,
		sp: null
	};
	return a.ctx = { _: a }, a.root = t ? t.root : a, a.emit = Ir.bind(null, a), e.ce && e.ce(a), a;
}
var X = null, Zi = () => X || H, Qi, $i;
{
	let e = he(), t = (t, n) => {
		let r;
		return (r = e[t]) || (r = e[t] = []), r.push(n), (e) => {
			r.length > 1 ? r.forEach((t) => t(e)) : r[0](e);
		};
	};
	Qi = t("__VUE_INSTANCE_SETTERS__", (e) => X = e), $i = t("__VUE_SSR_SETTERS__", (e) => ra = e);
}
var ea = (e) => {
	let t = X;
	return Qi(e), e.scope.on(), () => {
		e.scope.off(), Qi(t);
	};
}, ta = () => {
	X && X.scope.off(), Qi(null);
};
function na(e) {
	return e.vnode.shapeFlag & 4;
}
var ra = !1;
function ia(e, t = !1, n = !1) {
	t && $i(t);
	let { props: r, children: i } = e.vnode, a = na(e);
	Xr(e, r, a, t), li(e, i, n || t);
	let o = a ? aa(e, t) : void 0;
	return t && $i(!1), o;
}
function aa(e, t) {
	let n = e.type;
	e.accessCache = /* @__PURE__ */ Object.create(null), e.proxy = new Proxy(e.ctx, hr);
	let { setup: r } = n;
	if (r) {
		qe();
		let n = e.setupContext = r.length > 1 ? da(e) : null, i = ea(e), a = sn(r, e, 0, [e.props, n]), o = w(a);
		if (Je(), i(), (o || e.sp) && !Kn(e) && Vn(e), o) {
			if (a.then(ta, ta), t) return a.then((n) => {
				oa(e, n, t);
			}).catch((t) => {
				cn(t, e, 0);
			});
			e.asyncDep = a;
		} else oa(e, a, t);
	} else la(e, t);
}
function oa(e, t, n) {
	b(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : C(t) && (e.setupState = Zt(t)), la(e, n);
}
var sa, ca;
function la(e, t, n) {
	let r = e.type;
	if (!e.render) {
		if (!t && sa && !r.render) {
			let t = r.template || Sr(e).template;
			if (t) {
				let { isCustomElement: n, compilerOptions: i } = e.appContext.config, { delimiters: a, compilerOptions: o } = r;
				r.render = sa(t, f(f({
					isCustomElement: n,
					delimiters: a
				}, i), o));
			}
		}
		e.render = r.render || c, ca && ca(e);
	}
	{
		let t = ea(e);
		qe();
		try {
			vr(e);
		} finally {
			Je(), t();
		}
	}
}
var ua = { get(e, t) {
	return N(e, "get", ""), e[t];
} };
function da(e) {
	return {
		attrs: new Proxy(e.attrs, ua),
		slots: e.slots,
		emit: e.emit,
		expose: (t) => {
			e.exposed = t || {};
		}
	};
}
function fa(e) {
	return e.exposed ? e.exposeProxy ||= new Proxy(Zt(Wt(e.exposed)), {
		get(t, n) {
			if (n in t) return t[n];
			if (n in pr) return pr[n](e);
		},
		has(e, t) {
			return t in e || t in pr;
		}
	}) : e.proxy;
}
function pa(e) {
	return b(e) && "__vccOpts" in e;
}
var ma = (e, t) => /* @__PURE__ */ $t(e, t, ra), ha = "3.5.38", ga = void 0, _a = typeof window < "u" && window.trustedTypes;
if (_a) try {
	ga = /* @__PURE__ */ _a.createPolicy("vue", { createHTML: (e) => e });
} catch {}
var va = ga ? (e) => ga.createHTML(e) : (e) => e, ya = "http://www.w3.org/2000/svg", ba = "http://www.w3.org/1998/Math/MathML", xa = typeof document < "u" ? document : null, Sa = xa && /* @__PURE__ */ xa.createElement("template"), Ca = {
	insert: (e, t, n) => {
		t.insertBefore(e, n || null);
	},
	remove: (e) => {
		let t = e.parentNode;
		t && t.removeChild(e);
	},
	createElement: (e, t, n, r) => {
		let i = t === "svg" ? xa.createElementNS(ya, e) : t === "mathml" ? xa.createElementNS(ba, e) : n ? xa.createElement(e, { is: n }) : xa.createElement(e);
		return e === "select" && r && r.multiple != null && i.setAttribute("multiple", r.multiple), i;
	},
	createText: (e) => xa.createTextNode(e),
	createComment: (e) => xa.createComment(e),
	setText: (e, t) => {
		e.nodeValue = t;
	},
	setElementText: (e, t) => {
		e.textContent = t;
	},
	parentNode: (e) => e.parentNode,
	nextSibling: (e) => e.nextSibling,
	querySelector: (e) => xa.querySelector(e),
	setScopeId(e, t) {
		e.setAttribute(t, "");
	},
	insertStaticContent(e, t, n, r, i, a) {
		let o = n ? n.previousSibling : t.lastChild;
		if (i && (i === a || i.nextSibling)) for (; t.insertBefore(i.cloneNode(!0), n), !(i === a || !(i = i.nextSibling)););
		else {
			Sa.innerHTML = va(r === "svg" ? `<svg>${e}</svg>` : r === "mathml" ? `<math>${e}</math>` : e);
			let i = Sa.content;
			if (r === "svg" || r === "mathml") {
				let e = i.firstChild;
				for (; e.firstChild;) i.appendChild(e.firstChild);
				i.removeChild(e);
			}
			t.insertBefore(i, n);
		}
		return [o ? o.nextSibling : t.firstChild, n ? n.previousSibling : t.lastChild];
	}
}, wa = /* @__PURE__ */ Symbol("_vtc");
function Ta(e, t, n) {
	let r = e[wa];
	r && (t = (t ? [t, ...r] : [...r]).join(" ")), t == null ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t;
}
var Ea = /* @__PURE__ */ Symbol("_vod"), Da = /* @__PURE__ */ Symbol("_vsh"), Oa = /* @__PURE__ */ Symbol(""), ka = /(?:^|;)\s*display\s*:/;
function Aa(e, t, n) {
	let r = e.style, i = x(n), a = !1;
	if (n && !i) {
		if (t) if (x(t)) for (let e of t.split(";")) {
			let t = e.slice(0, e.indexOf(":")).trim();
			n[t] ?? Ma(r, t, "");
		}
		else for (let e in t) n[e] ?? Ma(r, e, "");
		for (let i in n) {
			i === "display" && (a = !0);
			let o = n[i];
			o == null ? Ma(r, i, "") : Ia(e, i, !x(t) && t ? t[i] : void 0, o) || Ma(r, i, o);
		}
	} else if (i) {
		if (t !== n) {
			let e = r[Oa];
			e && (n += ";" + e), r.cssText = n, a = ka.test(n);
		}
	} else t && e.removeAttribute("style");
	Ea in e && (e[Ea] = a ? r.display : "", e[Da] && (r.display = "none"));
}
var ja = /\s*!important$/;
function Ma(e, t, n) {
	if (g(n)) n.forEach((n) => Ma(e, t, n));
	else if (n ??= "", t.startsWith("--")) e.setProperty(t, n);
	else {
		let r = Fa(e, t);
		ja.test(n) ? e.setProperty(E(r), n.replace(ja, ""), "important") : e[r] = n;
	}
}
var Na = [
	"Webkit",
	"Moz",
	"ms"
], Pa = {};
function Fa(e, t) {
	let n = Pa[t];
	if (n) return n;
	let r = T(t);
	if (r !== "filter" && r in e) return Pa[t] = r;
	r = le(r);
	for (let n = 0; n < Na.length; n++) {
		let i = Na[n] + r;
		if (i in e) return Pa[t] = i;
	}
	return t;
}
function Ia(e, t, n, r) {
	return e.tagName === "TEXTAREA" && (t === "width" || t === "height") && x(r) && n === r;
}
var La = "http://www.w3.org/1999/xlink";
function Ra(e, t, n, r, i, a = Se(t)) {
	r && t.startsWith("xlink:") ? n == null ? e.removeAttributeNS(La, t.slice(6, t.length)) : e.setAttributeNS(La, t, n) : n == null || a && !Ce(n) ? e.removeAttribute(t) : e.setAttribute(t, a ? "" : S(n) ? String(n) : n);
}
function za(e, t, n, r, i) {
	if (t === "innerHTML" || t === "textContent") {
		n != null && (e[t] = t === "innerHTML" ? va(n) : n);
		return;
	}
	let a = e.tagName;
	if (t === "value" && a !== "PROGRESS" && !a.includes("-")) {
		let r = a === "OPTION" ? e.getAttribute("value") || "" : e.value, i = n == null ? e.type === "checkbox" ? "on" : "" : String(n);
		(r !== i || !("_value" in e)) && (e.value = i), n ?? e.removeAttribute(t), e._value = n;
		return;
	}
	let o = !1;
	if (n === "" || n == null) {
		let r = typeof e[t];
		r === "boolean" ? n = Ce(n) : n == null && r === "string" ? (n = "", o = !0) : r === "number" && (n = 0, o = !0);
	}
	try {
		e[t] = n;
	} catch {}
	o && e.removeAttribute(i || t);
}
function Ba(e, t, n, r) {
	e.addEventListener(t, n, r);
}
function Va(e, t, n, r) {
	e.removeEventListener(t, n, r);
}
var Ha = /* @__PURE__ */ Symbol("_vei");
function Ua(e, t, n, r, i = null) {
	let a = e[Ha] || (e[Ha] = {}), o = a[t];
	if (r && o) o.value = r;
	else {
		let [n, s] = Ga(t);
		r ? Ba(e, n, a[t] = Ya(r, i), s) : o && (Va(e, n, o, s), a[t] = void 0);
	}
}
var Wa = /(?:Once|Passive|Capture)$/;
function Ga(e) {
	let t;
	if (Wa.test(e)) {
		t = {};
		let n;
		for (; n = e.match(Wa);) e = e.slice(0, e.length - n[0].length), t[n[0].toLowerCase()] = !0;
	}
	return [e[2] === ":" ? e.slice(3) : E(e.slice(2)), t];
}
var Ka = 0, qa = /* @__PURE__ */ Promise.resolve(), Ja = () => Ka ||= (qa.then(() => Ka = 0), Date.now());
function Ya(e, t) {
	let n = (e) => {
		if (!e._vts) e._vts = Date.now();
		else if (e._vts <= n.attached) return;
		let r = n.value;
		if (g(r)) {
			let n = e.stopImmediatePropagation;
			e.stopImmediatePropagation = () => {
				n.call(e), e._stopped = !0;
			};
			let i = r.slice(), a = [e];
			for (let n = 0; n < i.length && !e._stopped; n++) {
				let e = i[n];
				e && z(e, t, 5, a);
			}
		} else z(r, t, 5, [e]);
	};
	return n.value = e, n.attached = Ja(), n;
}
var Xa = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123, Za = (e, t, n, r, i, a) => {
	let o = i === "svg";
	t === "class" ? Ta(e, r, o) : t === "style" ? Aa(e, n, r) : u(t) ? d(t) || Ua(e, t, n, r, a) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : Qa(e, t, r, o)) ? (za(e, t, r), !e.tagName.includes("-") && (t === "value" || t === "checked" || t === "selected") && Ra(e, t, r, o, a, t !== "value")) : e._isVueCE && ($a(e, t) || e._def.__asyncLoader && (/[A-Z]/.test(t) || !x(r))) ? za(e, T(t), r, a, t) : (t === "true-value" ? e._trueValue = r : t === "false-value" && (e._falseValue = r), Ra(e, t, r, o));
};
function Qa(e, t, n, r) {
	if (r) return !!(t === "innerHTML" || t === "textContent" || t in e && Xa(t) && b(n));
	if (t === "spellcheck" || t === "draggable" || t === "translate" || t === "autocorrect" || t === "sandbox" && e.tagName === "IFRAME" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA") return !1;
	if (t === "width" || t === "height") {
		let t = e.tagName;
		if (t === "IMG" || t === "VIDEO" || t === "CANVAS" || t === "SOURCE") return !1;
	}
	return Xa(t) && x(n) ? !1 : t in e;
}
function $a(e, t) {
	let n = e._def.props;
	if (!n) return !1;
	let r = T(t);
	return Array.isArray(n) ? n.some((e) => T(e) === r) : Object.keys(n).some((e) => T(e) === r);
}
var eo = /* @__PURE__ */ f({ patchProp: Za }, Ca), to;
function no() {
	return to ||= fi(eo);
}
var ro = ((...e) => {
	let t = no().createApp(...e), { mount: n } = t;
	return t.mount = (e) => {
		let r = ao(e);
		if (!r) return;
		let i = t._component;
		!b(i) && !i.render && !i.template && (i.template = r.innerHTML), r.nodeType === 1 && (r.textContent = "");
		let a = n(r, !1, io(r));
		return r instanceof Element && (r.removeAttribute("v-cloak"), r.setAttribute("data-v-app", "")), a;
	}, t;
});
function io(e) {
	if (e instanceof SVGElement) return "svg";
	if (typeof MathMLElement == "function" && e instanceof MathMLElement) return "mathml";
}
function ao(e) {
	return x(e) ? document.querySelector(e) : e;
}
//#endregion
//#region src/view/apps/dashboard/GrimdarkDashboard.vue?vue&type=script&setup=true&lang.ts
var oo = { class: "dashboard" }, so = {
	class: "dashboard__status",
	"aria-label": "Runtime status"
}, co = {
	key: 0,
	class: "dashboard__actor",
	"aria-label": "Selected actor"
}, lo = { class: "dashboard__actor-heading" }, uo = {
	key: 0,
	class: "dashboard__peril"
}, fo = { class: "dashboard__actor-grid" }, po = {
	key: 1,
	class: "dashboard__warning"
}, mo = {
	key: 2,
	class: "dashboard__warning",
	role: "status"
}, ho = { class: "dashboard__columns" }, go = { class: "dashboard__footer" }, _o = /* @__PURE__ */ Bn({
	__name: "GrimdarkDashboard",
	props: {
		actor: {},
		experimentalCombat: { type: Boolean },
		runtime: {}
	},
	setup(e) {
		let t = [
			"Melee exchange response prompt and opposed rolls",
			"Momentum gain, loss, use, and Initiative cap",
			"Recursive exploding damage and no doubled critical dice",
			"Toughness, armour, shield, Tank, and minimum-1 Negation",
			"Mortal Peril, Excess Damage, and thirteen Critical Injury tables"
		], n = [
			"Fate and fatal-injury intervention (rule still open)",
			"Armour Piercing conversion values (rule still open)",
			"Bleeding timing and First Aid procedure (rule still open)",
			"Perilous magic, Fear/Terror, corruption, and careers (rules still open)"
		];
		return (r, i) => (Oi(), Ni("main", oo, [
			i[14] ||= q("header", { class: "dashboard__hero" }, [
				q("p", { class: "dashboard__eyebrow" }, "Foundry VTT 14 · D&D5e 2024-first"),
				q("h1", null, "Grimdark 5e"),
				q("p", null, "5e chassis, Warhammer consequences.")
			], -1),
			q("section", so, [
				q("div", null, [i[0] ||= q("span", null, "Foundry", -1), q("strong", null, k(e.runtime.foundryVersion), 1)]),
				q("div", null, [i[1] ||= q("span", null, "D&D5e", -1), q("strong", null, k(e.runtime.systemVersion), 1)]),
				q("div", null, [i[2] ||= q("span", null, "Rules", -1), q("strong", null, k(e.runtime.rulesVersion), 1)])
			]),
			e.actor ? (Oi(), Ni("section", co, [q("div", lo, [q("div", null, [i[3] ||= q("p", { class: "dashboard__eyebrow" }, "Selected actor", -1), q("h2", null, k(e.actor.name), 1)]), e.actor.mortalPeril ? (Oi(), Ni("strong", uo, "Mortal Peril")) : Wi("", !0)]), q("div", fo, [
				q("div", null, [i[4] ||= q("span", null, "Negation", -1), q("strong", null, k(e.actor.negation.total), 1)]),
				q("div", null, [i[5] ||= q("span", null, "Toughness", -1), q("strong", null, k(e.actor.negation.toughness), 1)]),
				q("div", null, [i[6] ||= q("span", null, "Armour", -1), q("strong", null, k(e.actor.negation.armour), 1)]),
				q("div", null, [i[7] ||= q("span", null, "Shield", -1), q("strong", null, k(e.actor.negation.shield), 1)]),
				q("div", null, [i[8] ||= q("span", null, "Momentum", -1), q("strong", null, k(e.actor.momentum) + "/" + k(e.actor.momentumCap), 1)]),
				q("div", null, [i[9] ||= q("span", null, "Injuries", -1), q("strong", null, k(e.actor.criticalInjuries), 1)]),
				q("div", null, [i[10] ||= q("span", null, "Bleeding", -1), q("strong", null, k(e.actor.bleeding), 1)])
			])])) : (Oi(), Ni("p", po, "Select a token to inspect its Grimdark combat values.")),
			e.runtime.rulesVersion === "2024" ? Wi("", !0) : (Oi(), Ni("div", mo, " This module is designed against the 2024 rules. Set the D&D5e system Rules Version to Modern before enabling automation. ")),
			q("div", ho, [q("section", null, [i[11] ||= q("h2", null, "Scaffolded rule domains", -1), q("ul", null, [(Oi(), Ni(G, null, dr(t, (e) => q("li", { key: e }, k(e), 1)), 64))])]), q("section", null, [i[12] ||= q("h2", null, "Next integration slices", -1), q("ul", null, [(Oi(), Ni(G, null, dr(n, (e) => q("li", { key: e }, k(e), 1)), 64))])])]),
			q("footer", go, [i[13] ||= Ui(" Experimental combat automation: ", -1), q("strong", null, k(e.experimentalCombat ? "enabled" : "disabled"), 1)])
		]));
	}
}), Z = "grimdark-5e", vo = "Grimdark 5e", yo = "dnd5e";
//#endregion
//#region src/module/dnd5e/get-dnd5e-runtime-info.ts
function bo() {
	let e = game?.settings.get(yo, "rulesVersion");
	return e === "modern" ? "2024" : e === "legacy" ? "2014" : "unknown";
}
function xo() {
	let e = game?.system;
	return {
		foundryVersion: game?.version ?? "unknown",
		isExpectedSystem: e?.id === yo,
		rulesVersion: bo(),
		systemId: e?.id ?? "unknown",
		systemVersion: e?.version ?? "unknown"
	};
}
//#endregion
//#region src/module/settings/register-module-settings.ts
var So = {
	experimentalCombat: "experimentalCombat",
	dodgeCriticalPriority: "dodgeCriticalPriority",
	unopposedResolution: "unopposedResolution",
	automaticCriticalInjuries: "automaticCriticalInjuries"
};
function Co() {
	if (!game) throw Error("Foundry game global is unavailable during module settings registration.");
	game.settings.register(Z, So.experimentalCombat, {
		config: !0,
		default: !0,
		hint: "GRIMDARK_5E.Settings.ExperimentalCombat.Hint",
		name: "GRIMDARK_5E.Settings.ExperimentalCombat.Name",
		scope: "world",
		type: Boolean
	}), game.settings.register(Z, So.dodgeCriticalPriority, {
		choices: {
			both: "GRIMDARK_5E.Settings.DodgeCriticalPriority.Both",
			dodge: "GRIMDARK_5E.Settings.DodgeCriticalPriority.Dodge"
		},
		config: !0,
		default: "both",
		hint: "GRIMDARK_5E.Settings.DodgeCriticalPriority.Hint",
		name: "GRIMDARK_5E.Settings.DodgeCriticalPriority.Name",
		scope: "world",
		type: String
	}), game.settings.register(Z, So.unopposedResolution, {
		choices: {
			always: "GRIMDARK_5E.Settings.UnopposedResolution.Always",
			automaticExceptNaturalOne: "GRIMDARK_5E.Settings.UnopposedResolution.NaturalOne"
		},
		config: !0,
		default: "automaticExceptNaturalOne",
		hint: "GRIMDARK_5E.Settings.UnopposedResolution.Hint",
		name: "GRIMDARK_5E.Settings.UnopposedResolution.Name",
		scope: "world",
		type: String
	}), game.settings.register(Z, So.automaticCriticalInjuries, {
		config: !0,
		default: !0,
		hint: "GRIMDARK_5E.Settings.AutomaticCriticalInjuries.Hint",
		name: "GRIMDARK_5E.Settings.AutomaticCriticalInjuries.Name",
		scope: "world",
		type: Boolean
	});
}
function wo() {
	return game?.settings.get(Z, So.experimentalCombat) === !0;
}
function To() {
	return game?.settings.get("grimdark-5e", So.dodgeCriticalPriority) === "dodge" ? "dodge" : "both";
}
function Eo() {
	return game?.settings.get("grimdark-5e", So.unopposedResolution) === "always" ? "always" : "automaticExceptNaturalOne";
}
function Do() {
	return game?.settings.get(Z, So.automaticCriticalInjuries) === !0;
}
//#endregion
//#region src/module/dnd5e/actor-values.ts
function Oo(e) {
	return typeof e == "object" && e ? e : {};
}
function ko(e, t = 0) {
	return typeof e == "number" && Number.isFinite(e) ? e : t;
}
function Ao(e, t) {
	return Oo(e[t]);
}
function jo(e, t) {
	return ko(e.system.abilities?.[t]?.mod);
}
function Mo(e) {
	return ko(e.system.attributes?.prof, 2);
}
function No(e) {
	let t = e.system.attributes?.init;
	return ko(t?.total, ko(t?.value, jo(e, "dex")));
}
function Po(e) {
	return e.system.equipped === !0;
}
function Fo(e) {
	if (e.type !== "equipment" || !Po(e)) return;
	let t = Ao(e.system, "type"), n = Ao(e.system, "armor"), r = (t.value ?? n.type) === "shield";
	return {
		shield: r,
		value: ko(n.base, ko(n.value, r ? 2 : 10))
	};
}
function Io(e) {
	let t = 10, n = 0;
	for (let r of e.items) {
		let e = Fo(r);
		e && (e.shield ? n = Math.max(n, e.value) : t = Math.max(t, e.value));
	}
	return {
		armourBaseAc: t,
		shieldBonus: n
	};
}
function Lo(e, n = {}) {
	return t({
		...Io(e),
		constitutionModifier: jo(e, "con"),
		proficiencyBonus: Mo(e),
		strengthModifier: jo(e, "str"),
		...n
	});
}
function Ro(e) {
	return r(No(e));
}
function zo(e) {
	return Array.from(e.items).filter((e) => e.type === "weapon" && Po(e));
}
function Bo(e) {
	if (typeof e == "string") return e;
	if (e && Symbol.iterator in Object(e)) {
		let t = Array.from(e)[0];
		return typeof t == "string" ? t : void 0;
	}
}
function Vo(e) {
	return e ? Bo(Ao(Ao(e.system, "damage"), "base").types) ?? "bludgeoning" : "bludgeoning";
}
//#endregion
//#region src/functions/combat/critical-injury-severity.ts
function Ho(e) {
	return e.unmodified ? 0 : Math.max(0, Math.trunc(e.excessDamage ?? 0)) + Math.max(0, Math.trunc(e.existingInjuries)) * 10;
}
function Uo(e) {
	let t = Ho(e);
	return t > 0 ? `1d100 + ${t}` : "1d100";
}
//#endregion
//#region src/module/critical-injuries/critical-injury-service.ts
var Wo = "criticalInjury", Go = "bludgeoning";
function Ko(e) {
	return typeof e == "object" && e ? e : {};
}
function qo(e) {
	return typeof e == "number" && Number.isFinite(e) ? e : 0;
}
function Jo(e) {
	return e.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;");
}
function Yo(e) {
	let t = Ko(Ko(e.flags?.[Z])[Wo]);
	if (typeof t.name == "string") return t;
}
function Xo(e) {
	let t = Ko(e.flags?.[Z]);
	return typeof t.severity == "string" ? t.severity : "unknown";
}
function Zo(e) {
	let t = e.match(/(?:gain|increase[^.]*by)\s+Bleeding\s+(\d+)/i) ?? e.match(/Bleeding\s+(\d+)/i);
	return t ? Number.parseInt(t[1] ?? "0", 10) : 0;
}
function Qo(e) {
	return Array.from(e.effects).flatMap((e) => {
		let t = Yo(e);
		return t ? [{
			data: t,
			effect: e
		}] : [];
	});
}
function $o(e) {
	return Qo(e).reduce((e, t) => e + t.data.bleeding, 0);
}
async function es(e, t = 1) {
	let n = Math.max(0, Math.trunc(t));
	for (let t of Qo(e)) {
		if (!n || !t.data.bleeding || !t.effect.update) continue;
		let e = Math.min(n, t.data.bleeding);
		n -= e, await t.effect.update({ [`flags.${Z}.${Wo}.bleeding`]: t.data.bleeding - e });
	}
	return $o(e);
}
async function ts(e) {
	let { actor: t } = e, n = e.damageType?.toLowerCase() || Go, r = game?.packs.get(`${Z}.critical-injury-tables`);
	if (!r) {
		ui.notifications.error("Grimdark Critical Injury compendium is unavailable.");
		return;
	}
	let i = await r.getDocuments(), a = `${n} critical injuries`, o = i.find((e) => e.name.toLowerCase() === a) ?? i.find((e) => e.name.toLowerCase() === `${Go} critical injuries`);
	if (!o) {
		ui.notifications.error(`No Critical Injury table was found for ${n} damage.`);
		return;
	}
	let s = Qo(t).length, c = Math.max(0, Math.trunc(e.excessDamage ?? 0)), l = Uo({
		excessDamage: c,
		existingCriticalInjuries: s,
		unmodified: e.unmodified
	}), u = await o.roll({ roll: new Roll(l) }), d = u.results[0];
	if (!d) return;
	let f = d.description ?? "", p = {
		bleeding: Zo(f),
		damageType: n,
		description: f,
		excessDamage: c,
		name: d.name,
		rollTotal: qo(u.roll.total),
		severity: Xo(d)
	};
	await t.createEmbeddedDocuments("ActiveEffect", [{
		name: `Critical Injury: ${d.name}`,
		img: d.img ?? "icons/svg/blood.svg",
		description: f,
		disabled: !1,
		transfer: !1,
		flags: { [Z]: {
			[Wo]: p,
			source: e.source
		} }
	}]);
	let m = u.roll.render ? await u.roll.render() : `<strong>${p.rollTotal}</strong>`;
	return await ChatMessage.create({
		content: `<section class="grimdark-critical-card">
      <h3><i class="fa-solid fa-droplet"></i> Critical Injury — ${Jo(t.name)}</h3>
      <p><strong>${Jo(d.name)}</strong> · ${Jo(n)} · ${Jo(p.severity)}</p>
      ${f}
      <details><summary>Severity roll</summary>${m}</details>
    </section>`,
		flags: { [Z]: { criticalInjury: p } },
		speaker: ChatMessage.getSpeaker({ actor: t })
	}), p;
}
//#endregion
//#region src/module/combat/momentum-service.ts
var ns = "momentum";
function rs(e) {
	let t = e.getFlag(Z, ns);
	return typeof t == "number" && Number.isFinite(t) ? Math.max(0, Math.trunc(t)) : 0;
}
async function is(e, t) {
	let n = Math.min(Ro(e), Math.max(0, Math.trunc(t)));
	return await e.setFlag(Z, ns, n), n;
}
async function as(e, t) {
	t === "gain" ? await is(e, rs(e) + 1) : t === "clear" && await is(e, 0);
}
async function os(e, t, n) {
	await Promise.all([as(e, n.attackerMomentumChange), as(t, n.defenderMomentumChange)]);
}
//#endregion
//#region node_modules/pinia/dist/pinia.mjs
var ss = typeof window < "u", cs = Symbol(), ls;
(function(e) {
	e.direct = "direct", e.patchObject = "patch object", e.patchFunction = "patch function";
})(ls ||= {});
var us = typeof window == "object" && window.window === window ? window : typeof self == "object" && self.self === self ? self : typeof global == "object" && global.global === global ? global : typeof globalThis == "object" ? globalThis : { HTMLElement: null };
function ds(e, { autoBom: t = !1 } = {}) {
	return t && /^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(e.type) ? new Blob(["﻿", e], { type: e.type }) : e;
}
function fs(e, t, n) {
	let r = new XMLHttpRequest();
	r.open("GET", e), r.responseType = "blob", r.onload = function() {
		_s(r.response, t, n);
	}, r.onerror = function() {
		console.error("could not download file");
	}, r.send();
}
function ps(e) {
	let t = new XMLHttpRequest();
	t.open("HEAD", e, !1);
	try {
		t.send();
	} catch {}
	return t.status >= 200 && t.status <= 299;
}
function ms(e) {
	try {
		e.dispatchEvent(new MouseEvent("click"));
	} catch {
		let t = new MouseEvent("click", {
			bubbles: !0,
			cancelable: !0,
			view: window,
			detail: 0,
			screenX: 80,
			screenY: 20,
			clientX: 80,
			clientY: 20,
			ctrlKey: !1,
			altKey: !1,
			shiftKey: !1,
			metaKey: !1,
			button: 0,
			relatedTarget: null
		});
		e.dispatchEvent(t);
	}
}
var hs = typeof navigator == "object" ? navigator : { userAgent: "" }, gs = /Macintosh/.test(hs.userAgent) && /AppleWebKit/.test(hs.userAgent) && !/Safari/.test(hs.userAgent), _s = ss ? typeof HTMLAnchorElement < "u" && "download" in HTMLAnchorElement.prototype && !gs ? vs : "msSaveOrOpenBlob" in hs ? ys : bs : () => {};
function vs(e, t = "download", n) {
	let r = document.createElement("a");
	r.download = t, r.rel = "noopener", typeof e == "string" ? (r.href = e, r.origin === location.origin ? ms(r) : ps(r.href) ? fs(e, t, n) : (r.target = "_blank", ms(r))) : (r.href = URL.createObjectURL(e), setTimeout(function() {
		URL.revokeObjectURL(r.href);
	}, 4e4), setTimeout(function() {
		ms(r);
	}, 0));
}
function ys(e, t = "download", n) {
	if (typeof e == "string") if (ps(e)) fs(e, t, n);
	else {
		let t = document.createElement("a");
		t.href = e, t.target = "_blank", setTimeout(function() {
			ms(t);
		});
	}
	else navigator.msSaveOrOpenBlob(ds(e, n), t);
}
function bs(e, t, n, r) {
	if (r ||= open("", "_blank"), r && (r.document.title = r.document.body.innerText = "downloading..."), typeof e == "string") return fs(e, t, n);
	let i = e.type === "application/octet-stream", a = /constructor/i.test(String(us.HTMLElement)) || "safari" in us, o = /CriOS\/[\d]+/.test(navigator.userAgent);
	if ((o || i && a || gs) && typeof FileReader < "u") {
		let t = new FileReader();
		t.onloadend = function() {
			let e = t.result;
			if (typeof e != "string") throw r = null, Error("Wrong reader.result type");
			e = o ? e : e.replace(/^data:[^;]*;/, "data:attachment/file;"), r ? r.location.href = e : location.assign(e), r = null;
		}, t.readAsDataURL(e);
	} else {
		let t = URL.createObjectURL(e);
		r ? r.location.assign(t) : location.href = t, r = null, setTimeout(function() {
			URL.revokeObjectURL(t);
		}, 4e4);
	}
}
var { assign: xs } = Object;
function Ss() {
	let e = Ae(!0), t = e.run(() => /* @__PURE__ */ Kt({})), n = [], r = [], i = Wt({
		install(e) {
			i._a = e, e.provide(cs, i), e.config.globalProperties.$pinia = i, r.forEach((e) => n.push(e)), r = [];
		},
		use(e) {
			return this._a ? n.push(e) : r.push(e), this;
		},
		_p: n,
		_a: null,
		_e: e,
		_s: /* @__PURE__ */ new Map(),
		state: t
	});
	return i;
}
var { assign: Cs } = Object, ws = class extends foundry.applications.api.ApplicationV2 {
	#e;
	getVueProps() {}
	async _renderHTML(e, t) {
		let n = document.createElement("div");
		return n.classList.add("grimdark-5e-root"), n.dataset.theme = "grimdark-5e", n;
	}
	_replaceHTML(e, t, n) {
		this.unmountVue(), t.classList.add("grimdark-5e-app"), t.replaceChildren(e), this.#e = ro(this.getVueComponent(), this.getVueProps() ?? {}), this.#e.use(Ss()), this.#e.mount(e);
	}
	async _preClose(e) {
		this.unmountVue(), await super._preClose(e);
	}
	unmountVue() {
		this.#e?.unmount(), this.#e = void 0;
	}
}, Ts = class extends ws {
	static DEFAULT_OPTIONS = {
		id: `${Z}-dashboard`,
		tag: "section",
		window: {
			icon: "fa-solid fa-shield-halved",
			resizable: !0,
			title: vo
		},
		position: {
			height: "auto",
			width: 620
		}
	};
	getVueComponent() {
		return _o;
	}
	getVueProps() {
		let e = canvas.tokens?.controlled[0]?.actor ?? game?.user.character, t = e ? Lo(e) : void 0;
		return {
			actor: e ? {
				bleeding: $o(e),
				criticalInjuries: Qo(e).length,
				mortalPeril: e.getFlag(Z, "mortalPeril") === !0,
				momentum: rs(e),
				momentumCap: Ro(e),
				name: e.name,
				negation: t
			} : void 0,
			experimentalCombat: wo(),
			runtime: xo()
		};
	}
};
//#endregion
//#region src/module/api/create-module-api.ts
async function Es(e) {
	let t = await fromUuid(e);
	if (typeof t == "object" && t && "applyDamage" in t) return t;
}
function Ds() {
	return {
		calculateDamageNegation: t,
		calculateMomentumCap: r,
		calculateToughness: e,
		async getActorCombatSummary(e) {
			let t = await Es(e);
			if (t) return {
				bleeding: $o(t),
				criticalInjuries: Qo(t).length,
				mortalPeril: t.getFlag(Z, "mortalPeril") === !0,
				momentum: rs(t),
				momentumCap: Ro(t),
				negation: Lo(t)
			};
		},
		getDefenseResponses() {
			return n;
		},
		getRuntimeInfo: xo,
		async openDashboard() {
			await new Ts().render(!0);
		},
		async reduceBleeding(e, t) {
			let n = await Es(e);
			return n ? es(n, t) : void 0;
		},
		async rollCriticalInjury(e, t = {}) {
			let n = await Es(e);
			return n ? ts({
				actor: n,
				...t
			}) : void 0;
		},
		resolveDamageAfterNegation: i,
		async setMomentum(e, t) {
			let n = await Es(e);
			return n ? is(n, t) : void 0;
		}
	};
}
//#endregion
//#region src/module/api/register-module-api.ts
function Os() {
	if (!game) throw Error("Foundry game global is unavailable during module API registration.");
	let e = game.modules.get(Z);
	if (!e) throw Error(`Foundry module registry entry was not found for ${Z}.`);
	e.api = Ds();
}
//#endregion
//#region src/module/dnd5e/report-runtime-status.ts
function ks() {
	let e = xo();
	if (!e.isExpectedSystem) {
		console.error(`${vo} requires the dnd5e system; found ${e.systemId}.`);
		return;
	}
	e.rulesVersion !== "2024" && console.warn(`${vo} is 2024-first, but this world currently reports the ${e.rulesVersion} rules baseline.`), console.info(`${vo} ready on Foundry ${e.foundryVersion}, dnd5e ${e.systemVersion}, rules ${e.rulesVersion}.`);
}
//#endregion
//#region src/module/dnd5e/register-damage-hooks.ts
var As = new Set([
	"bludgeoning",
	"piercing",
	"slashing"
]);
function Q(e) {
	return typeof e == "object" && e ? e : {};
}
function js(e) {
	let t = Q(Q(e[Z]).damageContext);
	return {
		...Q(Q(Q(Q(e.originatingMessage).flags)[Z]).damageContext),
		...t
	};
}
function Ms(e, t) {
	if (t.damageType) return t.damageType;
	let n = e.filter((e) => (e.value ?? 0) > 0 && e.type);
	return n.sort((e, t) => (t.value ?? 0) - (e.value ?? 0)), n[0]?.type ?? "bludgeoning";
}
function Ns(e) {
	let t = e.system.attributes?.hp;
	return Math.max(0, (t?.value ?? 0) + (t?.temp ?? 0));
}
function Ps(e, t, n) {
	if (!wo() || t.amount <= 0) return;
	let r = Q(n[Z]), a = js(n), o = a.defenderActorUuid, s = o && o !== e.uuid ? {} : a, c = Ms(t, s), l = t.amount, u = r.bypassNegation === !0, d = As.has(c), f = c !== "psychic", p = u ? {
		armour: 0,
		shield: 0,
		tanking: 0,
		toughness: 0,
		total: 0
	} : Lo(e, {
		armourApplies: d,
		shieldApplies: d,
		tanking: s.response === "tank",
		toughnessApplies: f
	}), m = u ? l : i({
		damage: l,
		negation: p.total
	}), h = Math.max(0, m - Ns(e));
	t.amount = m, n[Z] = {
		...r,
		resolution: {
			context: s,
			damageType: c,
			excessDamage: h,
			finalAmount: m,
			negation: p,
			rawAmount: l
		}
	};
}
function Fs() {
	return game?.user.isGM === !0 && game.users.activeGM?.id === game.user.id;
}
async function Is(e, t, n) {
	if (!wo()) return;
	if (!Fs()) {
		let r = Q(Q(n[Z]).resolution);
		game?.users.activeGM && game.socket.emit(`module.${Z}`, {
			actorUuid: e.uuid,
			amount: t,
			resolution: r,
			type: "damageConsequences"
		});
		return;
	}
	let r = e.system.attributes?.hp?.value ?? 0;
	r <= 0 ? await e.setFlag(Z, "mortalPeril", !0) : e.getFlag("grimdark-5e", "mortalPeril") && await e.unsetFlag(Z, "mortalPeril");
	let i = Q(Q(n[Z]).resolution);
	if (t <= 0 || !Object.keys(i).length) return;
	let a = Q(i.negation), o = Number(i.rawAmount ?? t), s = Number(i.finalAmount ?? t), c = Number(i.excessDamage ?? 0), l = String(i.damageType ?? "bludgeoning"), u = Q(i.context), d = u.attackerCritical === !0 || u.surprisedCritical === !0 || c > 0;
	await ChatMessage.create({
		content: `<section class="grimdark-damage-card">
      <h3><i class="fa-solid fa-shield-halved"></i> Grimdark Damage — ${e.name}</h3>
      <p><strong>${o}</strong> incoming − <strong>${Number(a.total ?? 0)}</strong> Negation
      = <strong>${s}</strong> damage.</p>
      <p class="grimdark-breakdown">Toughness ${Number(a.toughness ?? 0)} · Armour ${Number(a.armour ?? 0)} · Shield ${Number(a.shield ?? 0)} · Tank ${Number(a.tanking ?? 0)}</p>
      ${c > 0 ? `<p><strong>${c} Excess Damage</strong> — Critical Injury triggered.</p>` : ""}
      ${r <= 0 ? "<p><strong>Mortal Peril:</strong> the creature remains conscious, but death saves are replaced by concrete injuries.</p>" : ""}
    </section>`,
		flags: { [Z]: { damageResolution: i } },
		speaker: ChatMessage.getSpeaker({ actor: e })
	}), d && Do() && await ts({
		actor: e,
		damageType: l,
		excessDamage: c,
		source: typeof u.exchangeMessageId == "string" ? u.exchangeMessageId : void 0
	});
}
function Ls() {
	Hooks.on("dnd5e.calculateDamage", ((e, t, n) => {
		Ps(e, t, n);
	})), Hooks.on("dnd5e.applyDamage", ((e, t, n) => {
		Is(e, t, n);
	})), Hooks.on("dnd5e.preRollDeathSaveV2", ((e) => {
		let t = e.subject, n = typeof Q(t).getFlag == "function" ? t : Q(t).actor;
		if (!(!wo() || !n?.getFlag("grimdark-5e", "mortalPeril"))) return ui.notifications.warn("Death saves are replaced by Mortal Peril and Critical Injuries in Grimdark 5e."), !1;
	})), Hooks.once("ready", (() => {
		game?.socket.on(`module.${Z}`, (e) => {
			let t = Q(e);
			!Fs() || t.type !== "damageConsequences" || typeof t.actorUuid != "string" || typeof t.amount != "number" || fromUuid(t.actorUuid).then((e) => {
				let n = e;
				if (n) return Is(n, t.amount, { [Z]: { resolution: t.resolution } });
			});
		});
	}));
}
//#endregion
//#region src/module/dnd5e/register-roll-hooks.ts
var Rs = {
	bonusDamage: "",
	bonusDice: 0,
	multiplier: 1,
	multiplyNumeric: !1,
	powerfulCritical: !1
};
function zs(e) {
	e.options ??= {}, e.options.isCritical = !1, e.options.critical = Rs, e.configureDamage?.({ critical: Rs });
}
function Bs(e) {
	for (let t of e.dice ?? []) t.modifiers ??= [], t.modifiers.some((e) => e.toLowerCase().startsWith("x")) || t.modifiers.push("x");
	e.resetFormula?.();
}
function Vs() {
	Hooks.on("dnd5e.postBuildDamageRollConfig", ((e, t) => {
		if (!wo()) return;
		e.isCritical = !1, e.critical = Rs;
		let n = typeof t.options == "object" && t.options ? t.options : t.options = {};
		n.isCritical = !1, n.critical = Rs;
	})), Hooks.on("dnd5e.postDamageRollConfiguration", ((e) => {
		if (wo()) for (let t of e) zs(t), Bs(t);
	}));
}
//#endregion
//#region src/functions/combat/resolve-melee-exchange.ts
function Hs(e) {
	return e.total + e.momentum;
}
function Us(e) {
	return e.modifier + e.momentum;
}
function Ws(e, t) {
	let n = Hs(e), r = Hs(t);
	if (n !== r) return n > r ? "attacker" : "defender";
	let i = Us(e), a = Us(t);
	return i === a ? "stalemate" : i > a ? "attacker" : "defender";
}
function Gs(e) {
	let t = e.response === "parry" || e.response === "dodge", n = t ? Ws(e.attacker, e.defender ?? e.attacker) : "unopposed", r = e.response === "tank" ? !0 : e.unopposedSucceeds ?? e.attacker.natural !== 1, i = e.defender?.natural === 20, a = e.response === "dodge" && i;
	return {
		attackerCritical: e.attacker.natural === 20,
		attackerMomentumChange: n === "attacker" ? "gain" : n === "defender" ? "clear" : "none",
		defenderCritical: e.response === "parry" && i,
		defenderMomentumChange: n === "defender" ? "gain" : n === "attacker" ? "clear" : "none",
		hit: t ? n === "attacker" && !a : r,
		normalDamageNegated: a,
		response: e.response,
		surprisedCritical: e.response === "surprised" && r,
		winner: n
	};
}
//#endregion
//#region src/module/combat/exchange-service.ts
function $(e) {
	return typeof e == "object" && e ? e : {};
}
function Ks(e) {
	return $(e.flags?.dnd5e);
}
function qs(e) {
	return $(e.flags?.[Z]);
}
function Js(e) {
	let t = $(Ks(e).activity).uuid;
	return typeof t == "string" ? t : void 0;
}
function Ys(e) {
	let t = Ks(e).targets;
	return Array.isArray(t) ? t.filter((e) => typeof $(e).uuid == "string") : [];
}
function Xs(e) {
	for (let t of e.dice ?? []) {
		let e = t.results.find((e) => e.active !== !1);
		if (e) return e.result;
	}
	return Math.trunc(e.total);
}
function Zs(e) {
	if (e.type !== "attack") return !1;
	let t = e.attack?.type?.value, n = e.item.system.actionType;
	return t === "melee" || n === "mwak";
}
function Qs(e) {
	return $(Ks(e).roll).type === "attack";
}
function $s(e) {
	let t = $(e);
	if (typeof t.applyDamage == "function") return e;
	let n = t.actor;
	return typeof $(n).applyDamage == "function" ? n : void 0;
}
function ec(e, t) {
	let n = Mo(e);
	return t === "dodge" ? n + jo(e, "dex") : n + Math.max(jo(e, "str"), jo(e, "dex"));
}
async function tc(e, t) {
	let n = ec(e, t), r = await new Roll("1d20 + @modifier", { modifier: n }).evaluate();
	return {
		exchangeRoll: {
			modifier: n,
			momentum: rs(e),
			natural: Xs(r),
			total: r.total
		},
		roll: r
	};
}
function nc(e) {
	return game?.user.isGM === !0 || e.isOwner === !0;
}
function rc() {
	return game?.user.isGM === !0 && game.users.activeGM?.id === game.user.id;
}
async function ic(e, t) {
	let n = game?.messages.get(e);
	if (!n || qs(n).exchange) return;
	let r = Js(n), i = Ys(n)[0], a = n.rolls?.[0];
	if (!r || !i || !a) {
		ui.notifications.error("The attack must have one stored target and an attack roll before it can be resolved.");
		return;
	}
	let o = await fromUuid(r), s = $s(await fromUuid(i.uuid)), c = o?.actor;
	if (!o || !c || !s || !Zs(o)) {
		ui.notifications.error("Grimdark 5e could not resolve the attacker, defender, or melee activity.");
		return;
	}
	let l = Xs(a), u = {
		modifier: a.total - l,
		momentum: rs(c),
		natural: l,
		total: a.total
	}, d = t === "parry" || t === "dodge" ? await tc(s, t) : void 0, f = Gs({
		attacker: u,
		defender: d?.exchangeRoll,
		response: t,
		unopposedSucceeds: Eo() === "always" ? !0 : void 0
	});
	await os(c, s, f);
	let p = Vo(o.item), m = {
		attackerActorUuid: c.uuid,
		attackerName: c.name,
		attackTotal: a.total + u.momentum,
		damageContext: {
			attackerCritical: f.attackerCritical,
			damageType: p,
			defenderActorUuid: s.uuid,
			exchangeMessageId: n.id,
			response: t,
			surprisedCritical: f.surprisedCritical
		},
		defenderActorUuid: s.uuid,
		defenderName: s.name,
		defenseTotal: d ? d.roll.total + d.exchangeRoll.momentum : void 0,
		resolution: f
	};
	await n.setFlag(Z, "exchange", m), f.defenderCritical && await ts({
		actor: c,
		damageType: Vo(zo(s)[0]),
		source: n.id
	});
	let h = t === "dodge" && f.normalDamageNegated && To() === "dodge";
	f.attackerCritical && !f.hit && !h && await ts({
		actor: s,
		damageType: p,
		source: n.id
	}), await ChatMessage.create({
		content: `<section class="grimdark-exchange-card">
      <h3><i class="fa-solid fa-swords"></i> Melee Exchange</h3>
      <p><strong>${c.name}</strong> ${m.attackTotal} vs. <strong>${s.name}</strong> ${m.defenseTotal ?? t}.</p>
      <p><strong>${f.hit ? "Hit" : "No normal damage"}</strong> · ${t} · ${f.winner}</p>
      <p>Momentum: ${c.name} ${rs(c)} · ${s.name} ${rs(s)}</p>
    </section>`,
		flags: { [Z]: { exchange: m } },
		speaker: n.speaker
	});
}
async function ac(e, t) {
	if (rc()) {
		await ic(e, t);
		return;
	}
	if (!game?.users.activeGM) {
		ui.notifications.error("An active GM is required to resolve a Grimdark exchange.");
		return;
	}
	game.socket.emit(`module.${Z}`, {
		messageId: e,
		response: t,
		type: "resolveExchange"
	}), ui.notifications.info("Exchange response sent to the GM.");
}
function oc() {
	Hooks.once("ready", (() => {
		game?.socket.on(`module.${Z}`, (e) => {
			let t = $(e);
			!rc() || t.type !== "resolveExchange" || typeof t.messageId != "string" || typeof t.response != "string" || ic(t.messageId, t.response);
		});
	}));
}
//#endregion
//#region src/module/combat/exchange-workflow.ts
async function sc(e) {
	let t = await foundry.applications.api.DialogV2.wait({
		window: { title: "Resolve Grimdark Exchange" },
		content: "<p>Choose how the defender responds. Parry and Dodge are opposed rolls; Tank, Unopposed, and Surprised do not roll.</p>",
		buttons: [
			{
				action: "parry",
				label: "Parry",
				icon: "<i class=\"fa-solid fa-swords\"></i>",
				callback: () => "parry"
			},
			{
				action: "dodge",
				label: "Dodge",
				icon: "<i class=\"fa-solid fa-person-running\"></i>",
				callback: () => "dodge"
			},
			{
				action: "tank",
				label: "Tank the Hit",
				icon: "<i class=\"fa-solid fa-shield\"></i>",
				callback: () => "tank"
			},
			{
				action: "unopposed",
				label: "Unopposed",
				callback: () => "unopposed"
			},
			{
				action: "surprised",
				label: "Surprised",
				callback: () => "surprised"
			}
		],
		rejectClose: !1
	});
	typeof t == "string" && [
		"parry",
		"dodge",
		"tank",
		"unopposed",
		"surprised"
	].includes(t) && await ac(e.id, t);
}
async function cc(e) {
	let t = $(qs(e).exchange);
	if ($(t.resolution).hit !== !0) return;
	let n = Js(e), r = n ? await fromUuid(n) : void 0;
	if (!r?.actor?.isOwner) {
		ui.notifications.warn("The attack's owner or GM must roll its damage.");
		return;
	}
	let i = $(t.damageContext);
	await r.rollDamage({ isCritical: !1 }, { configure: !0 }, { data: { flags: {
		dnd5e: { originatingMessage: e.id },
		[Z]: { damageContext: i }
	} } });
}
function lc(e) {
	let t = document.createElement("section");
	return t.className = "grimdark-exchange-panel", e ? (t.innerHTML = `<p><strong>${e.resolution.hit ? "Exchange won: roll damage" : "Exchange resolved: no normal damage"}</strong></p>
    <p>${e.attackerName} ${e.attackTotal} vs. ${e.defenderName} ${e.defenseTotal ?? e.resolution.response} · ${e.resolution.response}</p>
    ${e.resolution.hit ? "<button type=\"button\" data-grimdark-action=\"roll-damage\"><i class=\"fa-solid fa-burst\"></i> Roll Grimdark damage</button>" : ""}`, t) : (t.innerHTML = "<p><strong>Grimdark melee exchange</strong></p>\n      <button type=\"button\" data-grimdark-action=\"resolve-exchange\"><i class=\"fa-solid fa-swords\"></i> Resolve exchange</button>", t);
}
async function uc(e, t) {
	if (!wo() || !Qs(e) || t.querySelector(".grimdark-exchange-panel")) return;
	let n = Js(e), r = n ? await fromUuid(n) : void 0, i = Ys(e)[0], a = i ? $s(await fromUuid(i.uuid)) : void 0;
	if (!r || !Zs(r) || !a) return;
	let o = qs(e).exchange;
	if (!o && !nc(a)) return;
	let s = lc(o);
	if (t.querySelector(".message-content")?.append(s), o) for (let e of t.querySelectorAll("[data-action=\"rollDamage\"]")) e.disabled = !0, e.title = "Use Roll Grimdark damage after resolving the exchange.";
	s.addEventListener("click", (t) => {
		let n = t.target.closest("[data-grimdark-action]");
		n?.dataset.grimdarkAction === "resolve-exchange" && sc(e), n?.dataset.grimdarkAction === "roll-damage" && cc(e);
	});
}
function dc() {
	Hooks.on("renderChatMessageHTML", ((e, t) => {
		uc(e, t);
	})), oc();
}
//#endregion
//#region src/module/ui/register-ui-hooks.ts
function fc() {
	new Ts().render(!0);
}
function pc() {
	Hooks.on("getSceneControlButtons", ((e) => {
		let t = e.tokens;
		t && (t.tools ??= {}, t.tools[Z] = {
			name: Z,
			title: "Open Grimdark 5e dashboard",
			icon: "fa-solid fa-shield-halved",
			order: Object.keys(t.tools).length,
			button: !0,
			visible: !0,
			onChange: fc
		});
	}));
}
//#endregion
//#region src/module/hooks/register-module-hooks.ts
function mc() {
	dc(), Ls(), Vs(), pc(), Hooks.once("init", () => {
		Co(), Os();
	}), Hooks.once("ready", () => {
		ks();
	});
}
//#endregion
//#region src/main.ts
mc();
//#endregion

//# sourceMappingURL=grimdark-5e.mjs.map